var Ti=Object.defineProperty;var ji=(e,t,n)=>t in e?Ti(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n;var Ge=(e,t,n)=>ji(e,typeof t!="symbol"?t+"":t,n);import"./index-Dks-HI8O.js";import{k as Ne,s as Ce,I as Be,M as ve,l as On,n as Ai,B as Ii,L as Ft,S as Hn,a as y,j as l,t as $,D as Ie,o as Ei,g as zi,p as ln,q as Ri,h as Li}from"./theme-B737NtOh.js";import{C as Ni,R as Pi,i as _i,a as Di,r as Bi}from"./GuideRefiner-CP_FUjEj.js";import{o as Ui,v as Pt}from"./videoStore-BptGOnPg.js";import{c as se}from"./createLucideIcon-DVCY8CCe.js";import{f as Fi}from"./utils-zwI8c19Y.js";import{S as Vn,P as Wi,a as cn,F as Oi}from"./square-7HCpVZ4f.js";/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Hi=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],Vi=se("arrow-down",Hi);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Gi=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],Yi=se("arrow-up",Gi);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xi=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],qi=se("check",Xi);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ki=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],Gn=se("chevron-left",Ki);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qi=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],Yn=se("chevron-right",Qi);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Zi=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],Ji=se("circle-check",Zi);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const er=[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2",key:"4jdomd"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v4",key:"3hqy98"}],["path",{d:"M21 14H11",key:"1bme5i"}],["path",{d:"m15 10-4 4 4 4",key:"5dvupr"}]],vt=se("clipboard-copy",er);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tr=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"22",x2:"18",y1:"12",y2:"12",key:"l9bcsi"}],["line",{x1:"6",x2:"2",y1:"12",y2:"12",key:"13hhkx"}],["line",{x1:"12",x2:"12",y1:"6",y2:"2",key:"10w3f3"}],["line",{x1:"12",x2:"12",y1:"22",y2:"18",key:"15g9kq"}]],nr=se("crosshair",tr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ir=[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]],_t=se("download",ir);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rr=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M12 18v-6",key:"17g6i2"}],["path",{d:"m9 15 3 3 3-3",key:"1npd3o"}]],or=se("file-down",rr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ar=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M15.033 13.44a.647.647 0 0 1 0 1.12l-4.065 2.352a.645.645 0 0 1-.968-.56v-4.704a.645.645 0 0 1 .967-.56z",key:"1tzo1f"}]],sr=se("file-play",ar);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lr=[["path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",key:"1cjeqo"}],["path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",key:"19qd67"}]],cr=se("link",lr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const dr=[["path",{d:"M21 5H3",key:"1fi0y6"}],["path",{d:"M10 12H3",key:"1ulcyk"}],["path",{d:"M10 19H3",key:"108z41"}],["path",{d:"M15 12.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997a1 1 0 0 1-1.517-.86z",key:"ms4nik"}]],ur=se("list-video",dr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const pr=[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}],["path",{d:"M12 8v6",key:"1ib9pf"}],["path",{d:"M9 11h6",key:"1fldmi"}]],fr=se("message-square-plus",pr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const hr=[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]],mr=se("pencil",hr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const gr=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],xr=se("plus",gr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const br=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],yr=se("rotate-ccw",br);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const vr=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],wt=se("shield",vr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wr=[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],Sr=se("sparkles",wr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const kr=[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]],it=se("trash-2",kr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Mr=[["path",{d:"M9 14 4 9l5-5",key:"102s5s"}],["path",{d:"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",key:"f3b9sd"}]],$r=se("undo-2",Mr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Cr=[["path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",key:"uqj9uw"}],["path",{d:"M16 9a5 5 0 0 1 0 6",key:"1q6k2b"}],["path",{d:"M19.364 18.364a9 9 0 0 0 0-12.728",key:"ijwkga"}]],Tr=se("volume-2",Cr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jr=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Ar=se("x",jr),Ir="#2563eb";function Xn(e){return typeof e=="string"&&/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(e.trim())}function Wt(e){return Xn(e)?e.trim():Ir}function Ot(e,t){return Xn(t)?t.trim():Wt(e)}const Er=.8,zr=.65,Rr=.42;function Lr(e){var t,n;return!e||e.x===void 0||e.y===void 0||!((t=e.viewport)!=null&&t.width)||!((n=e.viewport)!=null&&n.height)?null:{left:`${Dt(dn(e.x/e.viewport.width*100))}%`,top:`${Dt(dn(e.y/e.viewport.height*100))}%`}}function Ht(e,t="circle"){if(!e)return null;if((e.shape??t)==="rectangle"){const r=_r(e);if(r)return{shape:"rectangle",...r}}const i=Lr(e);return i?{shape:"circle",...i}:null}function ct(e){const t=e.viewport;if(!(t!=null&&t.width)||!t.height)return{...e,shape:"rectangle"};const n=e.detectedRect??e.rect,i=e.rect&&(e.rectAdjusted||Kn(e.rect,t.width,t.height))?Xe(e.rect,t.width,t.height):null,r=Math.min(220,Math.max(72,t.width*.16)),a=Math.min(100,Math.max(36,t.height*.08)),s=Xe({x:(e.x??t.width/2)-r/2,y:(e.y??t.height/2)-a/2,width:r,height:a},t.width,t.height),o=i??s;return{...e,shape:"rectangle",x:o.x+o.width/2,y:o.y+o.height/2,rect:o,detectedRect:n,rectAdjusted:!i||e.rectAdjusted}}function qn(e,t,n){const i=ct(e),r=i.viewport,a=i.rect;if(!(r!=null&&r.width)||!r.height||!a)return i;const s=Xe({...a,x:dt(t,0,1)*r.width-a.width/2,y:dt(n,0,1)*r.height-a.height/2},r.width,r.height);return{...i,x:s.x+s.width/2,y:s.y+s.height/2,rect:s,rectAdjusted:!0}}function Nr(e,t,n,i){const r=ct(e),a=r.viewport,s=r.rect;if(!(a!=null&&a.width)||!a.height||!s)return r;const o=Math.max(28,a.width*.025),c=Math.max(22,a.height*.025),d=n*a.width,u=i*a.height;let x=s.x,f=s.x+s.width,m=s.y,T=s.y+s.height;t.includes("left")&&(x=Math.min(f-o,x+d)),t.includes("right")&&(f=Math.max(x+o,f+d)),t.includes("top")&&(m=Math.min(T-c,m+u)),t.includes("bottom")&&(T=Math.max(m+c,T+u));const z=Xe({x,y:m,width:f-x,height:T-m},a.width,a.height);return{...r,x:z.x+z.width/2,y:z.y+z.height/2,rect:z,rectAdjusted:!0}}function Pr(e){var n;if(!e.detectedRect||!((n=e.viewport)!=null&&n.width)||!e.viewport.height)return e;const t=Xe(e.detectedRect,e.viewport.width,e.viewport.height);return{...e,x:t.x+t.width/2,y:t.y+t.height/2,rect:t,rectAdjusted:!1}}function _r(e){const t=e.viewport,n=e.rect;if(!(t!=null&&t.width)||!t.height||!n||!e.rectAdjusted&&!Kn(n,t.width,t.height))return null;const i=Xe(n,t.width,t.height);return i.width<=0||i.height<=0?null:Dr(i.x/t.width*100,i.y/t.height*100,i.width/t.width*100,i.height/t.height*100)}function Kn(e,t,n){if(e.width<6||e.height<6||t<=0||n<=0)return!1;const i=e.width/t,r=e.height/n;return i<=Er&&r<=zr&&i*r<=Rr}function Xe(e,t,n){const i=Math.min(t,Math.max(1,e.width)),r=Math.min(n,Math.max(1,e.height));return{x:dt(e.x,0,t-i),y:dt(e.y,0,n-r),width:i,height:r}}function dn(e,t=100){return Math.max(0,Math.min(t,e))}function dt(e,t,n){return Math.max(t,Math.min(n,e))}function Dr(e,t,n,i){const r=a=>`${Dt(a)}`;return{left:r(e)+"%",top:r(t)+"%",width:r(n)+"%",height:r(i)+"%"}}function Dt(e){return Math.round(e*100)/100}const St=5,Qn=240,un=.06;function Je(e){const{focusId:t,...n}=e;return{...n,text:e.text.slice(0,Qn),x:ut(e.x,.01,.99),y:ut(e.y,.01,.88)}}function Br(e,t,n,i={}){const r=Je({...e,x:e.x+t,y:e.y+n});return{...r,x:ut(r.x,.01,i.maxX??.99),y:ut(r.y,.01,i.maxY??.88)}}function Vt(e,t){var o,c;const n=(o=t==null?void 0:t.viewport)==null?void 0:o.width,i=(c=t==null?void 0:t.viewport)==null?void 0:c.height;if((t==null?void 0:t.x)===void 0||t.y===void 0||!n||n<=0||!i||i<=0)return e.x<.5?"right":"left";const r=(t==null?void 0:t.x)!==void 0&&n&&n>0?t.x/n:.5,a=(t==null?void 0:t.y)!==void 0&&i&&i>0?t.y/i:.5,s=e.y-a;return s<=-un?"down":s>=un?"up":e.x<r?"right":"left"}function Zn(e){const t=Je(e);return{left:`${pn(t.x*100)}%`,top:`${pn(t.y*100)}%`}}function ut(e,t,n){return Math.max(t,Math.min(n,Number.isFinite(e)?e:t))}function pn(e){return Math.round(e*1e3)/1e3}const $e="primary",at=5;function et(e,t=[]){const n=[];e&&n.push({id:$e,focus:e,primary:!0});for(const i of t.slice(0,Math.max(0,at-n.length)))i.id&&n.push({id:i.id,focus:i,primary:!1});return n}function Gt(e,t,n=[]){const i=et(t,n).map(s=>s.focus);if(i.length<=1)return i[0];let r,a=Number.POSITIVE_INFINITY;for(const s of i){const o=Ur(s);if(!o)continue;const c=Math.hypot(e.x-o.x,e.y-o.y);c<a&&(r=s,a=c)}return r??i[0]}function Ur(e){const t=e.viewport;if(!(t!=null&&t.width)||!t.height)return;const n=e.x??(e.rect?e.rect.x+e.rect.width/2:void 0),i=e.y??(e.rect?e.rect.y+e.rect.height/2:void 0);if(!(n===void 0||i===void 0))return{x:n/t.width,y:i/t.height}}const Jn={includeScreenshots:!0,includeMetadata:!0,includeTableOfContents:!0,includeStepNumbers:!0,includeFooter:!0,printOptimized:!1,themeColor:"#2563eb",focusColor:"",focusShape:"circle"};class kt{static renderMarkdown(t,n={}){const i=fn(n),r=De(t),a=[`# ${t.title}`,""],s=ni(t);if(i.includeMetadata&&(a.push(`> ${r.url}: ${t.url||"N/A"}`),a.push(`> ${r.updated}: ${new Date(t.createdAt).toLocaleString()}`),a.push("")),t.outline?Yr(a,t):s&&(a.push(`## ${r.summary}`,""),a.push(s,"")),i.includeTableOfContents&&t.steps.length>0){a.push(`## ${r.contents}`,"");for(const o of t.steps)a.push(`- ${Yt(o,i,t.language)} ${o.title}`);a.push("")}for(const o of t.steps){a.push(`## ${Gr(o,i,t.language)}`,""),a.push(o.description||"","");const c=ei(t,o);i.includeScreenshots&&c&&a.push(`![${r.step} ${o.stepNumber} ${r.screenshot}](${c.maskedDataUrl||c.dataUrl})`,""),a.push("---","")}return a.join(`
`)}static renderHtml(t,n={}){const i=fn(n),r=De(t),a=new Date(t.createdAt).toLocaleString();return`<!DOCTYPE html>
<html lang="${t.language==="en"?"en":"zh-CN"}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ye(t.title)}</title>
  <style>
    :root {
      color-scheme: light;
      --ink: #151c2e;
      --muted: #667085;
      --soft: #f7faf9;
      --panel: #ffffff;
      --line: #e4ece9;
      --brand: ${mn(i.themeColor)};
      --focus: ${mn(i.focusColor)};
      --brand-soft: color-mix(in srgb, var(--brand) 9%, #ffffff);
      --brand-faint: color-mix(in srgb, var(--brand) 5%, #f8fbfa);
      --click-soft: color-mix(in srgb, var(--focus) 14%, #ffffff);
      --shadow-sm: 0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 22px -18px rgba(15, 23, 42, 0.3);
      --shadow-md: 0 18px 44px -26px color-mix(in srgb, var(--brand) 34%, #0f172a);
      --radius-lg: 16px;
      --radius-md: 10px;
    }
    *, *::before, *::after { box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body {
      margin: 0;
      background:
        linear-gradient(180deg, color-mix(in srgb, var(--brand) 9%, #f8fbfa) 0, color-mix(in srgb, var(--brand) 4%, #f8fbfa) 260px, color-mix(in srgb, var(--brand) 6%, #f3f7f6) 100%);
      color: var(--ink);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
      line-height: 1.65;
      -webkit-font-smoothing: antialiased;
    }
    .topbar {
      position: sticky;
      top: 0;
      z-index: 10;
      display: flex;
      align-items: center;
      gap: 12px;
      height: 58px;
      padding: 0 24px;
      border-bottom: 1px solid color-mix(in srgb, var(--line) 84%, transparent);
      background: rgba(255, 255, 255, 0.88);
      backdrop-filter: blur(14px) saturate(160%);
    }
    .mark {
      width: 30px;
      height: 30px;
      border-radius: 9px;
      display: grid;
      place-items: center;
      color: #fff;
      background: linear-gradient(135deg, var(--brand), color-mix(in srgb, var(--brand) 68%, #0f172a));
      font-weight: 900;
      font-size: 12px;
      box-shadow: 0 8px 22px -12px var(--brand);
    }
    .topbar-title {
      min-width: 0;
      font-size: 14px;
      font-weight: 750;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .layout {
      width: min(1220px, calc(100% - 48px));
      margin: 0 auto;
      padding: 24px 0 64px;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(220px, 280px);
      gap: 24px;
    }
    .layout.no-sidebar {
      grid-template-columns: minmax(0, 1fr);
      width: min(1040px, calc(100% - 48px));
    }
    .sidebar {
      position: sticky;
      top: 82px;
      align-self: start;
      max-height: calc(100dvh - 106px);
      overflow: auto;
    }
    .page {
      min-width: 0;
    }
    .cover {
      position: relative;
      overflow: hidden;
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      background: var(--panel);
      padding: 30px 34px 32px;
      margin-bottom: 22px;
      box-shadow: var(--shadow-sm);
    }
    .cover::before {
      content: '';
      position: absolute;
      inset: 0 0 auto;
      height: 4px;
      background: linear-gradient(90deg, var(--brand), color-mix(in srgb, var(--brand) 30%, #38bdf8), color-mix(in srgb, var(--brand) 30%, #f43f5e));
    }
    .eyebrow {
      color: var(--brand);
      font-size: 12px;
      font-weight: 800;
      letter-spacing: .08em;
      text-transform: uppercase;
      margin-bottom: 8px;
    }
    h1 {
      font-size: clamp(30px, 4vw, 48px);
      line-height: 1.12;
      margin: 0 0 16px;
      letter-spacing: 0;
    }
    .meta-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 10px;
      margin-top: 18px;
    }
    .meta-item {
      border: 1px solid var(--line);
      background: var(--brand-faint);
      border-radius: 8px;
      padding: 10px 12px;
      min-width: 0;
    }
    .meta-label {
      color: var(--muted);
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      margin-bottom: 2px;
    }
    .meta-value {
      color: var(--ink);
      font-size: 13px;
      overflow-wrap: anywhere;
    }
    .meta-value a {
      color: var(--brand);
      text-decoration: none;
      font-weight: 500;
    }
    .meta-value a:hover {
      text-decoration: underline;
    }
    .toc {
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      padding: 14px;
      margin: 0;
      background: #fff;
      box-shadow: var(--shadow-sm);
    }
    .toc h2 {
      margin: 0 0 10px;
      padding: 0 4px 10px;
      border-bottom: 1px solid var(--line);
      font-size: 12px;
      color: var(--muted);
      letter-spacing: .08em;
      text-transform: uppercase;
    }
    .steps h2 {
      margin: 0 0 12px;
      font-size: 18px;
    }
    .toc ol {
      margin: 0;
      padding-left: 0;
      list-style: none;
    }
    .toc li {
      margin: 3px 0;
      color: var(--muted);
    }
    .toc a {
      display: block;
      border-radius: 8px;
      padding: 8px 10px;
      color: var(--ink);
      text-decoration: none;
      font-size: 13px;
      line-height: 1.45;
    }
    .toc a:hover {
      background: var(--brand-soft);
      color: var(--brand);
    }
    .toc-mobile {
      display: none;
      margin-bottom: 22px;
      max-height: min(42dvh, 360px);
      overflow-y: auto;
      overscroll-behavior: contain;
    }
    .overview {
      border: 1px solid var(--line);
      border-top: 4px solid var(--brand);
      border-radius: var(--radius-lg);
      padding: 18px 20px;
      margin-bottom: 22px;
      background: var(--brand-soft);
      box-shadow: var(--shadow-sm);
    }
    .overview h2 {
      margin: 14px 0 8px;
      font-size: 16px;
    }
    .overview h2:first-child {
      margin-top: 0;
    }
    .overview p {
      margin: 0;
      color: #475467;
      font-size: 14px;
      line-height: 1.85;
    }
    .overview ul {
      margin: 6px 0 0;
      padding-left: 20px;
      color: #475467;
      font-size: 14px;
    }
    .steps {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }
    .steps > h2 {
      margin: 4px 0 0;
      color: var(--muted);
      font-size: 12px;
      letter-spacing: .08em;
      text-transform: uppercase;
    }
    .step {
      overflow: hidden;
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      background: var(--panel);
      box-shadow: var(--shadow-sm);
      break-inside: avoid;
      scroll-margin-top: 82px;
      transition: border-color .18s ease, box-shadow .18s ease;
    }
    .step:hover {
      border-color: color-mix(in srgb, var(--brand) 24%, var(--line));
      box-shadow: var(--shadow-md);
    }
    .step-head {
      display: grid;
      grid-template-columns: auto minmax(0, 1fr);
      gap: 14px;
      padding: 18px 22px 14px;
    }
    .step-num {
      width: 34px;
      height: 34px;
      border-radius: 999px;
      background: var(--brand);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
      font-weight: 800;
      box-shadow: 0 8px 18px -10px var(--brand);
    }
    .step-title {
      margin: 0 0 6px;
      font-size: 19px;
      line-height: 1.4;
      letter-spacing: -0.02em;
      color: var(--ink);
      font-weight: 700;
    }
    .step-desc {
      color: #475467;
      margin: 0 0 14px;
      font-size: 15px;
      line-height: 1.7;
    }
    .screenshot-wrap {
      position: relative;
      margin: 0 22px 20px;
      overflow: hidden;
      border: 1px solid var(--line);
      border-radius: 12px;
      background: var(--soft);
    }
    .screenshot {
      width: 100%;
      display: block;
    }
    .click-circle {
      position: absolute;
      left: var(--focus-x, 50%);
      top: var(--focus-y, 50%);
      width: 44px;
      height: 44px;
      border: 3px solid var(--focus);
      border-radius: 50%;
      transform: translate(-50%, -50%);
      pointer-events: none;
      box-shadow: 0 0 0 3px #fff, 0 0 18px 4px color-mix(in srgb, var(--focus) 35%, transparent);
      animation: click-pulse 2.4s ease-in-out infinite;
      z-index: 3;
    }
    .focus-dim {
      position: absolute;
      inset: 0;
      pointer-events: none;
      opacity: 0;
      transition: opacity 160ms ease;
      z-index: 1;
      background: radial-gradient(circle 46px at var(--focus-x, 50%) var(--focus-y, 50%), transparent 0 46px, rgba(15, 23, 42, 0.10) 70px, rgba(15, 23, 42, 0.22) 100%);
    }
    .focus-rect {
      position: absolute;
      left: var(--focus-left, 40%);
      top: var(--focus-top, 40%);
      width: var(--focus-width, 20%);
      height: var(--focus-height, 10%);
      border: 3px solid var(--focus);
      border-radius: 7px;
      outline: 3px solid #fff;
      outline-offset: 2px;
      pointer-events: none;
      box-shadow: 0 5px 18px rgba(15, 23, 42, .32), 0 0 16px 3px color-mix(in srgb, var(--focus) 30%, transparent);
      transform-origin: center;
      animation: focus-rect-pulse 2.4s ease-in-out infinite;
      z-index: 3;
    }
    .focus-rect-dim {
      position: absolute;
      left: var(--focus-left, 40%);
      top: var(--focus-top, 40%);
      width: var(--focus-width, 20%);
      height: var(--focus-height, 10%);
      border-radius: 7px;
      box-shadow: 0 0 0 9999px rgba(15, 23, 42, 0.20);
      pointer-events: none;
      opacity: 0;
      transition: opacity 160ms ease;
      z-index: 1;
    }
    .focus-secondary {
      opacity: .78;
      animation: none;
    }
    .click-circle.focus-secondary {
      box-shadow: 0 0 0 2px rgba(255, 255, 255, .9), 0 3px 10px rgba(15, 23, 42, .22);
    }
    .focus-rect.focus-secondary {
      outline-width: 2px;
      box-shadow: 0 3px 12px rgba(15, 23, 42, .24);
    }
    .screenshot-note {
      position: absolute;
      max-width: min(32%, calc(99% - var(--annotation-x, 0%)));
      padding: 8px 14px;
      border: 0;
      border-radius: 7px;
      background: linear-gradient(180deg, color-mix(in srgb, var(--focus) 92%, #fff) 0%, var(--focus) 62%, color-mix(in srgb, var(--focus) 94%, #000) 100%);
      color: #fff;
      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .3), inset 0 1px rgba(255, 255, 255, .18);
      filter: drop-shadow(0 0 5px color-mix(in srgb, var(--focus) 20%, transparent)) drop-shadow(0 3px 2px rgba(15, 23, 42, .25)) drop-shadow(0 8px 10px rgba(15, 23, 42, .22));
      font-size: clamp(12px, 1.45vw, 16px);
      font-weight: 700;
      line-height: 1.4;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      pointer-events: auto;
      transform: translateY(-1px);
      transition: transform 160ms ease, filter 160ms ease;
      z-index: 5;
    }
    .screenshot-note::before {
      position: absolute;
      top: 50%;
      width: 12px;
      height: 22px;
      background: var(--focus);
      content: '';
      transform: translateY(-50%);
    }
    .screenshot-note-left {
      margin-left: 9px;
    }
    .screenshot-note-left::before {
      left: -9px;
      clip-path: polygon(100% 0, 100% 100%, 0 50%);
    }
    .screenshot-note-right {
      margin-right: 9px;
    }
    .screenshot-note-right::before {
      right: -9px;
      clip-path: polygon(0 0, 100% 50%, 0 100%);
    }
    .screenshot-note-up {
      margin-top: 9px;
    }
    .screenshot-note-up::before {
      top: -9px;
      left: 50%;
      width: 22px;
      height: 12px;
      clip-path: polygon(50% 0, 100% 100%, 0 100%);
      transform: translateX(-50%);
    }
    .screenshot-note-down {
      margin-bottom: 9px;
    }
    .screenshot-note-down::before {
      top: auto;
      bottom: -9px;
      left: 50%;
      width: 22px;
      height: 12px;
      clip-path: polygon(0 0, 100% 0, 50% 100%);
      transform: translateX(-50%);
    }
    .screenshot-note:hover {
      transform: translateY(-4px);
      filter: drop-shadow(0 0 7px color-mix(in srgb, var(--focus) 28%, transparent)) drop-shadow(0 4px 3px rgba(15, 23, 42, .3)) drop-shadow(0 12px 14px rgba(15, 23, 42, .27));
    }
    .screenshot-wrap:hover .focus-dim,
    .screenshot-wrap:hover .focus-rect-dim {
      opacity: 1;
    }
    @keyframes click-pulse {
      0%, 100% { box-shadow: 0 0 0 3px #fff, 0 0 18px 4px color-mix(in srgb, var(--focus) 35%, transparent); transform: translate(-50%, -50%) scale(1); }
      50% { box-shadow: 0 0 0 3px #fff, 0 0 28px 8px color-mix(in srgb, var(--focus) 50%, transparent); transform: translate(-50%, -50%) scale(1.08); }
    }
    @keyframes focus-rect-pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.025); }
    }
    .step-action-tag {
      display: inline-flex;
      align-items: center;
      width: fit-content;
      max-width: calc(100% - 44px);
      margin: -2px 22px 20px;
      padding: 7px 10px;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 800;
      line-height: 1;
      letter-spacing: .02em;
    }
    .step-action-tag.click { color: #1d4ed8; background: #dbeafe; border: 1px solid #bfdbfe; }
    .step-action-tag.form { color: #166534; background: #dcfce7; border: 1px solid #bbf7d0; }
    .step-action-tag.select { color: #92400e; background: #fef3c7; border: 1px solid #fde68a; }
    .step-action-tag.selection { color: #6d28d9; background: #ede9fe; border: 1px solid #ddd6fe; }
    .step-action-tag.keyboard { color: #075985; background: #e0f2fe; border: 1px solid #bae6fd; }
    .step-action-tag.navigation { color: #be123c; background: #ffe4e6; border: 1px solid #fecdd3; }
    .step-action-tag.initial { color: #3730a3; background: #e0e7ff; border: 1px solid #c7d2fe; }
    .step-action-tag.generic { color: #334155; background: #e2e8f0; border: 1px solid #cbd5e1; }
    .footer {
      border-top: 1px solid var(--line);
      color: var(--muted);
      font-size: 12px;
      margin-top: 32px;
      padding-top: 18px;
    }
    @media (max-width: 1080px) {
      .topbar { padding: 0 16px; }
      .layout, .layout.no-sidebar {
        width: min(100% - 28px, 1040px);
        grid-template-columns: minmax(0, 1fr);
        padding-top: 18px;
      }
      .sidebar {
        display: none;
      }
      .toc-mobile {
        display: block;
      }
      .cover { padding: 24px 20px; }
      .step-head { padding: 16px 16px 12px; }
      .screenshot-wrap { margin: 0 16px 16px; }
      .step-num { width: 30px; height: 30px; }
    }
    @media print {
      @page { size: A4 portrait; margin: ${i.printOptimized?"0":"14mm 13mm 16mm"}; }
      html, body { width: 100%; background: #fff; }
      body {
        color: #111827;
        font-size: 10.5pt;
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
      }
      .topbar, .sidebar { display: none; }
      .layout, .layout.no-sidebar { display: block; width: auto; padding: 0; }
      .page {
        width: auto;
        max-width: none;
        padding: ${i.printOptimized?"14mm 13mm 16mm":"0"};
        box-decoration-break: clone;
        -webkit-box-decoration-break: clone;
      }
      .toc, .meta-item, .cover, .step { background: #fff; box-shadow: none; }
      .cover {
        min-height: 245mm;
        display: flex;
        flex-direction: column;
        justify-content: center;
        border: 0;
        border-top: 5px solid var(--brand);
        border-radius: 0;
        padding: 22mm 10mm;
        break-after: page;
      }
      .cover h1 { max-width: 150mm; font-size: 28pt; line-height: 1.18; }
      .meta-grid { margin-top: 18mm; }
      .overview { break-inside: avoid; box-shadow: none; }
      .toc-mobile {
        display: block;
        max-height: none;
        overflow: visible;
        break-inside: avoid;
        margin-bottom: 10mm;
        box-shadow: none;
      }
      .steps { display: block; }
      .steps > h2 { margin: 0 0 8mm; font-size: 11pt; }
      .step {
        break-inside: avoid-page;
        page-break-inside: avoid;
        margin: 0 0 7mm;
        border-radius: 3mm;
      }
      .step-head { padding: 5mm 6mm 4mm; }
      .screenshot-wrap { margin: 0 6mm 5mm; border-radius: 2mm; }
      .screenshot { height: auto; max-height: none; }
      .step-action-tag { margin: -1mm 6mm 5mm; }
      .footer { margin-top: 10mm; padding-top: 5mm; }
      a { color: inherit; text-decoration: underline; }
    }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="mark" aria-hidden="true">SP</div>
    <div class="topbar-title">${ye(t.title)}</div>
  </header>
  <div class="layout${i.includeTableOfContents&&t.steps.length>0?"":" no-sidebar"}">
    <main class="page">
      <section class="cover">
        <div class="eyebrow">${r.eyebrow}</div>
        <h1>${ye(t.title)}</h1>
        ${i.includeMetadata?Fr(t,a):""}
      </section>
      ${Wr(t)}
      ${i.includeTableOfContents&&t.steps.length>0?`<div class="toc-mobile">${hn(t,i)}</div>`:""}
      <section class="steps">
        <h2>${r.steps}</h2>
        ${t.steps.map(s=>Hr(t,s,i)).join(`
`)}
      </section>
      ${i.includeFooter?`<footer class="footer">${r.footer}</footer>`:""}
    </main>
    ${i.includeTableOfContents&&t.steps.length>0?`<aside class="sidebar">${hn(t,i)}</aside>`:""}
  </div>
</body>
</html>`}}function fn(e={}){const t={...Jn,...e},n=Wt(t.themeColor);return{...t,themeColor:n,focusColor:Ot(n,t.focusColor)}}function Fr(e,t){const n=De(e),i=e.url?`<a href="${ye(e.url)}" target="_blank" rel="noopener noreferrer">${ye(e.url)}</a>`:"N/A";return`<div class="meta-grid">
        <div class="meta-item">
          <div class="meta-label">${n.url}</div>
          <div class="meta-value">${i}</div>
        </div>
        <div class="meta-item">
          <div class="meta-label">${n.updated}</div>
          <div class="meta-value">${ye(t)}</div>
        </div>
      </div>`}function hn(e,t){if(e.steps.length===0)return"";const n=De(e);return`<nav class="toc" aria-label="${n.contents}">
      <h2>${n.contents}</h2>
      <ol>
${e.steps.map(i=>`        <li><a href="#step-${ti(i)}">${ye(`${Yt(i,t,e.language)} ${i.title}`.trim())}</a></li>`).join(`
`)}
      </ol>
    </nav>`}function Wr(e){if(!e.outline)return Or(e);const t=De(e),n=['<section class="overview" id="overview">'];return e.outline.purpose&&n.push(`<h2>${t.purpose}</h2><p>${ye(e.outline.purpose)}</p>`),e.outline.summary&&n.push(`<h2>${t.summary}</h2><p>${ye(e.outline.summary)}</p>`),n.push("</section>"),n.join(`
`)}function Or(e){const t=ni(e);return t?`<section class="overview" id="overview">
      <h2>${De(e).summary}</h2>
      <p>${ye(t)}</p>
    </section>`:""}function Hr(e,t,n){var u;const i=ei(e,t),r=et(t.focus,t.additionalFocuses).flatMap(x=>{const f=Ht(x.focus,n.focusShape);if(!f)return[];const m=x.primary?"":" focus-secondary";if(f.shape==="rectangle"){const z=`--focus-left: ${f.left}; --focus-top: ${f.top}; --focus-width: ${f.width}; --focus-height: ${f.height}`;return[`${x.primary?`<div class="focus-rect-dim" style="${z}"></div>`:""}<div class="focus-rect${m}" style="${z}"></div>`]}const T=`--focus-x: ${f.left}; --focus-y: ${f.top}`;return[`${x.primary?`<div class="focus-dim" style="${T}"></div>`:""}<div class="click-circle${m}" style="${T}"></div>`]}).join(""),a=(t.annotations??[]).flatMap(x=>{const f=Je(x),m=f.text.trim();if(!m)return[];const T=Zn(f);return[`<div class="screenshot-note screenshot-note-${Vt(f,Gt(f,t.focus,t.additionalFocuses))}" style="--annotation-x: ${T.left}; left: ${T.left}; top: ${T.top}">${ye(m)}</div>`]}).join(""),s=Vr(t.actionType,(u=t.focus)==null?void 0:u.type,e.language),o=De(e),c=n.includeScreenshots&&i?`<div class="screenshot-wrap"><img class="screenshot" src="${ye(i.maskedDataUrl||i.dataUrl)}" alt="${ye(`${o.step} ${t.stepNumber} ${o.screenshot}`)}">${r}${a}</div>`:"",d=n.includeStepNumbers?`<div class="step-num" aria-hidden="true">${t.stepNumber}</div>`:"<div></div>";return`<article class="step" id="step-${ti(t)}">
        <div class="step-head">
          ${d}
          <div>
          <h3 class="step-title">${ye(t.title)}</h3>
          <p class="step-desc">${ye(t.description)}</p>
          </div>
        </div>
        ${c}
        <div class="step-action-tag ${s.tone}">${s.label}</div>
      </article>`}function Vr(e,t,n){const i=n==="en";switch((t&&t!=="generic"?t:e||"").toLowerCase()){case"click":return{label:i?"Click":"点击操作",tone:"click"};case"input":case"change":case"focus":case"blur":return{label:i?"Form input":"填写表单",tone:"form"};case"select":return{label:i?"Select option":"下拉选单",tone:"select"};case"selection":return{label:i?"Text selection":"选中文本",tone:"selection"};case"keypress":return{label:i?"Keyboard input":"键盘输入",tone:"keyboard"};case"navigation":return{label:i?"Navigation":"页面跳转",tone:"navigation"};case"initial_screen":return{label:i?"Starting page":"起始页面",tone:"initial"};default:return{label:i?"Workflow step":"操作截图",tone:"generic"}}}function ei(e,t){return t.screenshotId?e.screenshots.find(n=>n.id===t.screenshotId):void 0}function Yt(e,t,n){return t.includeStepNumbers?`${n==="en"?"Step":"步骤"} ${e.stepNumber}:`:""}function Gr(e,t,n){const i=Yt(e,t,n);return i?`${i} ${e.title}`:e.title}function ti(e){return String(e.stepNumber)}function ni(e){const t=e.steps.map(r=>{var a;return(a=r.title)==null?void 0:a.trim()}).filter(Boolean).slice(0,5);if(t.length===0)return"";if(e.language==="en"){const r=t.join(", "),a=e.steps.length>t.length?", and more":"";return`This guide walks through "${e.title}" in ${e.steps.length} steps, including ${r}${a}.`}const n=t.join("、"),i=e.steps.length>t.length?"等操作":"操作";return`本篇 demo 演示“${e.title}”的完整操作流程，共 ${e.steps.length} 个步骤，主要包括：${n}${i}。`}function Yr(e,t){if(!t.outline)return;const n=De(t);t.outline.purpose&&e.push(`## ${n.purpose}`,"",t.outline.purpose,""),t.outline.summary&&e.push(`## ${n.summary}`,"",t.outline.summary,"")}function De(e){return e.language==="en"?{eyebrow:"StepMark guide",url:"Source URL",updated:"Updated",purpose:"Purpose",summary:"Summary",contents:"Contents",steps:"Steps",step:"Step",screenshot:"screenshot",footer:"Generated by StepMark. Review the content before publishing."}:{eyebrow:"StepMark 文档",url:"访问链接 URL",updated:"文档更新时间",purpose:"目的",summary:"操作概要",contents:"目录",steps:"步骤",step:"步骤",screenshot:"截图",footer:"由 StepMark 生成。发布前请检查内容。"}}function ye(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function mn(e){return typeof e=="string"&&/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(e.trim())?e.trim():"#2563eb"}class We{static export(t,n,i={}){switch(n){case"markdown":return this.toMarkdown(t,i);case"html":return this.toHtml(t,i);case"pdf":return this.toPdfForPrint(t,i);default:return this.toMarkdown(t,i)}}static getFilename(t,n){return`${t.title.replace(/[^a-zA-Z0-9\u4e00-\u9fa5\s-]/g,"").replace(/\s+/g,"-").toLowerCase().slice(0,50)||"guide"}.${{markdown:"md",html:"html",pdf:"pdf"}[n]}`}static getDefaultOptions(){return{...Jn}}static toMarkdown(t,n){return{content:kt.renderMarkdown(t,n),filename:We.getFilename(t,"markdown"),mimeType:"text/markdown"}}static toHtml(t,n){return{content:kt.renderHtml(t,n),filename:We.getFilename(t,"html"),mimeType:"text/html"}}static toPdfForPrint(t,n){return{content:kt.renderHtml(t,{...n,includeFooter:!1,printOptimized:!0}),filename:We.getFilename(t,"pdf"),mimeType:"text/html"}}}const Xr=1600,ii=2,qr=80;async function ri(e,t,n){var u;const i=await io(e.dataUrl),r=i.naturalWidth||i.width,a=i.naturalHeight||i.height,s=Kr(r,a),o=document.createElement("canvas");o.width=s.width,o.height=s.height;const c=o.getContext("2d");if(!c||o.width<=0||o.height<=0)throw new Error("Could not prepare the screenshot for export");if(c.drawImage(i,0,0,o.width,o.height),t==="annotated")for(const x of et(e.focus,e.additionalFocuses)){const f=Ht(x.focus,x.focus.shape??"circle");if((f==null?void 0:f.shape)==="rectangle")Jr(c,{x:rt(f.left,o.width),y:rt(f.top,o.height),width:rt(f.width,o.width),height:rt(f.height,o.height),scale:((u=gn(x.focus,o.width,o.height))==null?void 0:u.scale)??1},n);else if(f){const m=gn(x.focus,o.width,o.height);m&&Zr(c,o.width,o.height,m,n)}}eo(c,e.annotations??[],o.width,o.height,n,e.focus,e.additionalFocuses);const d=o.toDataURL("image/png");return{dataUrl:d,bytes:Qr(d),width:o.width,height:o.height}}function Kr(e,t,n=Xr){if(e<=0||t<=0||n<=0)return{width:0,height:0};const i=Math.min(1,n/Math.max(e,t));return{width:Math.max(1,Math.round(e*i)),height:Math.max(1,Math.round(t*i))}}function gn(e,t,n){var o,c;if(!e||e.x===void 0||e.y===void 0)return null;const i=(o=e.viewport)==null?void 0:o.width,r=(c=e.viewport)==null?void 0:c.height,a=i&&i>0?t/i:e.devicePixelRatio||1,s=r&&r>0?n/r:e.devicePixelRatio||1;return{x:Oe(e.x*a,0,t),y:Oe(e.y*s,0,n),scale:Math.max(1,(a+s)/2)}}function Qr(e){const t=e.indexOf(",");if(t<0)throw new Error("Invalid screenshot data");const n=e.slice(0,t),i=e.slice(t+1),r=/;base64/i.test(n)?atob(i):decodeURIComponent(i),a=new Uint8Array(r.length);for(let s=0;s<r.length;s+=1)a[s]=r.charCodeAt(s);return a}function Zr(e,t,n,i,r){const a=Oe(i.scale,1,ii),s=Math.min(qr,Math.max(40*a,Math.min(t,n)*.04)),o=/^#[0-9a-f]{6}$/i.test(r)?r:"#2563eb";e.save(),e.beginPath(),e.arc(i.x,i.y,s,0,Math.PI*2),e.strokeStyle="#ffffff",e.lineWidth=Math.max(12,12*a),e.shadowColor="rgba(15, 23, 42, 0.52)",e.shadowBlur=Math.max(20,20*a),e.shadowOffsetY=Math.max(6,6*a),e.stroke(),e.restore(),e.save(),e.beginPath(),e.arc(i.x,i.y,s,0,Math.PI*2),e.strokeStyle=o,e.lineWidth=Math.max(5,5*a),e.stroke(),e.restore()}function Jr(e,t,n){const i=Oe(t.scale,1,ii),r=/^#[0-9a-f]{6}$/i.test(n)?n:"#2563eb";e.save(),e.strokeStyle="#ffffff",e.lineWidth=Math.max(12,12*i),e.shadowColor="rgba(15, 23, 42, 0.52)",e.shadowBlur=Math.max(20,20*i),e.shadowOffsetY=Math.max(6,6*i),xn(e,t),e.restore(),e.save(),e.strokeStyle=r,e.lineWidth=Math.max(5,5*i),xn(e,t),e.restore()}function eo(e,t,n,i,r,a,s=[]){const o=/^#[0-9a-f]{6}$/i.test(r)?r:"#2563eb",c=Oe(Math.round(n*.015),14,22),d=Math.round(c*.72),u=Math.round(c*.5),x=Math.round(c*.58),f=Math.round(c*1.42),m=Math.min(n*.3,390);for(const T of t){const z=Je(T),E=Vt(z,Gt(z,a,s)),D=z.text.trim();if(!D)continue;e.save(),e.font=`700 ${c}px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`;const R=to(e,D,m),O=Math.max(...R.map(J=>e.measureText(J).width)),Q=E==="left"||E==="right",ee=Math.min(n*.34,O+d*2+(Q?x:0)),Y=R.length*f+u*2+(Q?0:x),ie=Oe(z.x*n,4,Math.max(4,n-ee-4)),Z=Oe(z.y*i,4,Math.max(4,i-Y-4)),_=e.createLinearGradient(0,Z,0,Z+Y);_.addColorStop(0,bn(o,"#ffffff",.08)),_.addColorStop(.62,o),_.addColorStop(1,bn(o,"#000000",.06)),e.shadowColor="rgba(15, 23, 42, 0.28)",e.shadowBlur=Math.max(14,c*.95),e.shadowOffsetY=Math.max(6,c*.32),e.fillStyle=_,no(e,ie,Z,ee,Y,x,E),e.fill(),e.shadowColor="transparent",e.strokeStyle="rgba(255, 255, 255, 0.36)",e.lineWidth=Math.max(1.5,c*.075),e.stroke(),e.fillStyle="#ffffff",e.textBaseline="top",R.forEach((J,H)=>{const oe=E==="left"?ie+x+d:ie+d,le=E==="up"?Z+x+u:Z+u;e.fillText(J,oe,le+H*f,m)}),e.restore()}}function to(e,t,n){const i=[];for(const r of t.split(/\r?\n/)){let a="";for(const s of r||" "){const o=a+s;a&&e.measureText(o).width>n?(i.push(a.trimEnd()),a=s.trimStart()):a=o}(a||r==="")&&i.push(a.trim()||" ")}return i.slice(0,8)}function xn(e,t){e.beginPath(),typeof e.roundRect=="function"?e.roundRect(t.x,t.y,t.width,t.height,10):e.rect(t.x,t.y,t.width,t.height),e.stroke()}function no(e,t,n,i,r,a,s){const o=s==="left"?t+a:t,c=s==="right"?t+i-a:t+i,d=s==="up"?n+a:n,u=s==="down"?n+r-a:n+r,x=u-d,f=Math.min(8,x*.22),m=(o+c)/2,T=(d+u)/2,z=Math.min(a*.72,x*.28),E=Math.min(a*.9,(c-o)*.18);e.beginPath(),s==="left"?(e.moveTo(o+f,d),e.lineTo(c-f,d),e.quadraticCurveTo(c,d,c,d+f),e.lineTo(c,u-f),e.quadraticCurveTo(c,u,c-f,u),e.lineTo(o+f,u),e.quadraticCurveTo(o,u,o,u-f),e.lineTo(o,T+z),e.lineTo(t,T),e.lineTo(o,T-z),e.lineTo(o,d+f),e.quadraticCurveTo(o,d,o+f,d)):s==="right"?(e.moveTo(o+f,d),e.lineTo(c-f,d),e.quadraticCurveTo(c,d,c,d+f),e.lineTo(c,T-z),e.lineTo(t+i,T),e.lineTo(c,T+z),e.lineTo(c,u-f),e.quadraticCurveTo(c,u,c-f,u),e.lineTo(o+f,u),e.quadraticCurveTo(o,u,o,u-f),e.lineTo(o,d+f),e.quadraticCurveTo(o,d,o+f,d)):s==="up"?(e.moveTo(o+f,d),e.lineTo(m-E,d),e.lineTo(m,n),e.lineTo(m+E,d),e.lineTo(c-f,d),e.quadraticCurveTo(c,d,c,d+f),e.lineTo(c,u-f),e.quadraticCurveTo(c,u,c-f,u),e.lineTo(o+f,u),e.quadraticCurveTo(o,u,o,u-f),e.lineTo(o,d+f),e.quadraticCurveTo(o,d,o+f,d)):(e.moveTo(o+f,d),e.lineTo(c-f,d),e.quadraticCurveTo(c,d,c,d+f),e.lineTo(c,u-f),e.quadraticCurveTo(c,u,c-f,u),e.lineTo(m+E,u),e.lineTo(m,n+r),e.lineTo(m-E,u),e.lineTo(o+f,u),e.quadraticCurveTo(o,u,o,u-f),e.lineTo(o,d+f),e.quadraticCurveTo(o,d,o+f,d)),e.closePath()}function bn(e,t,n){var s,o;const i=(s=e.match(/[0-9a-f]{2}/gi))==null?void 0:s.map(c=>Number.parseInt(c,16)),r=(o=t.match(/[0-9a-f]{2}/gi))==null?void 0:o.map(c=>Number.parseInt(c,16));return!i||!r?e:`#${i.map((c,d)=>Math.round(c+(r[d]-c)*n).toString(16).padStart(2,"0")).join("")}`}function io(e){return new Promise((t,n)=>{const i=new Image;i.onload=()=>t(i),i.onerror=()=>n(new Error("Could not load a screenshot for export")),i.src=e})}function Oe(e,t,n){return Math.max(t,Math.min(n,e))}function rt(e,t){return Number.parseFloat(e)/100*t}const ro=24,oo=24,ao=40*1024*1024;function so(e){const t=e.steps.flatMap(i=>i.screenshot?[i.screenshot]:[]),n=t.reduce((i,r)=>i+uo(r.dataUrl),0);return{screenshotCount:t.length,estimatedSourceBytes:n,shouldWarn:e.steps.length>=oo||t.length>=ro||n>=ao}}async function lo(e,t=ri,n={}){const i=po(e.language),r=['<article style="font-family:Arial,Helvetica,sans-serif;color:#172033;line-height:1.55">'],a=[];n.includeHeader!==!1&&(r.push(`<h1>${Te(e.title)}</h1>`),a.push(e.title),e.sourceUrl&&(r.push(`<p><strong>${i.source}:</strong> <a href="${Te(e.sourceUrl)}">${Te(e.sourceUrl)}</a></p>`),a.push(`${i.source}: ${e.sourceUrl}`)),e.purpose&&(r.push(`<h2>${i.purpose}</h2><p>${Te(e.purpose)}</p>`),a.push("",i.purpose,e.purpose)),e.summary&&(r.push(`<h2>${i.summary}</h2><p>${Te(e.summary)}</p>`),a.push("",i.summary,e.summary)));for(const s of e.steps){if(r.push(`<section><h2>${Te(`${i.step} ${s.stepNumber}: ${s.title}`)}</h2>`),a.push("",`${i.step} ${s.stepNumber}: ${s.title}`),s.description&&(r.push(`<p>${Te(s.description)}</p>`),a.push(s.description)),s.screenshot){const o=await t(s.screenshot,e.screenshotMode,e.focusColor);r.push(`<p><img src="${o.dataUrl}" alt="${Te(`${i.step} ${s.stepNumber}`)}" style="max-width:100%;height:auto"></p>`)}s.narration&&(r.push(`<p><strong>${i.narration}:</strong> ${Te(s.narration)}</p>`),a.push(`${i.narration}: ${s.narration}`)),r.push("</section>")}return r.push("</article>"),{html:r.join(""),text:a.join(`
`).replace(/^\n+/,"")}}async function co(e,t=ri,n={}){var r;if(!((r=navigator.clipboard)!=null&&r.write)||typeof ClipboardItem>"u")throw new Error("Rich clipboard is unavailable");const i=lo(e,t,n);await navigator.clipboard.write([new ClipboardItem({"text/html":i.then(a=>new Blob([a.html],{type:"text/html"})),"text/plain":i.then(a=>new Blob([a.text],{type:"text/plain"}))})])}function uo(e){const t=e.indexOf(",");if(t<0)return 0;const n=e.slice(0,t),i=e.slice(t+1);if(!/;base64/i.test(n))try{return new TextEncoder().encode(decodeURIComponent(i)).byteLength}catch{return i.length}const r=i.replace(/\s/g,""),a=r.endsWith("==")?2:r.endsWith("=")?1:0;return Math.max(0,Math.floor(r.length*3/4)-a)}function po(e){return e==="en"?{source:"Source",purpose:"Purpose",summary:"Summary",step:"Step",narration:"Narration"}:{source:"来源",purpose:"目的",summary:"操作概要",step:"步骤",narration:"口播稿"}}function Te(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}const fo={selectedStepIndexes:[],includeSummary:!0,includeSource:!1,includeScreenshots:!0,includeNarration:!1,screenshotMode:"annotated",themeColor:"#2563eb",focusColor:"",focusShape:"circle"};function ho(e,t={}){var s,o,c,d;const n={...fo,...t},i=e.language,r=n.selectedStepIndexes.length>0?new Set(n.selectedStepIndexes):new Set(e.steps.map((u,x)=>x)),a=e.steps.flatMap((u,x)=>{var z,E,D,R;if(!r.has(x))return[];const f=n.includeScreenshots&&u.screenshotId?e.screenshots.find(O=>O.id===u.screenshotId):void 0,m=u,T=((z=m.voiceScript)==null?void 0:z.trim())||((E=m.generatedVoiceScript)==null?void 0:E.trim());return[{sourceIndex:x,stepNumber:u.stepNumber,title:u.title.trim(),description:u.description.trim(),narration:n.includeNarration&&T?T:void 0,screenshot:f?{dataUrl:f.maskedDataUrl||f.dataUrl,focus:u.focus?{...u.focus,shape:u.focus.shape??n.focusShape}:void 0,additionalFocuses:(D=u.additionalFocuses)==null?void 0:D.map(O=>({...O,shape:O.shape??n.focusShape})),annotations:(R=u.annotations)==null?void 0:R.map(O=>({...O}))}:void 0}]});return{language:n.language??i??Ne,title:e.title.trim()||((n.language??i)==="en"?"Untitled guide":"未命名文档"),sourceUrl:n.includeSource&&e.url?e.url:void 0,purpose:n.includeSummary&&((o=(s=e.outline)==null?void 0:s.purpose)==null?void 0:o.trim())||void 0,summary:n.includeSummary&&((d=(c=e.outline)==null?void 0:c.summary)==null?void 0:d.trim())||void 0,steps:a,screenshotMode:n.screenshotMode,focusColor:Ot(n.themeColor,n.focusColor),focusShape:n.focusShape}}function oi(e,t){const n=[...t].sort((i,r)=>i.startedAt-r.startedAt);return n.length===0?[]:e.map((i,r)=>{const a=go(i.timestamp,n),s=typeof a.endedAt=="number"?Math.max(0,a.endedAt-a.startedAt):Number.POSITIVE_INFINITY;return{stepIndex:r,segmentId:a.id,startMs:Math.min(s,Math.max(0,i.timestamp-a.startedAt))}})}function mo(e,t,n){const i=e.filter(a=>a.segmentId===t);if(i.length===0)return null;let r=i[0];for(const a of i){if(a.startMs>n)break;r=a}return r.stepIndex}function go(e,t){const n=t.find(i=>e>=i.startedAt&&(typeof i.endedAt!="number"||e<=i.endedAt));return n||t.reduce((i,r)=>yn(e,r)<yn(e,i)?r:i)}function yn(e,t){return e<t.startedAt?t.startedAt-e:typeof t.endedAt=="number"&&e>t.endedAt?e-t.endedAt:0}async function xo(e,t,n){const i=new Map(n.map(o=>[o.segment.id,o])),r=oi(e.steps,t.videoManifest??[]),a=[];for(const o of t.videoManifest??[]){const c=i.get(o.id);!c||c.blob.size===0||a.push({id:o.id,src:await bo(c.blob,o.mimeType||"video/webm"),cues:r.filter(d=>d.segmentId===o.id).map(d=>{var x,f;const u=e.steps[d.stepIndex];return{stepNumber:u.stepNumber,startMs:d.startMs,title:u.title,text:((x=u.voiceScript)==null?void 0:x.trim())||((f=u.generatedVoiceScript)==null?void 0:f.trim())||u.description||u.title}})})}if(a.length===0)throw new Error("No saved video segment is available for tutorial export");const s=We.getFilename(e,"html").replace(/\.html$/i,"")||"tutorial";return{content:yo(e,a),filename:`${s}-video-tutorial.html`,mimeType:"text/html"}}async function bo(e,t){const n=new Uint8Array(await e.arrayBuffer());let i="";for(let r=0;r<n.length;r+=32768)i+=String.fromCharCode(...n.subarray(r,r+32768));return`data:${e.type||t};base64,${btoa(i)}`}function yo(e,t){const n=e.language==="en",i=n?{eyebrow:"StepMark video tutorial",voice:"Google voice",automatic:"Automatic (recommended)",segment:"Segment",step:"Step",contents:"Tutorial contents",jump:"Jump to"}:{eyebrow:"StepMark 视频教程",voice:"Google 音色",automatic:"自动选择（推荐）",segment:"片段",step:"步骤",contents:"教程目录",jump:"跳转到"},r=vo({language:n?"en-US":"zh-CN",videos:t,copy:{segment:i.segment,step:i.step,contents:i.contents,jump:i.jump}});return`<!doctype html>
<html lang="${n?"en":"zh-CN"}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${vn(e.title)}</title>
  <style>
    *{box-sizing:border-box}body{margin:0;background:#f3f7f6;color:#172033;font:15px/1.55 system-ui,-apple-system,sans-serif}.page{width:min(1180px,calc(100% - 32px));margin:auto;padding:28px 0 56px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;flex-wrap:wrap;margin-bottom:16px}.eyebrow{color:#1d4ed8;font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}h1{margin:4px 0 0;font-size:clamp(24px,4vw,36px);line-height:1.2}.tools{display:flex;align-items:end;gap:10px;flex-wrap:wrap}.tools label{display:grid;gap:5px;color:#667085;font-size:12px;font-weight:700}.tools select{min-height:38px;border:1px solid #d8e2df;border-radius:7px;background:#fff;color:#172033;padding:7px 11px;font:inherit;font-weight:700}.tutorial{display:grid;grid-template-columns:minmax(220px,280px) minmax(0,1fr);gap:16px;align-items:start}.stage{min-width:0}.chapters{position:sticky;top:16px;max-height:calc(100vh - 32px);overflow:auto;padding:10px;border:1px solid #dfe8e5;border-radius:8px;background:#fff}.chapters-title{padding:4px 5px 10px;border-bottom:1px solid #e7eeec;color:#667085;font-size:12px;font-weight:800;letter-spacing:.06em;text-transform:uppercase}.chapters ol{display:grid;gap:5px;margin:8px 0 0;padding:0;list-style:none}.chapter{display:grid;grid-template-columns:28px minmax(0,1fr);gap:8px;width:100%;min-height:56px;padding:8px 9px;border:1px solid transparent;border-radius:7px;background:transparent;color:#172033;text-align:left;cursor:pointer;font:inherit}.chapter:hover{background:#eff6ff}.chapter.active{border-color:#bfdbfe;background:#eff6ff}.chapter-number{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:#eef3f2;color:#667085;font-size:11px;font-weight:800}.chapter.active .chapter-number{background:#2563eb;color:#fff}.chapter-title{display:block;overflow:hidden;font-size:12px;font-weight:750;line-height:1.35;text-overflow:ellipsis;white-space:nowrap}.chapter-meta{display:block;margin-top:4px;color:#667085;font-size:10px}.player{position:relative;background:#0f172a;border-radius:8px;overflow:hidden;box-shadow:0 18px 48px -30px #0f172a}.player video{display:block;width:100%;max-height:72vh;background:#0f172a}.player video::-webkit-media-controls-mute-button,.player video::-webkit-media-controls-volume-slider,.player video::-webkit-media-controls-volume-slider-container{display:none!important}.caption{position:absolute;left:5%;right:5%;bottom:58px;text-align:center;pointer-events:none}.caption span{display:inline-block;max-width:900px;padding:9px 14px;border-radius:6px;background:rgba(15,23,42,.82);color:#fff;font-size:clamp(15px,2vw,20px);line-height:1.45}.status{display:flex;justify-content:space-between;gap:12px;padding:11px 14px;background:#fff;border:1px solid #dfe8e5;border-top:0;border-radius:0 0 8px 8px;color:#667085;font-size:13px}@media(max-width:820px){.tutorial{grid-template-columns:minmax(0,1fr)}.stage{order:1}.chapters{position:static;order:2;max-height:300px}}@media(max-width:600px){.page{width:min(100% - 20px,1180px);padding-top:18px}.caption{bottom:48px}.status{display:grid}.tools{width:100%}.tools label{flex:1}.tools select{width:100%}}
  </style>
</head>
<body><main class="page">
  <div class="head"><div><div class="eyebrow">${i.eyebrow}</div><h1>${vn(e.title)}</h1></div><div class="tools"><label><span>${i.voice}</span><select id="voice"><option value="">${i.automatic}</option></select></label></div></div>
  <div class="tutorial">
    <aside class="chapters" aria-label="${i.contents}"><div class="chapters-title">${i.contents}</div><ol id="chapters"></ol></aside>
    <div class="stage"><div class="player"><video id="video" controls playsinline preload="metadata"></video><div class="caption"><span id="caption"></span></div></div>
    <div class="status"><span id="segment"></span><span id="step"></span></div></div>
  </div>
</main>
<script>
const DATA=${r};
const synth=window.speechSynthesis||null;
// NOTE: these two helpers are inlined as literals on purpose. Build minifiers
// rename module-scope functions, which breaks any toString() injection —
// the exported HTML must stay self-contained. Keep in sync with
// voiceScore / narrationWatchdogMs in src/core/voice/SpeechQueue.ts.
function voiceScore(voice){return (/^Google\\b/i.test(voice.name||"")?0:100)+(voice.localService?2:0)+(voice.default?1:0)}
function narrationWatchdogMs(text){return Math.min(15000,2000+300*text.length)}
const video=document.getElementById('video'),caption=document.getElementById('caption'),segmentLabel=document.getElementById('segment'),stepLabel=document.getElementById('step'),voiceSelect=document.getElementById('voice'),chapterList=document.getElementById('chapters');
let segmentIndex=0,lastCueKey='',narrating=false,continueAfterNarration=false,tutorialPaused=false,tutorialStarted=false,narrationGeneration=0,activeUtterance=null;
function matchingVoices(){if(!synth)return[];const base=DATA.language.split('-')[0].toLowerCase();return synth.getVoices().filter(v=>v.lang.toLowerCase().startsWith(base+'-')).sort((a,b)=>voiceScore(b)-voiceScore(a))}
function refreshVoices(){const current=voiceSelect.value;voiceSelect.querySelectorAll('option:not(:first-child)').forEach(o=>o.remove());matchingVoices().forEach(v=>{const o=document.createElement('option');o.value=v.name;o.textContent=v.name+' ('+v.lang+')';voiceSelect.appendChild(o)});if([...voiceSelect.options].some(o=>o.value===current))voiceSelect.value=current}
if(synth)synth.addEventListener('voiceschanged',refreshVoices);refreshVoices();
function selectedVoice(){const voices=matchingVoices();return voices.find(v=>v.name===voiceSelect.value)||voices[0]||null}
function currentCue(){const cues=DATA.videos[segmentIndex].cues;let active=cues[0]||null;for(const cue of cues){if(cue.startMs>video.currentTime*1000)break;active=cue}return active}
function cueKey(cue){return cue?segmentIndex+':'+cue.stepNumber:''}
function updateActiveChapter(cue){const key=cueKey(cue);chapterList.querySelectorAll('.chapter').forEach(button=>{const active=button.dataset.key===key;button.classList.toggle('active',active);if(active){button.setAttribute('aria-current','step');button.scrollIntoView({block:'nearest'})}else button.removeAttribute('aria-current')})}
function renderCue(cue){if(!cue){caption.textContent='';stepLabel.textContent='';updateActiveChapter(null);return}caption.textContent=cue.text;stepLabel.textContent=DATA.copy.step+' '+cue.stepNumber;updateActiveChapter(cue)}
function cancelNarration(){narrationGeneration+=1;activeUtterance=null;narrating=false;if(synth&&(synth.speaking||synth.pending||synth.paused))synth.cancel()}
function speakCue(cue){if(!cue)return false;const key=segmentIndex+':'+cue.stepNumber;if(key===lastCueKey)return narrating;lastCueKey=key;renderCue(cue);if(!synth||typeof SpeechSynthesisUtterance==='undefined')return false;if(synth.getVoices().length===0)return false;if(synth.speaking||synth.pending||synth.paused)cancelNarration();if(synth.paused)synth.resume();const generation=++narrationGeneration,utterance=new SpeechSynthesisUtterance(cue.text),voice=selectedVoice();utterance.lang=DATA.language;utterance.rate=1;if(voice)utterance.voice=voice;activeUtterance=utterance;narrating=true;video.pause();let watchdog=null;const resume=()=>{if(generation!==narrationGeneration||!narrating)return;if(watchdog){clearTimeout(watchdog);watchdog=null}activeUtterance=null;narrating=false;if(continueAfterNarration&&!tutorialPaused)video.play().catch(()=>{})};watchdog=setTimeout(()=>{if(generation!==narrationGeneration)return;try{synth.cancel()}catch(error){}resume()},narrationWatchdogMs(cue.text));utterance.onend=resume;utterance.onerror=resume;try{synth.speak(utterance);return true}catch(error){resume();return false}}
function seekAndPlay(startMs,cue){const target=Math.max(0,startMs/1000),play=()=>{if(cue)renderCue(cue);video.play().catch(()=>{})};if(Math.abs(video.currentTime-target)<.01){play();return}video.addEventListener('seeked',play,{once:true});video.currentTime=target}
function loadSegment(index,autoplay=false,startMs=0,selectedCue=null){segmentIndex=index;lastCueKey='';cancelNarration();const item=DATA.videos[index];video.src=item.src;video.addEventListener('loadedmetadata',()=>{if(autoplay)seekAndPlay(startMs,selectedCue);else{const target=Math.max(0,startMs/1000);if(Math.abs(video.currentTime-target)>=.01)video.currentTime=target;if(selectedCue)renderCue(selectedCue)}},{once:true});video.load();segmentLabel.textContent=DATA.copy.segment+' '+(index+1)+' / '+DATA.videos.length;renderCue(selectedCue||item.cues[0]||null)}
function formatTime(ms){const total=Math.max(0,Math.floor(ms/1000));return Math.floor(total/60)+':'+String(total%60).padStart(2,'0')}
function jumpToCue(videoIndex,cueIndex){const cue=DATA.videos[videoIndex]?.cues[cueIndex];if(!cue)return;tutorialPaused=false;tutorialStarted=true;continueAfterNarration=true;lastCueKey='';cancelNarration();if(videoIndex!==segmentIndex){loadSegment(videoIndex,true,cue.startMs,cue);return}seekAndPlay(cue.startMs,cue)}
function renderChapters(){DATA.videos.forEach((item,videoIndex)=>item.cues.forEach((cue,cueIndex)=>{const li=document.createElement('li'),button=document.createElement('button'),number=document.createElement('span'),body=document.createElement('span'),title=document.createElement('span'),meta=document.createElement('span');button.type='button';button.className='chapter';button.dataset.key=videoIndex+':'+cue.stepNumber;button.setAttribute('aria-label',DATA.copy.jump+' '+DATA.copy.step+' '+cue.stepNumber+': '+cue.title);number.className='chapter-number';number.textContent=cue.stepNumber;title.className='chapter-title';title.textContent=cue.title;meta.className='chapter-meta';meta.textContent=DATA.copy.segment+' '+(videoIndex+1)+' · '+formatTime(cue.startMs);body.append(title,meta);button.append(number,body);button.addEventListener('click',()=>jumpToCue(videoIndex,cueIndex));li.appendChild(button);chapterList.appendChild(li)}))}
video.addEventListener('pointerdown',()=>{if(!tutorialStarted&&video.paused&&!narrating){tutorialStarted=true;tutorialPaused=false;continueAfterNarration=true;speakCue(currentCue())}});
video.addEventListener('play',()=>{tutorialStarted=true;tutorialPaused=false;continueAfterNarration=true;if(speakCue(currentCue()))video.pause()});
video.addEventListener('pause',()=>{if(!narrating){tutorialPaused=true;continueAfterNarration=false}});
video.addEventListener('timeupdate',()=>speakCue(currentCue()));
video.addEventListener('seeking',()=>{lastCueKey='';cancelNarration()});
video.addEventListener('ended',()=>{if(segmentIndex<DATA.videos.length-1)loadSegment(segmentIndex+1,true);else{continueAfterNarration=false;tutorialStarted=false;tutorialPaused=false}});
window.addEventListener('beforeunload',cancelNarration);
renderChapters();
loadSegment(0);
<\/script></body></html>`}function vo(e){return JSON.stringify(e).replace(/</g,"\\u003c").replace(/>/g,"\\u003e")}function vn(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}const wo=new Set(["click","change","input","selection","navigation","keypress"]),wn=30;function So(e,t="zh",n={}){const i=n.domainProfile??"generic",r=e.screenshots||[],{events:a,truncatedSteps:s}=$o(e.events||[],i),o=ko(r,a),c=o?1:0;let d=a.map((x,f)=>Ho(x,f+c,r,e,t));if(o&&d.length>0&&(d=[Mo(o,e,t),...d]),d.length===0)return{id:`guide-${e.id}`,language:t,title:e.title||`Guide - ${new Date(e.startedAt).toLocaleString()}`,createdAt:Date.now(),steps:[],screenshots:r,url:e.url,duration:e.endedAt?e.endedAt-e.startedAt:0,documentStatus:"capture_failed",captureFailureReason:t==="zh"?"未提取到可用操作步骤:可能未捕获到点击/输入事件,或所捕获事件被判定为噪声。请确认录制在该页面正常工作后重试。":"No usable interaction steps could be extracted: either no clicks/inputs were captured, or all captured events were filtered as noise. Verify recording works on this page and retry."};const u=la(e,d,t,i);return{id:`guide-${e.id}`,language:t,title:e.title||`Guide - ${new Date(e.startedAt).toLocaleString()}`,createdAt:Date.now(),steps:d,screenshots:r,url:e.url,duration:e.endedAt?e.endedAt-e.startedAt:0,outline:u,documentStatus:"rule_draft",truncatedSteps:s>0?s:void 0}}function ko(e,t){if(e.length===0||t.length===0)return;const n=e.find(r=>r.captureReason==="initial");if(n)return n;const i=t[0].timestamp;return e.filter(r=>r.timestamp<=i).sort((r,a)=>r.timestamp-a.timestamp)[0]}function Mo(e,t,n){return n==="zh"?{stepNumber:1,title:"查看起始页面",description:`确认“${t.title||"当前页面"}”的起始界面。`,voiceScript:"确认起始页面已加载完成，然后开始后续操作。",generatedVoiceScript:"确认起始页面已加载完成，然后开始后续操作。",voiceoverMode:"original",actionType:"initial_screen",screenshotId:e.id,timestamp:e.timestamp}:{stepNumber:1,title:"Review the starting page",description:`Confirm the starting screen for ${t.title||"this workflow"}.`,voiceScript:"Confirm that the starting page is ready before continuing.",generatedVoiceScript:"Confirm that the starting page is ready before continuing.",voiceoverMode:"original",actionType:"initial_screen",screenshotId:e.id,timestamp:e.timestamp}}function $o(e,t){const n=e.filter(s=>wo.has(s.type)).filter(s=>!No(s)).sort((s,o)=>s.timestamp-o.timestamp),i=[];for(const s of n){const o=i[i.length-1];if(o&&Uo(o,s)){i[i.length-1]=Fo(o,s);continue}if(o&&Bo(o,s)){i[i.length-1]=Sn(o,s);continue}o&&Do(o,s)?i[i.length-1]=Sn(o,s):i.push(s)}const r=t==="cdp"?To(Co(i)):i,a=Math.max(0,r.length-wn);return{events:r.slice(0,wn).map((s,o)=>({...s,timestamp:s.timestamp||Date.now()+o})),truncatedSteps:a}}function Co(e){const t=new Set,n=[];for(let i=0;i<e.length;i+=1){if(t.has(i))continue;const r=Ao(e,i,t);if(r){n.push(r);continue}const a=Eo(e,i,t);if(a){n.push(a);continue}const s=zo(e,i,t);if(s){n.push(s);continue}n.push(e[i])}return n}function To(e){if(!e.some(r=>{const a=`${de(r)} ${r.nearbyText||""}`;return/创建分群|分群主体|用户历史行为|线下购物|门店名称|消费金额|分群名称/.test(a)}))return e;const n=new Set,i=[];for(let r=0;r<e.length;r+=1){if(n.has(r))continue;const a=e[r],s=de(a);if(/^选择行为数据源|^添加筛选条件|^设置统计条件/.test(a.semanticTitle||"")){i.push(a),n.add(r);continue}if(a.controlAction==="select"&&/分群主体/.test(a.controlLabel||"")&&/C端用户/.test(a.selectedOption||s)){const o=Fe(e,r+1,n,c=>/确定/.test(de(c)),5e3);n.add(r),o>=0&&n.add(o),i.push(je([a,o>=0?e[o]:void 0].filter(Boolean),"选择分群主体“C端用户”","在创建弹窗中选择分群主体「C端用户」，并确认创建。"));continue}if(/最近\d+天|做过/.test(s)){const o=/做过/.test(s)?r:Fe(e,r+1,n,c=>/做过/.test(de(c)),5e3);n.add(r),o>=0&&n.add(o),i.push(je([a,o>=0?e[o]:void 0].filter(Boolean),"设置行为时间和关系","设置行为时间范围和行为关系，例如「最近1天」内「做过」指定行为。"));continue}if(/行为事件|浏览商品|用户历史行为|线下购物/.test(`${s} ${a.innerText||""} ${a.nearbyText||""}`)){const o=Fe(e,r+1,n,c=>/门店名称/.test(de(c)),8e3);if(n.add(r),o>=0&&n.add(o),i.push(je([a,o>=0?e[o]:void 0].filter(Boolean),"选择行为数据源“用户历史行为 > 线下购物”","在规则配置中选择行为数据源「用户历史行为 > 线下购物」。")),o>=0){const c=Fe(e,o+1,n,si,5e3);c>=0&&(n.add(c),i.push(je([e[o],e[c]],`添加筛选条件“门店名称 = ${de(e[c])}”`,`添加筛选条件：选择属性「门店名称」，并选择目标值「${de(e[c])}」。`)))}continue}if(a.type==="input"&&/分群名称|分群描述/.test(a.nearbyText||"")){const o=ai(e,r,n,3e3).filter(c=>c.event.type==="input"&&/分群名称|分群描述/.test(c.event.nearbyText||""));for(const c of o)n.add(c.index);i.push(je(o.map(c=>c.event),"填写分群基础信息","填写分群名称、描述等基础信息，用于保存并识别该用户分群。"));continue}i.push(a)}return jo(i.filter(r=>{const a=`${r.semanticTitle||""} ${de(r)}`;return!(/实时 凯德星商城小程序/.test(a)||/input arco-input/i.test(a)||/(快捷选择|天数)/.test(r.semanticTitle||de(r)))}))}function jo(e){const t=new Set,n=[];for(const i of e){const r=K(i.semanticTitle||"");if(/^选择行为数据源|^设置行为时间和关系/.test(r)){if(t.has(r))continue;t.add(r)}n.push(i)}return n}function Ao(e,t,n){const i=e[t],r=de(i),a=K(i.controlLabel||"");if(/用户历史行为|行为数据源/.test(a)&&i.selectedOption)return n.add(t),je([i],`选择行为数据源“${a} > ${i.selectedOption}”`,`在规则配置中选择行为数据源「${a} > ${i.selectedOption}」。`);if(!/用户历史行为|行为数据源/.test(r))return null;const s=Io(r),o=s?-1:Fe(e,t+1,n,u=>{const x=de(u);return/线下购物|线上购物|会员活动|停车缴费|行为/.test(x)},8e3);if(!s&&o<0)return null;const c=Bt(r,"用户历史行为"),d=s||Bt(de(e[o]),"线下购物");return n.add(t),o>=0&&n.add(o),je([i,o>=0?e[o]:void 0].filter(Boolean),`选择行为数据源“${c} > ${d}”`,`在规则配置中选择行为数据源「${c} > ${d}」。`)}function Io(e){return/线下购物/.test(e)?"线下购物":/线上购物/.test(e)?"线上购物":/会员活动/.test(e)?"会员活动":/停车缴费/.test(e)?"停车缴费":""}function Eo(e,t,n){const i=e[t];if(!/添加筛选|筛选条件|添加条件/.test(de(i)))return null;const r=ai(e,t,n,12e3),a=r.find(f=>Ro(f.event)),s=r.find(f=>a&&f.index<=a.index?!1:si(f.event));if(!a&&!s)return null;const o=a?de(a.event):"筛选字段",c=s?de(s.event):"",d=c?`添加筛选条件“${o} = ${c}”`:`添加筛选条件“${o}”`,u=c?`添加筛选条件：选择属性「${o}」，并选择目标值「${c}」。`:`添加筛选条件：选择属性「${o}」。`,x=(s==null?void 0:s.index)??(a==null?void 0:a.index)??t;for(const f of r)f.index<=x&&n.add(f.index);return je([i,a==null?void 0:a.event,s==null?void 0:s.event].filter(Boolean),d,u)}function zo(e,t,n){const i=e[t],r=de(i),a=K(i.controlLabel||r);if(!/总次数|次数|金额|消费金额/.test(a))return null;const s=i.controlAction==="select"&&i.selectedOption?t:Fe(e,t+1,n,x=>/≥|>=|大于等于|等于|>|小于|≤|<=/.test(de(x)),8e3),o=Fe(e,t+1,n,x=>x.type==="input"&&/\d/.test(x.value||""),8e3);if(o<0)return null;const c=s>=0?Lo(de(e[s])):"≥",d=K(e[o].value||de(e[o])),u=Bt(a,"总次数");return n.add(t),s>=0&&n.add(s),n.add(o),je([i,s>=0?e[s]:void 0,e[o]].filter(Boolean),`设置统计条件“${u} ${c} ${d}”`,`设置统计条件「${u} ${c} ${d}」。`)}function je(e,t,n){const i=e[0],r=e[e.length-1]||i;return{...r,id:`${i.id}-semantic`,selector:i.selector,label:t,innerText:t,semanticTitle:t,semanticDescription:n,semanticVoiceScript:n,timestamp:r.timestamp}}function ai(e,t,n,i){const r=e[t].timestamp,a=[];for(let s=t;s<e.length;s+=1)if(!n.has(s)){if(e[s].timestamp-r>i)break;a.push({index:s,event:e[s]})}return a}function Fe(e,t,n,i,r){var s,o;const a=((s=e[t-1])==null?void 0:s.timestamp)||((o=e[t])==null?void 0:o.timestamp)||0;for(let c=t;c<e.length;c+=1)if(!n.has(c)){if(e[c].timestamp-a>r)break;if(i(e[c]))return c}return-1}function Ro(e){const t=de(e);return!t||/添加筛选|请选择|搜索|输入/.test(t)?!1:/(?:门店名称|门店ID|品牌名称|品类|属性|字段|标签|名称|ID|类型)$/.test(t)}function si(e){const t=de(e);return!t||/添加筛选|请选择|门店名称|字段|属性/.test(t)?!1:/>>|广场|门店|店|会员|用户|品牌|商场|中心|Mall|mall/.test(t)}function de(e){return e.semanticTitle?K(e.semanticTitle):e.controlAction==="select"?K(e.selectedOption||""):e.type==="input"?K(e.value||e.label||e.placeholder||""):K(e.label||e.innerText||e.value||"")}function Bt(e,t){const n=li(e);return!n||n.includes(t)?t:n}function Lo(e){return/大于等于|>=|≥/.test(e)?"≥":/小于等于|<=|≤/.test(e)?"≤":/等于|=/.test(e)?"=":/大于|>/.test(e)?">":/小于|</.test(e)?"<":e}function No(e){if(e.type==="keypress"&&e.value!=="Enter"||e.type==="input"&&!_o(e)||e.type==="selection"&&!K(e.value||e.innerText||""))return!0;if(e.type==="click"){const t=qt(e);if(!t||!e.role&&!["button","a","input","textarea","select"].includes(e.tagName||"")&&!Po(e,t))return!0}return!1}function Po(e,t){return!e.coordinates&&!e.rect||!t||t.length>40||/控制台|个人中心|退出登录|使用指南|API 文档|常见问题/.test(t)&&t.length>12?!1:!!K(e.label||e.innerText||e.value||"")}function _o(e){return e.tagName==="textarea"?!0:e.tagName!=="input"?!1:!["radio","checkbox","button","submit","reset","hidden","file"].includes(e.elementType||"text")}function Do(e,t){return e.type!==t.type||e.selector!==t.selector||t.timestamp-e.timestamp>1500?!1:t.type==="input"||t.type==="keypress"||t.type==="click"}function Bo(e,t){return e.type!=="selection"||t.type!=="selection"||t.timestamp-e.timestamp>3e3?!1:K(e.value||e.innerText||"")===K(t.value||t.innerText||"")}function Sn(e,t){return{...e,...t,value:t.value??e.value,innerText:t.innerText??e.innerText,timestamp:t.timestamp}}function Uo(e,t){return e.type!=="click"||t.type!=="click"||t.timestamp-e.timestamp>3e3?!1:e.role==="combobox"&&t.role==="option"?!0:t.role==="option"&&Oo(e)}function Fo(e,t){const n=Wo(e);return{...t,selector:e.selector,role:"combobox",label:e.label||e.innerText,controlAction:"select",controlLabel:n,selectedOption:li(t.label||t.innerText||t.value||"")}}function Wo(e){const t=Qo(e.label||e.innerText||""),n=Jo(e.nearbyText||"",t);return n&&Zo(t)?n:t||n}function Oo(e){const t=qt(e);return t?/[：:]/.test(t)?!0:e.role==="button"&&/选择|深度|模式|类型|模型|月份|选项/.test(t):!1}function Ho(e,t,n,i,r){var d;const a=qt(e),s=Ko(e,i),o=(d=oa(e,n))==null?void 0:d.id,c=Xo(e,a,s,r);return{stepNumber:t+1,title:Go(e,a,r),description:Yo(e,a,s,r),voiceScript:c,generatedVoiceScript:c,voiceoverMode:"original",actionType:e.type,selector:e.selector,focus:Vo(e),screenshotId:o,timestamp:e.timestamp}}function Vo(e){var n,i;const t=e.controlAction==="select"?"select":e.type==="click"||e.type==="input"||e.type==="selection"?e.type:"generic";if(!(!e.coordinates&&!e.rect))return{type:t,x:(n=e.coordinates)==null?void 0:n.x,y:(i=e.coordinates)==null?void 0:i.y,rect:e.rect,viewport:e.viewport,devicePixelRatio:e.devicePixelRatio}}function Go(e,t,n){return Xt(e.semanticTitle,n)?e.semanticTitle:n==="zh"?e.controlAction==="select"?`选择${e.controlLabel||"选项"}“${e.selectedOption||t}”`:Kt(e)?t?`跳转到“${t}”`:"跳转到页面区块":e.type==="click"?t?`点击“${t}”`:"点击目标元素":e.type==="input"?t?`填写${ia(t)}`:"填写必填信息":e.type==="selection"?t?`选中文本“${t}”`:"选中页面文本":e.type==="keypress"?e.value==="Enter"?"按下 Enter":`按下${e.value||"指定按键"}`:"进入下一页面":e.controlAction==="select"?`Select ${e.selectedOption||t} in ${e.controlLabel||"the dropdown"}`:e.type==="click"?t?`Click "${t}"`:"Click the highlighted element":e.type==="input"?t?`Enter ${t}`:"Enter the required value":e.type==="selection"?t?`Select the text "${t}"`:"Select text on the page":e.type==="keypress"?e.value==="Enter"?"Press Enter":`Press ${e.value||"the key"}`:"Navigate to the next page"}function Yo(e,t,n,i){if(Xt(e.semanticDescription,i))return e.semanticDescription;if(i==="zh"){if(e.controlAction==="select")return`在${e.controlLabel||"当前"}下拉框中选择「${e.selectedOption||t}」。`;if(e.type==="click"){if(Kt(e))return t?`在页面目录中打开“${t}”区块。`:"在页面目录中打开目标区块。";const a=qo(e.role);return t?`在页面中选择${a||"目标"}“${t}”。`:"在页面中选择当前高亮的目标元素。"}return e.type==="input"?t?`在“${t}”中填写所需信息。`:"在当前输入框中填写所需信息。":e.type==="selection"?t?`在页面中圈选文本“${t}”。`:"在页面中圈选需要关注的文本内容。":e.type==="keypress"?e.value==="Enter"?"按下 Enter 提交当前内容或继续下一步。":`按下${e.value||"录制中的按键"}继续操作。`:"等待页面跳转或内容更新。"}const r=n?` in ${n}`:"";if(e.controlAction==="select")return`In the dropdown, select "${e.selectedOption||t}" for ${e.controlLabel||"the field"}.`;if(e.type==="click"){const a=e.role&&e.role!=="generic"?` ${e.role}`:"";return t?`Select the${a} labeled "${t}"${r}.`:`Select the target element${r}.`}return e.type==="input"?t?`Fill in "${t}"${r}.`:`Fill in the active field${r}.`:e.type==="selection"?t?`Select the text "${t}"${r}.`:`Select the relevant text${r}.`:e.type==="keypress"?e.value==="Enter"?`Press Enter to submit or continue${r}.`:`Use the ${e.value||"recorded"} key to continue${r}.`:`Wait for the page to navigate or update${r}.`}function Xo(e,t,n,i){if(Xt(e.semanticVoiceScript,i))return e.semanticVoiceScript;if(i==="zh")return e.controlAction==="select"?`在${e.controlLabel||"当前"}下拉框中选择「${e.selectedOption||t}」。`:e.type==="click"?Kt(e)?t?`打开“${t}”区块。`:"打开页面中的目标区块。":t?`点击“${t}”。`:"点击当前需要操作的页面元素。":e.type==="input"?t?`在“${t}”中填写所需信息。`:"填写当前步骤需要的信息。":e.type==="selection"?t?`圈选文本“${t}”。`:"圈选页面中需要关注的文本内容。":e.type==="keypress"?e.value==="Enter"?"按下 Enter，确认当前操作。":`按下${e.value||"指定按键"}，继续当前流程。`:"页面将进入下一步。请等待新页面或新内容加载完成后再继续操作。";const r=n?` in ${n}`:"";return e.controlAction==="select"?`In the dropdown, select ${e.selectedOption||t} for ${e.controlLabel||"the field"}, then confirm the selected value before continuing.`:e.type==="click"?t?`Click ${t}${r}. Then wait for the page to respond before moving on.`:`Click the highlighted item${r}. Then wait for the page to respond.`:e.type==="input"?t?`Enter the required information in ${t}${r}. Check the value before continuing.`:`Enter the required information${r}. Check the value before continuing.`:e.type==="selection"?t?`Select the text ${t}${r}.`:`Select the relevant text${r}.`:e.type==="keypress"?e.value==="Enter"?`Press Enter to confirm this step${r}.`:`Press ${e.value||"the recorded key"} to continue${r}.`:"The workflow navigates to the next page. Wait until the new screen finishes loading."}function Xt(e,t){if(!e)return!1;const n=/[\u3400-\u9fff]/.test(e);return t==="zh"?n:!n}function qo(e){return e&&{button:"按钮",link:"链接",textbox:"输入框",combobox:"下拉选择框",tab:"标签页",checkbox:"复选框",radio:"单选项",menu:"菜单",dialog:"弹窗"}[e]||""}function qt(e){if(e.type==="selection")return K(e.value||e.innerText||"");if(e.type==="input")return ea(e);const t=[e.label,e.innerText,e.placeholder,e.value];return K(t.find(n=>K(n||""))||"")}function Ko(e,t){const n=[e.nearbyText,e.pageTitle,t.title],i=K(n.find(r=>K(r||""))||"");return i.length>80?`${i.slice(0,77)}...`:i}function K(e){return e.replace(/\s+/g," ").replace(/[|→]+/g," ").trim().slice(0,80)}function Qo(e){var n;const t=K(e);return((n=t.split(/[：:]/)[0])==null?void 0:n.trim())||t}function Zo(e){const t=K(e);return!t||/^(请选择|选择|全部|默认|基准|无)$/.test(t)?!0:t.length<=2}function Jo(e,t){const n=K(e);if(!n)return"";const i=K(t),r=i&&n.includes(i)?n.slice(0,n.indexOf(i)).trim():n,a=r.split(/\s+/).filter(Boolean),o=[...a.length>0?a:[r]].reverse().find(c=>/(?:类型|名称|字段|方式|模式|分组|范围|条件|ID|Id|id)$/.test(c));return pt(o||"")}function li(e){const t=K(e);if(!t)return"";const n=t.match(/^(.+?)(?:\s+(?:适合|用于|支持|开启|关闭|快速|深度|中\s|低\s|高\s))/);if(n!=null&&n[1])return n[1].trim();const[i]=t.split(/\s+/);return i&&i.length<=12&&t.length>i.length?i:t}function pt(e){return K(e).replace(/[：:].*$/,"").replace(/^请选择/,"").replace(/^请输入/,"").trim()}function ea(e){const t=pt(e.label||"");if(t)return t;const n=na(e.nearbyText||"",e.placeholder||e.value||"");if(n)return n;const i=pt(e.placeholder||"");return i&&!ta(i)?i:K(ra(e.selector))}function ta(e){return/^≤?\d+字符$|^请输入|^请选择|^input\b/i.test(K(e))}function na(e,t){const n=K(e);if(!n)return"";const i=K(t),s=[...(i&&n.includes(i)?n.slice(0,n.indexOf(i)).trim():n).split(/\s+/).filter(Boolean)].reverse().find(o=>/(?:名称|描述|主体|类型|字段|备注|标签|条件)$/.test(o));return pt(s||"")}function ia(e){return/^[A-Za-z0-9]/.test(e)?` ${e}`:e}function ra(e){var n;return e?(((n=e.split(">").pop())==null?void 0:n.trim())||e).replace(/:nth-child\(\d+\)/g,"").replace(/[#.]/g," ").replace(/\[[^\]]+\]/g,"").trim():""}function oa(e,t){if(ci(e)){const n=sa(e.timestamp,t,5e3);if(n)return n}return aa(e.timestamp,t)}function ci(e){return e.type==="click"&&(e.role==="link"||e.tagName==="a")}function Kt(e){return ci(e)&&/href=["']?#/.test(e.selector||"")}function aa(e,t){if(t.length!==0)return t.reduce((n,i)=>{const r=Math.abs(n.timestamp-e);return Math.abs(i.timestamp-e)<r?i:n},t[0])}function sa(e,t,n){return t.filter(i=>i.timestamp<=e&&e-i.timestamp<=n).sort((i,r)=>r.timestamp-i.timestamp)[0]}function la(e,t,n,i){if(n!=="zh")return;if(i!=="cdp")return{summary:Mt(e,t)};const r=`${e.title} ${t.map(a=>`${a.title} ${a.description}`).join(" ")}`;return/用户分群|创建分群|分群主体|门店名称|用户历史行为/.test(r)?{purpose:"创建用户分群，并通过行为数据源、筛选属性和统计条件圈选目标用户。",scope:"适用于需要在客户数据平台中创建用户分群，并根据历史行为、门店、次数或金额条件筛选用户的场景。",prerequisites:["已登录客户数据平台。","当前账号具备创建和保存用户分群的权限。","已明确分群主体、行为数据源和筛选条件。"],summary:Mt(e,t),verification:["分群主体已选择为目标用户主体，例如「C端用户」。","行为数据源、筛选属性和筛选值已正确显示，例如「用户历史行为 > 线下购物」和「门店名称」。","统计条件已正确设置，例如「总次数 ≥ 1」或消费金额条件。","查询结果和分群基础信息确认无误后再保存。"],conclusion:"完成以上配置后，即可保存该规则型用户分群，并在后续营销或分析场景中使用。"}:{summary:Mt(e,t)}}function Mt(e,t){const n=t.map(i=>i.title).filter(i=>i&&!/^查看/.test(i)).slice(0,6);return n.length===0?`本篇演示围绕“${e.title||"当前流程"}”记录关键操作。`:`本篇演示围绕“${e.title||"当前流程"}”，展示${n.join("、")}等关键操作。`}const ca="flowscribe-db",da=1,Ue="sessions";let $t=null;function Ke(){return $t||($t=Ui(ca,da,{upgrade(e){if(!e.objectStoreNames.contains(Ue)){const t=e.createObjectStore(Ue,{keyPath:"id"});t.createIndex("startedAt","startedAt"),t.createIndex("status","status")}}})),$t}const st={async saveSession(e){await(await Ke()).put(Ue,e)},async getSession(e){return(await Ke()).get(Ue,e)},async getAllSessions(){return(await(await Ke()).getAll(Ue)).sort((n,i)=>i.startedAt-n.startedAt)},async deleteSession(e){await(await Ke()).delete(Ue,e)},async clearAll(){await(await Ke()).clear(Ue)}};async function kn(e,t=Ne){const n=await st.getSession(e);if(!n)return null;if(n.guide){const a=n.guide.language??ua(n.guide);if(a===t)return n.guide.language||(n.guide.language=a,await st.saveSession(n)),{session:n,guide:n.guide}}const i=await Ce.get("domainProfile"),r=So(n,t,{domainProfile:i});return n.guide=r,await st.saveSession(n),{session:n,guide:r}}function ua(e){var i,r,a;return(((a=[e.title,(i=e.outline)==null?void 0:i.purpose,(r=e.outline)==null?void 0:r.summary,...e.steps.flatMap(s=>[s.title,s.description,s.voiceScript])].filter(Boolean).join(" ").match(/[\u3400-\u9fff]/g))==null?void 0:a.length)??0)>=3?"zh":"en"}async function pa(e,t){e.guide=t,await st.saveSession(e)}const ft=32,di="rgba(15, 23, 42, 0.22)",Qt=10,Pe=.018;function tt(e){const t=_e(e.width,Pe,1),n=_e(e.height,Pe,1);return{...e,x:_e(e.x,0,1-t),y:_e(e.y,0,1-n),width:t,height:n}}function fa(e,t,n){return tt({...e,x:e.x+t,y:e.y+n})}function ha(e,t,n,i){let r=e.x,a=e.y,s=e.x+e.width,o=e.y+e.height;return t.includes("left")?r+=n:s+=n,t.includes("top")?a+=i:o+=i,r=_e(r,0,s-Pe),s=_e(s,r+Pe,1),a=_e(a,0,o-Pe),o=_e(o,a+Pe,1),tt({...e,x:r,y:a,width:s-r,height:o-a})}function ma(e){const t=tt(e);return{left:`${t.x*100}%`,top:`${t.y*100}%`,width:`${t.width*100}%`,height:`${t.height*100}%`}}function ui(e){return e.manualMaskRegions===void 0&&e.maskedDataUrl||e.dataUrl}async function ga(e,t){const n=t.slice(0,Qt).map(tt),i=ui(e);return n.length===0?{dataUrl:i,maskedDataUrl:void 0,manualMaskRegions:[]}:{dataUrl:i,maskedDataUrl:await xa(i,n),manualMaskRegions:n}}async function xa(e,t){const n=await ya(e),i=n.naturalWidth||n.width,r=n.naturalHeight||n.height,a=document.createElement("canvas");a.width=i,a.height=r;const s=a.getContext("2d");if(!s||i<=0||r<=0)throw new Error("Could not prepare screenshot redaction");s.drawImage(n,0,0,i,r);for(const o of t){const c=tt(o),d=Math.round(c.x*i),u=Math.round(c.y*r),x=Math.max(1,Math.ceil(c.width*i)),f=Math.max(1,Math.ceil(c.height*r));ba(s,a,d,u,x,f)}return a.toDataURL("image/png")}function ba(e,t,n,i,r,a){const s=Math.max(1,Math.ceil(r/ft)),o=Math.max(1,Math.ceil(a/ft)),c=document.createElement("canvas");c.width=s,c.height=o;const d=c.getContext("2d");if(!d)throw new Error("Could not prepare screenshot redaction sample");d.drawImage(t,n,i,r,a,0,0,s,o),e.save(),e.imageSmoothingEnabled=!1,e.drawImage(c,0,0,s,o,n,i,r,a),e.fillStyle=di,e.fillRect(n,i,r,a),e.restore()}function ya(e){return new Promise((t,n)=>{const i=new Image;i.onload=()=>t(i),i.onerror=()=>n(new Error("Could not load screenshot for redaction")),i.src=e})}function _e(e,t,n){return Math.min(n,Math.max(t,Number.isFinite(e)?e:t))}const Ct={fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif',color:Be,background:"linear-gradient(180deg, color-mix(in srgb, var(--fs-brand) 9%, #f8fbfa) 0, color-mix(in srgb, var(--fs-brand) 4%, #f8fbfa) 260px, color-mix(in srgb, var(--fs-brand) 6%, #f3f7f6) 100%)",minHeight:"100vh",margin:0,WebkitFontSmoothing:"antialiased"},Tt={width:"min(1220px, calc(100% - 48px))",margin:"0 auto",padding:"24px 0 64px"},va={display:"grid",gridTemplateColumns:"minmax(0, 1fr) minmax(220px, 280px)",gap:24,alignItems:"flex-start"},wa={minWidth:0},Sa={position:"sticky",top:0,zIndex:10,display:"flex",gap:10,alignItems:"center",flexWrap:"wrap",padding:"10px 12px",marginBottom:24,border:"1px solid color-mix(in srgb, var(--fs-brand) 10%, #e4ece9)",borderRadius:16,background:"rgba(255,255,255,0.88)",boxShadow:"0 1px 2px rgba(15, 23, 42, 0.04), 0 14px 34px -28px rgba(15, 23, 42, 0.45)",backdropFilter:"blur(14px) saturate(160%)"},ka={display:"flex",alignItems:"center",gap:10,minWidth:180,marginRight:6},Ma={width:30,height:30,borderRadius:9,display:"grid",placeItems:"center",color:"#fff",background:"linear-gradient(135deg, var(--fs-brand), color-mix(in srgb, var(--fs-brand) 68%, #0f172a))",fontWeight:900,fontSize:12,boxShadow:"0 8px 22px -12px var(--fs-brand)"},$a={minWidth:0,fontSize:13,fontWeight:750,color:Be,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"},Ca={color:ve,fontSize:11,lineHeight:1.2},Zt={display:"inline-flex",alignItems:"center",justifyContent:"center",gap:6,minHeight:34,padding:"7px 12px",fontSize:13,fontWeight:700,border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontFamily:"inherit"},Ta=e=>({...Zt,background:"var(--fs-brand)",opacity:e?.6:1,cursor:e?"wait":"pointer",boxShadow:"0 10px 20px -14px var(--fs-brand)"}),ke={...Zt,background:"#fff",color:Be,border:"1px solid #e4ece9"},ja=e=>({...Zt,background:e?"var(--fs-brand)":"#fff",color:e?"#fff":ve,border:`1px solid ${e?"var(--fs-brand)":Ft}`,boxShadow:e?"0 10px 20px -14px var(--fs-brand)":"none"}),Aa={position:"relative",overflow:"hidden",border:"1px solid #e4ece9",borderRadius:16,background:"#fff",padding:"30px 34px 32px",marginBottom:22,boxShadow:"0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 22px -18px rgba(15, 23, 42, 0.3)"},Ia={position:"absolute",inset:"0 0 auto",height:4,background:"linear-gradient(90deg, var(--fs-brand), color-mix(in srgb, var(--fs-brand) 30%, #38bdf8), color-mix(in srgb, var(--fs-brand) 30%, #f43f5e))"},Jt={color:"var(--fs-brand)",fontSize:12,fontWeight:700,letterSpacing:".08em",textTransform:"uppercase",marginBottom:8},Ea={fontSize:32,lineHeight:1.15,margin:"0 0 8px",fontWeight:800,letterSpacing:"-0.01em"},za={color:ve,fontSize:13,marginTop:10,display:"flex",gap:14,flexWrap:"wrap",alignItems:"center"},pi={color:"var(--fs-brand)",textDecoration:"none",fontWeight:500,wordBreak:"break-all",cursor:"pointer"},jt={rule_draft:{bg:"#f1f5f9",text:ve},ai_refined:{bg:Ii,text:Ai},vision_refined:{bg:"#f5f3ff",text:"#6d28d9"},manual_edited:{bg:"#eff6ff",text:"#1d4ed8"},capture_failed:{bg:"#fee2e2",text:On}},Ra={display:"inline-block",fontSize:11,fontWeight:700,padding:"2px 10px",borderRadius:999,letterSpacing:"0.02em",verticalAlign:"middle"},en={border:"1px solid #e4ece9",borderTop:"4px solid var(--fs-brand)",borderRadius:16,padding:"18px 20px",marginBottom:22,background:"color-mix(in srgb, var(--fs-brand) 9%, #ffffff)",boxShadow:"0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 22px -18px rgba(15, 23, 42, 0.3)"},fi={display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:16,flexWrap:"wrap",marginBottom:16},hi={margin:"2px 0 0",fontSize:22,lineHeight:1.25,color:Be,fontWeight:750},La={display:"flex",flexDirection:"column",gap:6,minWidth:180,fontSize:12,color:ve,fontWeight:700},Na={minHeight:38,fontSize:14},Pa={color:ve,fontSize:13,margin:"0 0 12px",lineHeight:1.5},_a={display:"block",width:"100%",maxHeight:"min(52vw, 420px)",marginBottom:14,borderRadius:12,background:"#0f172a"},Da={position:"relative"},Ba={position:"absolute",left:12,right:12,bottom:24,padding:"8px 12px",borderRadius:8,background:"rgba(15, 23, 42, 0.78)",color:"#fff",fontSize:14,lineHeight:1.5,pointerEvents:"none"},Ua={display:"flex",flexWrap:"wrap",gap:14,alignItems:"flex-start"},Mn={display:"flex",flexWrap:"wrap",gap:6,alignItems:"baseline",fontSize:13,color:"#475467",lineHeight:1.5,minWidth:0,wordBreak:"break-word"},$n={color:ve,fontWeight:700},Le=e=>({margin:"0 0 12px",fontSize:13,lineHeight:1.5,color:e==="info"?"#1d4ed8":"#9a3412"}),Fa={minWidth:76,textAlign:"center",color:ve,fontSize:12,fontWeight:700},Wa={display:"flex",alignItems:"center",gap:8},Oa={display:"flex",alignItems:"center",flexWrap:"wrap",gap:8,marginTop:10},Cn={display:"flex",alignItems:"center",gap:7,minWidth:0,color:ve,fontSize:11,fontWeight:800},mi={position:"sticky",top:92,alignSelf:"flex-start",maxHeight:"calc(100dvh - 116px)",overflowY:"auto",border:"1px solid #e4ece9",borderRadius:16,padding:14,background:"#fff",boxShadow:"0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 22px -18px rgba(15, 23, 42, 0.3)",zIndex:5},Ha={margin:"0 0 10px",padding:"0 4px 10px",borderBottom:"1px solid #e4ece9",fontSize:12,color:ve,letterSpacing:".08em",textTransform:"uppercase"},Va={margin:0,paddingLeft:0,listStyle:"none"},Ga={margin:"3px 0",color:ve},Tn={display:"block",borderRadius:8,padding:"8px 10px",color:Be,textDecoration:"none",cursor:"pointer",fontSize:13,lineHeight:1.45},Ya={...mi,position:"static",top:"auto",maxHeight:"min(42dvh, 360px)",overflowY:"auto",overscrollBehavior:"contain",marginBottom:22},jn={fontSize:16,fontWeight:700,color:Be,marginBottom:6},ht={fontSize:14,lineHeight:1.85,color:"#475467",margin:0},Xa={display:"flex",flexDirection:"column",gap:18},qa={fontSize:12,margin:"4px 0 0",color:ve,letterSpacing:".08em",textTransform:"uppercase"},An={overflow:"hidden",border:"1px solid #e4ece9",borderRadius:16,background:"#fff",boxShadow:"0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 22px -18px rgba(15, 23, 42, 0.3)",breakInside:"avoid",scrollMarginTop:92},Ka={display:"grid",gridTemplateColumns:"auto minmax(0, 1fr)",gap:14,padding:"18px 22px 14px"},Qa={width:34,height:34,borderRadius:999,background:"var(--fs-brand)",color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,fontWeight:800,boxShadow:"0 8px 18px -10px var(--fs-brand)"},Za={minWidth:0},Ja={display:"flex",justifyContent:"flex-end",gap:6,marginBottom:8,flexWrap:"wrap"},Qe={display:"inline-flex",alignItems:"center",justifyContent:"center",gap:4,minHeight:30,padding:"5px 8px",fontSize:12,fontWeight:700,border:`1px solid ${Ft}`,borderRadius:8,background:"#fff",color:ve,cursor:"pointer",lineHeight:1,fontFamily:"inherit"},es={fontSize:19,lineHeight:1.4,margin:"0 0 6px",fontWeight:700,color:Be,letterSpacing:"-0.02em"},ts={color:"#475467",margin:"0 0 14px",fontSize:15,lineHeight:1.7},ns={click:{bg:"#dbeafe",text:"#1d4ed8",border:"#bfdbfe"},form:{bg:"#dcfce7",text:"#166534",border:"#bbf7d0"},select:{bg:"#fef3c7",text:"#92400e",border:"#fde68a"},selection:{bg:"#ede9fe",text:"#6d28d9",border:"#ddd6fe"},keyboard:{bg:"#e0f2fe",text:"#075985",border:"#bae6fd"},navigation:{bg:"#ffe4e6",text:"#be123c",border:"#fecdd3"},initial:{bg:"#dbeafe",text:"#1d4ed8",border:"#bfdbfe"},generic:{bg:"#e2e8f0",text:"#334155",border:"#cbd5e1"}},is=e=>{const t=ns[e];return{display:"inline-flex",alignItems:"center",width:"fit-content",maxWidth:"100%",padding:"7px 10px",border:`1px solid ${t.border}`,borderRadius:999,background:t.bg,color:t.text,fontSize:12,fontWeight:800,lineHeight:1,letterSpacing:"0.02em"}},rs={position:"relative",cursor:"zoom-in",margin:"0 22px 20px",overflow:"hidden",border:"1px solid #e4ece9",borderRadius:12,background:Hn},os={display:"block",width:"100%",background:Hn},nt={width:"100%",fontSize:15,padding:"6px 8px",border:`1px solid ${Ft}`,borderRadius:6,color:Be,background:"#fff",fontFamily:"inherit"},mt={...nt,minHeight:60,resize:"vertical",lineHeight:1.5},as={position:"fixed",inset:0,background:"rgba(15, 23, 42, 0.85)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:9999,padding:16},ss={width:"min(1040px, 95vw)"},ls={textAlign:"center",color:"#cbd5e1",fontSize:12,marginTop:8},In={color:On,fontSize:13,marginBottom:12},At={textAlign:"center",color:ve,fontSize:15,padding:"60px 12px"},cs={color:ve,fontSize:12,marginTop:6},It=e=>({display:"flex",alignItems:"center",flexWrap:"wrap",gap:6,margin:"0 0 14px",padding:"12px 14px",borderRadius:12,border:e?"1px solid color-mix(in srgb, var(--fs-brand) 28%, #c7e7df)":"1px solid #fed7aa",background:e?"color-mix(in srgb, var(--fs-brand) 10%, #ffffff)":"#fff7ed",color:e?"#1d4ed8":"#9a3412",fontSize:13,fontWeight:750,lineHeight:1.5});function En(e,t,n,i,r,a="circle"){const s=e!=null&&e.devicePixelRatio&&e.devicePixelRatio>0?e.devicePixelRatio:1,o=(e==null?void 0:e.viewport)??{width:i/s,height:r/s,scrollX:0,scrollY:0},c={...e,type:(e==null?void 0:e.type)??"generic",shape:a,x:Math.max(0,Math.min(1,t))*o.width,y:Math.max(0,Math.min(1,n))*o.height,viewport:o,devicePixelRatio:s};return a==="rectangle"?qn(c,t,n):c}function gi({screenshot:e,focus:t,additionalFocuses:n=[],activeFocusId:i=$e,defaultFocusShape:r="circle",stepNumber:a,uiLanguage:s=Ie,editing:o=!1,redactionMode:c=!1,onFocusChange:d,onFocusSelect:u,annotations:x=[],activeAnnotationId:f,onAnnotationsChange:m,onAnnotationSelect:T,manualMaskRegions:z=[],activeMaskId:E,onMaskRegionsChange:D,onMaskSelect:R,onZoom:O}){const Q=y.useRef(null),ee=y.useRef(null),Y=y.useRef(!1),[ie,Z]=y.useState({width:0,height:0}),[_,J]=y.useState(null),H=y.useRef(null),[oe,le]=y.useState(null),k=y.useRef(null),[M,U]=y.useState(null),F=zn(t,ie.width,ie.height),X=n.map(b=>zn(b,ie.width,ie.height)??b),fe=et(F,X).map(b=>(_==null?void 0:_.id)===b.id?{...b,focus:_.focus}:b),te=fe.find(b=>b.id===i)??fe[0],Se=(te==null?void 0:te.id)??$e,ae=te==null?void 0:te.focus,ne=oe??x,L=M??z,me=o&&!c,v=me&&!!d;function B(b){if(Y.current){Y.current=!1;return}if(c)return;if(!v){O==null||O();return}const j=Q.current;if(!j||!j.naturalWidth||!j.naturalHeight)return;const I=j.getBoundingClientRect();if(!I.width||!I.height)return;const N=(ae==null?void 0:ae.shape)??r;d==null||d(En(ae,(b.clientX-I.left)/I.width,(b.clientY-I.top)/I.height,j.naturalWidth,j.naturalHeight,N),Se)}function ue(b,j,I,N){if(!v)return;b.preventDefault(),b.stopPropagation(),u==null||u(I);const q=Q.current;if(!q)return;const re=q.getBoundingClientRect();if(!re.width||!re.height)return;const ge=b.clientX,he=b.clientY,ce=N,G=V=>{const h=Nr(ce,j,(V.clientX-ge)/re.width,(V.clientY-he)/re.height);ee.current={id:I,focus:h},J({id:I,focus:h})},W=()=>{window.removeEventListener("pointermove",G),window.removeEventListener("pointerup",W),window.removeEventListener("pointercancel",W);const V=ee.current;V&&(d==null||d(V.focus,V.id)),ee.current=null,J(null),Y.current=!0};window.addEventListener("pointermove",G),window.addEventListener("pointerup",W,{once:!0}),window.addEventListener("pointercancel",W,{once:!0})}function we(b,j,I,N){if(!v)return;b.preventDefault(),b.stopPropagation(),u==null||u(j);const q=Q.current;if(!q||!q.naturalWidth||!q.naturalHeight)return;const re=q.getBoundingClientRect();if(!re.width||!re.height)return;const ge=b.clientX,he=b.clientY,ce=I,G=N.shape==="rectangle"?(Number.parseFloat(N.left)+Number.parseFloat(N.width)/2)/100:Number.parseFloat(N.left)/100,W=N.shape==="rectangle"?(Number.parseFloat(N.top)+Number.parseFloat(N.height)/2)/100:Number.parseFloat(N.top)/100,V=C=>{const P=En(ce,G+(C.clientX-ge)/re.width,W+(C.clientY-he)/re.height,q.naturalWidth,q.naturalHeight,N.shape);ee.current={id:j,focus:P},J({id:j,focus:P})},h=()=>{window.removeEventListener("pointermove",V),window.removeEventListener("pointerup",h),window.removeEventListener("pointercancel",h);const C=ee.current;C&&(d==null||d(C.focus,C.id)),ee.current=null,J(null),Y.current=!0};window.addEventListener("pointermove",V),window.addEventListener("pointerup",h,{once:!0}),window.addEventListener("pointercancel",h,{once:!0})}function He(b,j){if(b.stopPropagation(),T==null||T(j),!me||!m)return;b.preventDefault();const I=Q.current;if(!I)return;const N=I.getBoundingClientRect();if(!N.width||!N.height)return;const q=b.currentTarget.getBoundingClientRect(),re={maxX:Math.max(.01,1-q.width/N.width-.01),maxY:Math.max(.01,1-q.height/N.height-.01)},ge=b.clientX,he=b.clientY,ce=ne,G=V=>{const h=ce.map(C=>C.id===j?Br(C,(V.clientX-ge)/N.width,(V.clientY-he)/N.height,re):C);H.current=h,le(h)},W=()=>{window.removeEventListener("pointermove",G),window.removeEventListener("pointerup",W),window.removeEventListener("pointercancel",W);const V=H.current;V&&m(V),H.current=null,le(null),Y.current=!0};window.addEventListener("pointermove",G),window.addEventListener("pointerup",W,{once:!0}),window.addEventListener("pointercancel",W,{once:!0})}function Ee(b){if(!c||!D||L.length>=Qt||b.target.closest(".fs-manual-mask"))return;const j=Q.current;if(!j)return;const I=j.getBoundingClientRect();if(!I.width||!I.height)return;b.preventDefault();const N=ot((b.clientX-I.left)/I.width,0,1),q=ot((b.clientY-I.top)/I.height,0,1),re=`mask-${Date.now()}-${L.length}`,ge=ce=>{const G=ot((ce.clientX-I.left)/I.width,0,1),W=ot((ce.clientY-I.top)/I.height,0,1),V={id:re,x:Math.min(N,G),y:Math.min(q,W),width:Math.abs(G-N),height:Math.abs(W-q)},h=[...z,V];k.current=h,U(h)},he=()=>{window.removeEventListener("pointermove",ge),window.removeEventListener("pointerup",he),window.removeEventListener("pointercancel",he);const ce=k.current,G=ce==null?void 0:ce.find(W=>W.id===re);ce&&G&&G.width>=Pe&&G.height>=Pe&&(R==null||R(re),D(ce)),k.current=null,U(null),Y.current=!0};window.addEventListener("pointermove",ge),window.addEventListener("pointerup",he,{once:!0}),window.addEventListener("pointercancel",he,{once:!0})}function Ve(b,j){b.preventDefault(),b.stopPropagation(),R==null||R(j);const I=L.find(G=>G.id===j),N=Q.current;if(!I||!N||!D)return;const q=N.getBoundingClientRect(),re=b.clientX,ge=b.clientY,he=L;Me(G=>{const W=he.map(V=>V.id===j?fa(V,(G.clientX-re)/q.width,(G.clientY-ge)/q.height):V);k.current=W,U(W)},()=>{const G=k.current;G&&D(G)})}function qe(b,j,I){b.preventDefault(),b.stopPropagation(),R==null||R(j);const N=L.find(W=>W.id===j),q=Q.current;if(!N||!q||!D)return;const re=q.getBoundingClientRect(),ge=b.clientX,he=b.clientY,ce=L;Me(W=>{const V=ce.map(h=>h.id===j?ha(h,I,(W.clientX-ge)/re.width,(W.clientY-he)/re.height):h);k.current=V,U(V)},()=>{const W=k.current;W&&D(W)})}function Me(b,j){const I=()=>{window.removeEventListener("pointermove",b),window.removeEventListener("pointerup",I),window.removeEventListener("pointercancel",I),j(),k.current=null,U(null),Y.current=!0};window.addEventListener("pointermove",b),window.addEventListener("pointerup",I,{once:!0}),window.addEventListener("pointercancel",I,{once:!0})}const ze=c?ui(e):e.maskedDataUrl||e.dataUrl;return l.jsxs("div",{"data-fs-screenshot-wrap":!0,style:{...rs,cursor:c||v?"crosshair":O?"zoom-in":"default"},onClick:B,onPointerDown:Ee,title:c?$(s,"step.privacyMaskDrawHint"):v?$(s,"step.adjustFocus"):void 0,children:[l.jsx("img",{ref:Q,src:ze,alt:`${$(s,"preview.screenshotAlt")} ${a??""}`,style:os,onLoad:b=>Z({width:b.currentTarget.naturalWidth,height:b.currentTarget.naturalHeight})}),!c&&fe.map(b=>{const j=Ht(b.focus,r);if(!j)return null;const I=b.id===Se;return j.shape==="circle"?l.jsxs("div",{children:[!me&&b.primary&&l.jsx("div",{className:"fs-focus-dim",style:{background:`radial-gradient(circle 46px at ${j.left} ${j.top}, transparent 0 46px, rgba(15, 23, 42, 0.10) 70px, rgba(15, 23, 42, 0.22) 100%)`}}),l.jsx("div",{"data-fs-focus-ring":!0,className:`fs-click-circle${me?" fs-focus-draggable":b.primary?" fs-click-circle-animated":" fs-focus-secondary"}${I&&me?" fs-focus-active":""}`,style:{left:j.left,top:j.top},onPointerDown:N=>we(N,b.id,b.focus,j)})]},b.id):l.jsx(us,{geometry:j,editing:me,primary:b.primary,active:I,canAdjust:v&&I,onDragStart:N=>we(N,b.id,b.focus,j),onResizeStart:(N,q)=>ue(N,q,b.id,b.focus)},b.id)}),!c&&ne.map(b=>l.jsx("div",{className:`fs-screenshot-annotation fs-screenshot-annotation-${Vt(b,Gt(b,F,X))}${me?" fs-screenshot-annotation-editing":""}${f===b.id?" fs-screenshot-annotation-active":""}`,style:Zn(b),onPointerDown:j=>He(j,b.id),onClick:me?j=>j.stopPropagation():void 0,children:b.text},b.id)),c&&L.map(b=>{const j=b.id===E;return l.jsxs("div",{className:`fs-manual-mask${j?" fs-manual-mask-active":""}`,style:ma(b),onPointerDown:I=>Ve(I,b.id),children:[l.jsx(ds,{sourceDataUrl:ze,region:b}),j&&["top-left","top-right","bottom-left","bottom-right"].map(I=>l.jsx("button",{type:"button",className:`fs-manual-mask-handle fs-manual-mask-${I}`,"aria-label":I,onPointerDown:N=>qe(N,b.id,I)},I))]},b.id)})]})}function ds({sourceDataUrl:e,region:t}){const n=y.useRef(null);return y.useEffect(()=>{let i=!1;const r=new Image;return r.onload=()=>{if(i)return;const a=n.current;if(!a)return;const s=r.naturalWidth||r.width,o=r.naturalHeight||r.height,c=Math.round(t.x*s),d=Math.round(t.y*o),u=Math.max(1,Math.ceil(t.width*s)),x=Math.max(1,Math.ceil(t.height*o)),f=Math.max(1,Math.ceil(u/ft)),m=Math.max(1,Math.ceil(x/ft));a.width=f,a.height=m;const T=a.getContext("2d");T&&(T.drawImage(r,c,d,u,x,0,0,f,m),T.fillStyle=di,T.fillRect(0,0,f,m))},r.src=e,()=>{i=!0}},[e,t.x,t.y,t.width,t.height]),l.jsx("canvas",{ref:n,className:"fs-manual-mask-preview","aria-hidden":"true"})}function ot(e,t,n){return Math.min(n,Math.max(t,e))}function us({geometry:e,editing:t,primary:n,active:i,canAdjust:r,onDragStart:a,onResizeStart:s}){const o={left:e.left,top:e.top,width:e.width,height:e.height};return l.jsxs(l.Fragment,{children:[!t&&n&&l.jsx("div",{className:"fs-focus-rect-dim",style:o}),l.jsx("div",{"data-fs-focus-ring":!0,className:`fs-focus-rect${t?" fs-focus-draggable":n?" fs-focus-rect-animated":" fs-focus-secondary"}${i&&t?" fs-focus-active":""}`,style:o,onPointerDown:a}),r&&["top-left","top-right","bottom-left","bottom-right"].map(c=>l.jsx("button",{type:"button",className:`fs-focus-resize-handle fs-focus-resize-${c}`,"aria-label":c,title:c,style:ps(e,c),onPointerDown:d=>s(d,c)},c))]})}function ps(e,t){const n=t.includes("left")?e.left:`calc(${e.left} + ${e.width})`,i=t.includes("top")?e.top:`calc(${e.top} + ${e.height})`;return{left:n,top:i}}function zn(e,t,n){if(!e||e.viewport||!t||!n)return e;const i=e.devicePixelRatio&&e.devicePixelRatio>0?e.devicePixelRatio:1;return{...e,viewport:{width:t/i,height:n/i,scrollX:0,scrollY:0}}}function fs({screenshot:e,focus:t,additionalFocuses:n=[],annotations:i=[],defaultFocusShape:r="circle",uiLanguage:a=Ie,onClose:s}){return y.useEffect(()=>{const o=c=>{c.key==="Escape"&&s()};return window.addEventListener("keydown",o),()=>window.removeEventListener("keydown",o)},[s]),l.jsx("div",{style:as,onClick:s,children:l.jsxs("div",{style:ss,onClick:o=>o.stopPropagation(),children:[l.jsx(gi,{screenshot:e,focus:t,additionalFocuses:n,annotations:i,defaultFocusShape:r,uiLanguage:a}),l.jsx("div",{style:ls,children:$(a,"preview.lightboxHint")})]})})}function Ye({value:e,editing:t,multiline:n,placeholder:i,onChange:r,style:a,inputStyle:s}){const o=y.useRef(null);if(!t)return l.jsx("div",{style:a,children:e||l.jsx("span",{style:{color:"#cbd5e1"},children:i??""})});const c=()=>{var x;const u=(((x=o.current)==null?void 0:x.value)??"").trim();u!==(e??"")&&r(u)},d=n?"textarea":"input";return l.jsx(d,{ref:o,defaultValue:e??"",placeholder:i,style:s,onBlur:c,onKeyDown:u=>{var x,f,m;u.key==="Escape"&&(o.current&&(o.current.value=e??""),(x=o.current)==null||x.blur()),(u.metaKey||u.ctrlKey)&&u.key==="Enter"&&(u.preventDefault(),(f=o.current)==null||f.blur()),!n&&u.key==="Enter"&&(u.preventDefault(),(m=o.current)==null||m.blur())}})}function hs({step:e,screenshot:t,editing:n,defaultFocusShape:i="circle",justMoved:r,canUp:a,canDown:s,onPatch:o,onMoveUp:c,onMoveDown:d,onDelete:u,onScreenshotPatch:x,onZoom:f,uiLanguage:m=Ie}){var me;const[T,z]=y.useState(null),[E,D]=y.useState($e),[R,O]=y.useState(!1),[Q,ee]=y.useState(null),[Y,ie]=y.useState((t==null?void 0:t.manualMaskRegions)??[]),[Z,_]=y.useState(!1),J=Ms(e.actionType,(me=e.focus)==null?void 0:me.type,m),H=e.additionalFocuses??[],oe=et(e.focus,H),le=oe.find(v=>v.id===E)??oe[0],k=(le==null?void 0:le.id)??$e,M=le==null?void 0:le.focus,U=(M==null?void 0:M.shape)??i,F=(e.annotations??[]).map(Je);y.useEffect(()=>{ie((t==null?void 0:t.manualMaskRegions)??[])},[t==null?void 0:t.id,t==null?void 0:t.manualMaskRegions]);async function X(v){if(!(!t||Z)){ie(v),_(!0);try{x(await ga(t,v))}catch{ie(t.manualMaskRegions??[])}finally{_(!1)}}}function fe(v){if(k===$e){o({focus:v});return}o({additionalFocuses:H.map(B=>B.id===k?v:B)})}function te(){if(!M||oe.length>=at)return;const v=M.viewport,B=`focus-${Date.now()}-${oe.length}`,ue=.08*oe.length;let we={...M,id:B,detectedRect:void 0,rect:void 0,rectAdjusted:void 0,x:v!=null&&v.width?Math.min(v.width*.92,(M.x??v.width/2)+v.width*ue):M.x,y:v!=null&&v.height?Math.min(v.height*.92,(M.y??v.height/2)+v.height*ue):M.y};(we.shape??i)==="rectangle"&&(v!=null&&v.width)&&v.height&&(we=qn(ct(we),(we.x??v.width/2)/v.width,(we.y??v.height/2)/v.height)),D(B),o({additionalFocuses:[...H,we]})}function Se(){k!==$e&&(D($e),o({additionalFocuses:H.filter(v=>v.id!==k)}))}function ae(){if(F.length>=St)return;const v={id:`note-${Date.now()}-${F.length}`,text:$(m,"step.annotationDefault"),x:.06+F.length*.03,y:.07+F.length*.05};z(v.id),o({annotations:[...F,v]})}function ne(v,B){o({annotations:F.map(ue=>ue.id===v?{...ue,...B}:ue)})}function L(v){z(B=>B===v?null:B),o({annotations:F.filter(B=>B.id!==v)})}return l.jsxs("article",{id:`step-${e.stepNumber}`,style:r?{...An,animation:"fs-step-moved 0.45s ease"}:An,children:[l.jsxs("div",{style:Ka,children:[l.jsx("div",{style:Qa,children:e.stepNumber}),l.jsxs("div",{style:Za,children:[n&&l.jsxs("div",{style:Ja,children:[l.jsxs("button",{type:"button",style:Qe,disabled:!a,onClick:c,title:$(m,"step.moveUp"),children:[l.jsx(Yi,{size:14}),$(m,"step.moveUp")]}),l.jsxs("button",{type:"button",style:Qe,disabled:!s,onClick:d,title:$(m,"step.moveDown"),children:[l.jsx(Vi,{size:14}),$(m,"step.moveDown")]}),l.jsxs("button",{type:"button",style:{...Qe,background:"#fff1f2",color:"#dc2626",borderColor:"#fecdd3"},onClick:u,title:$(m,"step.deleteConfirm"),children:[l.jsx(it,{size:14}),$(m,"step.delete")]})]}),l.jsx(Ye,{value:e.title,editing:n,placeholder:$(m,"step.titlePlaceholder"),onChange:v=>o({title:v}),style:es,inputStyle:nt}),l.jsx(Ye,{value:e.description,editing:n,multiline:!0,placeholder:$(m,"step.descPlaceholder"),onChange:v=>o({description:v}),style:ts,inputStyle:mt})]})]}),t&&l.jsxs(l.Fragment,{children:[n&&l.jsx("div",{style:ms,children:R?l.jsxs("div",{style:Rn,children:[l.jsxs("div",{style:Et,children:[l.jsxs("span",{style:Rt,children:[$(m,"step.privacyMask")," · ",Y.length,"/",Qt]}),l.jsxs("span",{style:zt,children:[l.jsx(wt,{size:13}),$(m,"step.privacyMaskDrawHint")]})]}),l.jsxs("button",{type:"button",style:Nn(!0),onClick:()=>{O(!1),ee(null)},children:[l.jsx(wt,{size:14}),$(m,"step.privacyMaskDone")]}),Q&&l.jsx("button",{type:"button",style:Lt,disabled:Z,title:$(m,"step.deletePrivacyMask"),"aria-label":$(m,"step.deletePrivacyMask"),onClick:()=>{var B;const v=Y.filter(ue=>ue.id!==Q);ee(((B=v[0])==null?void 0:B.id)??null),X(v)},children:l.jsx(it,{size:14})}),Y.length>0&&l.jsx("button",{type:"button",style:lt,disabled:Z,onClick:()=>{ee(null),X([])},children:$(m,"step.clearPrivacyMasks")})]}):l.jsxs(l.Fragment,{children:[l.jsxs("div",{style:Rn,children:[l.jsxs("div",{style:Et,children:[l.jsxs("span",{style:Rt,children:[$(m,"step.focusShape")," · ",oe.length,"/",at]}),l.jsxs("span",{style:zt,children:[l.jsx(nr,{size:13}),$(m,U==="rectangle"?"step.adjustFocusRectHint":"step.adjustFocusHint")]})]}),l.jsxs("div",{style:gs,children:[oe.map((v,B)=>l.jsx("button",{type:"button",style:tn(v.id===k),title:`${$(m,"step.focusShape")} ${B+1}`,onClick:()=>D(v.id),children:B+1},v.id)),l.jsx("button",{type:"button",style:xs,disabled:!M||oe.length>=at,title:$(m,"step.addFocus"),"aria-label":$(m,"step.addFocus"),onClick:te,children:l.jsx(xr,{size:14})}),k!==$e&&l.jsx("button",{type:"button",style:Lt,title:$(m,"step.deleteFocus"),"aria-label":$(m,"step.deleteFocus"),onClick:Se,children:l.jsx(it,{size:14})})]}),l.jsxs("div",{style:bs,children:[l.jsxs("button",{type:"button",style:Ln(U==="circle"),disabled:!M,onClick:()=>M&&fe({...M,shape:"circle"}),children:[l.jsx(Ni,{size:14}),$(m,"step.focusCircle")]}),l.jsxs("button",{type:"button",style:Ln(U==="rectangle"),disabled:!M,onClick:()=>M&&fe(ct(M)),children:[l.jsx(Pi,{size:15}),$(m,"step.focusRectangle")]})]}),U==="rectangle"&&(M==null?void 0:M.detectedRect)&&l.jsxs("button",{type:"button",style:lt,title:$(m,"step.resetFocusRect"),onClick:()=>fe(Pr(M)),children:[l.jsx(yr,{size:14}),$(m,"step.resetFocusRect")]}),l.jsxs("button",{type:"button",style:Nn(!1),title:$(m,"step.privacyMaskHint"),onClick:()=>O(!0),children:[l.jsx(wt,{size:14}),$(m,"step.privacyMask"),Y.length>0?` · ${Y.length}`:""]})]}),l.jsxs("div",{style:ys,children:[l.jsxs("div",{style:Et,children:[l.jsxs("div",{style:Rt,children:[$(m,"step.textAnnotations")," · ",F.length,"/",St]}),l.jsx("div",{style:zt,children:$(m,"step.annotationHint")})]}),l.jsxs("button",{type:"button",style:lt,disabled:F.length>=St,onClick:ae,children:[l.jsx(fr,{size:14}),$(m,"step.addTextAnnotation")]})]}),F.length>0&&l.jsx("div",{style:vs,children:F.map((v,B)=>l.jsxs("div",{style:ws,children:[l.jsx("button",{type:"button",style:Ss(T===v.id),title:`${$(m,"step.textAnnotations")} ${B+1}`,onClick:()=>z(v.id),children:B+1}),l.jsx("input",{value:v.text,maxLength:Qn,"aria-label":$(m,"step.annotationPlaceholder"),placeholder:$(m,"step.annotationPlaceholder"),style:ks(T===v.id),onFocus:()=>z(v.id),onChange:ue=>ne(v.id,{text:ue.target.value})}),l.jsx("button",{type:"button",style:Lt,title:$(m,"step.deleteAnnotation"),"aria-label":$(m,"step.deleteAnnotation"),onClick:()=>L(v.id),children:l.jsx(it,{size:14})})]},v.id))})]})}),l.jsx(gi,{screenshot:t,focus:e.focus,additionalFocuses:H,activeFocusId:k,defaultFocusShape:i,stepNumber:e.stepNumber,uiLanguage:m,editing:n,redactionMode:R,onFocusChange:(v,B)=>{D(B),o(B===$e?{focus:v}:{additionalFocuses:H.map(ue=>ue.id===B?v:ue)})},onFocusSelect:D,annotations:F,activeAnnotationId:T,onAnnotationsChange:v=>o({annotations:v}),onAnnotationSelect:z,manualMaskRegions:Y,activeMaskId:Q,onMaskSelect:ee,onMaskRegionsChange:v=>void X(v),onZoom:()=>f(t,e.focus,H,F)})]}),l.jsx("div",{style:{padding:"0 22px 18px",display:"grid",gap:8,justifyItems:"start"},children:l.jsx("span",{style:is(J.tone),children:J.label})})]})}const ms={margin:"0 22px 10px",padding:"9px 11px",border:"1px solid #bfdbfe",borderRadius:7,background:"#ecfdf5"},Rn={display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"},Et={display:"inline-flex",alignItems:"center",gap:9,minWidth:0,flex:"1 1 320px"},zt={display:"inline-flex",alignItems:"center",gap:5,color:"#52736f",fontSize:11,fontWeight:650,lineHeight:1.35},gs={display:"inline-flex",alignItems:"center",gap:5},tn=e=>({display:"grid",placeItems:"center",width:30,height:30,padding:0,border:`1px solid ${e?"#2563eb":"#bfdbfe"}`,borderRadius:6,background:e?"#2563eb":"#fff",color:e?"#fff":"#365b57",fontSize:12,fontWeight:800,cursor:"pointer"}),xs={...tn(!1),cursor:"pointer"},Rt={color:"#476b68",fontSize:12,fontWeight:800},bs={display:"inline-flex",border:"1px solid #bfdbfe",borderRadius:6,overflow:"hidden",background:"#fff"},Ln=e=>({display:"inline-flex",alignItems:"center",gap:5,minHeight:30,padding:"5px 9px",border:0,borderRight:"1px solid #cce7e3",background:e?"#2563eb":"#fff",color:e?"#fff":"#365b57",fontSize:12,fontWeight:750,cursor:"pointer"}),lt={display:"inline-flex",alignItems:"center",gap:5,minHeight:30,padding:"5px 8px",border:"1px solid #bfdbfe",borderRadius:6,background:"#fff",color:"#1d4ed8",fontSize:12,fontWeight:750,cursor:"pointer"},Nn=e=>({...lt,borderColor:e?"#1d4ed8":"#bfdbfe",background:e?"#1d4ed8":"#fff",color:e?"#fff":"#365b57"}),ys={display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,marginTop:10,paddingTop:10,borderTop:"1px solid #bfe8e2"},vs={display:"grid",gap:6,marginTop:8},ws={display:"grid",gridTemplateColumns:"26px minmax(0, 1fr) 32px",gap:6,alignItems:"center"},Ss=e=>({...tn(e),width:26,height:26,borderRadius:999}),ks=e=>({minWidth:0,height:34,padding:"6px 9px",border:`1px solid ${e?"#2563eb":"#bfdbfe"}`,borderRadius:6,outline:e?"2px solid rgba(13, 148, 136, .12)":"none",background:"#fff",color:"#172033",fontSize:12}),Lt={display:"grid",placeItems:"center",width:32,height:32,padding:0,border:"1px solid #fecdd3",borderRadius:6,background:"#fff1f2",color:"#dc2626",cursor:"pointer"};function Ms(e,t,n=Ie){switch((t&&t!=="generic"?t:e||"").toLowerCase()){case"click":return{label:$(n,"step.action.click"),tone:"click"};case"input":case"change":case"focus":case"blur":return{label:$(n,"step.action.form"),tone:"form"};case"select":return{label:$(n,"step.action.select"),tone:"select"};case"selection":return{label:$(n,"step.action.selection"),tone:"selection"};case"keypress":return{label:$(n,"step.action.keyboard"),tone:"keyboard"};case"navigation":return{label:$(n,"step.action.navigation"),tone:"navigation"};case"initial_screen":return{label:$(n,"step.action.initial"),tone:"initial"};default:return{label:$(n,"step.action.generic"),tone:"generic"}}}const $s=408125543,Cs=524531317,xi=231,Ts=163,js=160,As=161,Is=33;function nn(e){if(!e)throw new Error("Invalid EBML vint: leading zero byte");let t=1,n=128;for(;!(e&n);)if(n>>=1,t+=1,t>8)throw new Error("Invalid EBML vint: length exceeds 8 bytes");return t}function Es(e,t){const n=nn(e[t]);let i=0;for(let r=0;r<n;r+=1)i=i*256+e[t+r];return{id:i,length:n}}function zs(e,t){const n=nn(e[t]),i=255>>n;let r=e[t]&i,a=r===i;for(let s=1;s<n;s+=1){const o=e[t+s];r=r*256+o,o!==255&&(a=!1)}return{value:a?null:r,length:n}}function Ut(e,t,n){const{id:i,length:r}=Es(e,t),a=t+r,s=zs(e,a),o=a+s.length,c=s.value??n-o;return{id:i,sizePos:a,sizeLength:s.length,sizeValue:s.value,dataStart:o,end:Math.min(o+c,n)}}function Rs(e,t,n){let i=0;for(let r=0;r<n;r+=1)i=i*256+e[t+r];return i}function rn(e,t,n,i){let r=n;for(let a=i-1;a>=0;a-=1)e[t+a]=r&255,r=Math.floor(r/256)}function Ls(e){let t=1;for(;e>=2**(8*t);)t+=1;return t}function bi(e,t){const n=new Uint8Array(t);return rn(n,0,e,t),n[0]|=1<<8-t,n}function Ns(e){let t=1;for(;e>2**(7*t)-2;)t+=1;return t}function Pn(e,t){const n=nn(e[t]),i=e[t+n]<<8|e[t+n+1];return i>=32768?i-65536:i}function Ps(e,t,n){let i=t.dataStart;const r=t.end;let a=null,s=null;const o=[];for(;i<r;){const d=Ut(e,i,r);if(d.end<=i)throw new Error("Corrupt EBML: non-advancing element");if(d.id===xi&&s===null)a=Rs(e,d.dataStart,d.end-d.dataStart),s={elementPos:i,dataPos:d.dataStart,dataLength:d.end-d.dataStart,sizeLength:d.sizeLength};else if(d.id===Ts)o.push(Pn(e,d.dataStart));else if(d.id===js){let u=d.dataStart;for(;u<d.end;){const x=Ut(e,u,d.end);if(x.end<=u)break;x.id===As&&o.push(Pn(e,x.dataStart)),u=x.end}}i=d.end}const c=a??0;for(const d of o)n.push(c+d);return{sizePos:t.sizePos,sizeLength:t.sizeLength,sizeValue:t.sizeValue,timecode:c,timecodeField:s}}function _s(e){const t=[],n=[];yi(e,0,e.length,t,n);let i=Is,r=0;if(n.length>0){const a=[...n].sort((o,c)=>o-c);r=a[a.length-1];let s=1/0;for(let o=1;o<a.length;o+=1){const c=a[o]-a[o-1];c>0&&c<s&&(s=c)}s!==1/0&&(i=s)}return{clusters:t,blockTimecodes:n,durationMs:r+i}}function yi(e,t,n,i,r){let a=t;for(;a<n;){const s=Ut(e,a,n);if(s.end<=a)throw new Error("Corrupt EBML: non-advancing element");if(s.id===Cs){const o=s.sizeValue===null?Ds(e,s.dataStart,n):s.end;i.push(Ps(e,{...s,end:o},r)),a=o;continue}s.id===$s&&yi(e,s.dataStart,s.end,i,r),a=s.end}}function Ds(e,t,n){for(let i=t;i+4<=n;i+=1)if(!(e[i]!==31&&e[i]!==26)&&(e[i]===31&&e[i+1]===67&&e[i+2]===182&&e[i+3]===117||e[i]===26&&e[i+1]===69&&e[i+2]===223&&e[i+3]===163))return i;return n}function Bs(e,t,n){const i=new Uint8Array(1+n+t);return i[0]=xi,i.set(bi(t,n),1),rn(i,1+n,e,t),i}function Us(e,t,n){if(n===0)return[e];const i=t.clusters.filter(s=>s.timecodeField!==null);if(i.length===0)return[e];const r=[];let a=0;for(const s of i){const o=s.timecodeField,c=s.timecode+n,d=Ls(c);if(d<=o.dataLength){r.push(e.subarray(a,o.dataPos));const T=new Uint8Array(o.dataLength);rn(T,0,c,o.dataLength),r.push(T),a=o.dataPos+o.dataLength;continue}const u=d>2**(7*o.sizeLength)-2?Ns(d):o.sizeLength,x=Bs(c,d,u),f=o.dataPos+o.dataLength-o.elementPos,m=x.length-f;if(s.sizeValue!==null){const T=s.sizeValue+m;if(T>2**(7*s.sizeLength)-2)throw new Error("Cannot remap cluster timecode: declared Cluster size field too small");r.push(e.subarray(a,s.sizePos)),r.push(bi(T,s.sizeLength)),r.push(e.subarray(s.sizePos+s.sizeLength,o.elementPos))}else r.push(e.subarray(a,o.elementPos));r.push(x),a=o.elementPos+f}return r.push(e.subarray(a)),r}async function Fs(e){if(e.length===0)throw new Error("No video segments to merge");const t=e[0].mimeType;if(e.some(s=>s.mimeType!==t))throw new Error(`Cannot merge video segments with different encodings (${t} vs other)`);if(e.length===1)return{blob:e[0].blob,mimeType:t};const n=await Promise.all(e.map(async s=>new Uint8Array(await s.blob.arrayBuffer()))),i=n.map(_s),r=[];let a=0;return n.forEach((s,o)=>{o>0?r.push(...Us(s,i[o],a)):r.push(s),a+=i[o].durationMs}),{blob:new Blob(r,{type:t}),mimeType:t}}function Ws(e){return e.length>=2&&new Set(e).size===1}function vi(e){var t,n,i,r;return((t=e.voiceScript)==null?void 0:t.trim())||((n=e.generatedVoiceScript)==null?void 0:n.trim())||((i=e.description)==null?void 0:i.trim())||((r=e.title)==null?void 0:r.trim())||""}function Os(e,t){return e.flatMap(n=>{const i=t[n.stepIndex];if(!i)return[];const r=vi(i);return r?[{...n,stepNumber:i.stepNumber,text:r}]:[]})}function Hs(e,t,n){let i=null;for(const r of e)if(r.segmentId===t){if(r.startMs>n)break;i=r}return i}class Vs{constructor(t,n){Ge(this,"lastCueKey",null);Ge(this,"narrating",!1);Ge(this,"active",!1);this.cues=t,this.segmentOrder=n}get isActive(){return this.active}get isNarrating(){return this.narrating}start(t,n){return this.active=!0,this.narrating=!1,this.lastCueKey=null,this.evaluate(t,n)}onTimeUpdate(t,n){return!this.active||this.narrating?{type:"none"}:this.evaluate(t,n)}onPlay(t,n){return!this.active||this.narrating?{type:"none"}:this.evaluate(t,n)}onNarrationEnd(){return!this.active||!this.narrating?{type:"none"}:(this.narrating=!1,{type:"resume"})}onUserPause(){this.active&&(this.narrating=!1,this.lastCueKey=null)}onUserSeek(){this.onUserPause()}onSegmentEnded(t){if(!this.active)return{type:"none"};this.narrating=!1,this.lastCueKey=null;const n=this.segmentOrder.indexOf(t),i=n>=0?this.segmentOrder[n+1]:void 0;return i?{type:"advance-segment",segmentId:i}:(this.active=!1,{type:"finish"})}stop(){this.active=!1,this.narrating=!1,this.lastCueKey=null}evaluate(t,n){const i=Hs(this.cues,t,n);if(!i)return{type:"none"};const r=`${i.segmentId}:${i.stepIndex}`;return r===this.lastCueKey?{type:"none"}:(this.lastCueKey=r,this.narrating=!0,{type:"narrate",cue:i})}}class wi{constructor(t,n){Ge(this,"generation",0);this.synthesis=t,this.createUtterance=n}play(t,n){this.cancel();const i=t.filter(o=>o.text.trim().length>0),r=this.generation,a=qs(this.synthesis.getVoices(),n.language,n.voiceName),s=o=>{var x,f,m,T,z;if(r!==this.generation)return;const c=i[o];if(!c){(x=n.onComplete)==null||x.call(n);return}const d=this.createUtterance(c.text.trim());d.lang=n.language,d.rate=gt(n.rate),d.voice=a,d.onstart=()=>{var E;r===this.generation&&((E=n.onItemStart)==null||E.call(n,c))};const u=()=>s(o+1);d.onend=u,d.onerror=u,(m=(f=this.synthesis).paused)!=null&&m.call(f)&&((z=(T=this.synthesis).resume)==null||z.call(T)),this.synthesis.speak(d)};s(0)}cancel(){this.generation+=1,this.synthesis.cancel()}}const Gs=.5,Ys=2,Xs=1;function gt(e){return typeof e!="number"||!Number.isFinite(e)?Xs:Math.min(Ys,Math.max(Gs,e))}function Si(e,t){var r,a;const n=((r=e.match(/[\u3400-\u9fff]/g))==null?void 0:r.length)??0,i=((a=e.match(/[a-z]/gi))==null?void 0:a.length)??0;return n>=2&&i===0?"zh-CN":i>=3&&n===0?"en-US":t}function qs(e,t,n){var a;const i=(a=t.split("-")[0])==null?void 0:a.toLowerCase();if(n){const s=e.find(o=>o.name===n&&o.lang.toLowerCase().startsWith(`${i}-`));if(s&&Ae(s)>0||s&&!ki(e,t))return s}const r=e.filter(s=>s.lang.toLowerCase()===t.toLowerCase()).sort((s,o)=>Ae(o)-Ae(s))[0];return r||(e.filter(s=>s.lang.toLowerCase().startsWith(`${i}-`)).sort((s,o)=>Ae(o)-Ae(s))[0]??null)}function ki(e,t){var i;const n=(i=t.split("-")[0])==null?void 0:i.toLowerCase();return e.some(r=>r.lang.toLowerCase().startsWith(`${n}-`)&&Ae(r)>0)}function Ks(e,t){var i;const n=(i=t.split("-")[0])==null?void 0:i.toLowerCase();return e.filter(r=>r.lang.toLowerCase().startsWith(`${n}-`)).sort((r,a)=>Ae(a)-Ae(r))}function Ae(e){return(/^Google\b/i.test(e.name??"")?0:100)+(e.localService?2:0)+(e.default?1:0)}function Qs(e){return Math.min(15e3,2e3+300*e.length)}function on(e,t){return t==="local"&&Object.prototype.hasOwnProperty.call(e,Ei)}function _n(e){return e==="ok"||e==="partial"}function Zs(e,t,n=new Set){const i=new Map(t.map(r=>[r.segmentId,r.url]));return e.flatMap((r,a)=>{const s=i.get(r.id);return!s||n.has(r.id)?[]:[{index:a,segment:r,url:s,durationMs:nl(r)}]})}function Js(e,t){return t.length===0?null:e&&t.some(n=>n.segment.id===e)?e:t[0].segment.id}function el(e,t,n){const i=n>1?`-${String(t+1).padStart(2,"0")}`:"";return`${Mi(e)}-video${i}.webm`}function tl(e,t=new Date){const n=[t.getFullYear(),String(t.getMonth()+1).padStart(2,"0"),String(t.getDate()).padStart(2,"0")].join("");return`${Mi(e)}-video-merged-${n}.webm`}function Mi(e){return e.replace(/[^a-zA-Z0-9\u4e00-\u9fa5\s-]/g,"").replace(/\s+/g,"-").toLowerCase().slice(0,50)||"tutorial"}function nl(e){if(typeof e.endedAt!="number")return null;const t=e.endedAt-e.startedAt;return t>=0?t:null}const Dn={en:{sectionEyebrow:"Video tutorial",sectionTitle:"Walkthrough preview",loading:"Loading saved video segments. The document preview stays available.",segmentLabel:"Segment",segmentOption:e=>`Segment ${e+1}`,currentUrl:"URL",duration:"Duration",durationUnknown:"Not available",partialStatus:"Some video segments were not captured, but the written guide is complete.",partialWarning:e=>`${e} saved video segment${e===1?"":"s"} could not be loaded.`,failedWarning:"Saved video is unavailable right now. The written guide is still ready.",playbackWarning:"One or more saved video segments could not be played back.",downloadVideo:"Download video",downloadSegment:"Download segment",downloadMergedVideo:"Download merged video",mergeMimeMismatch:"Video segments use different encodings, so they cannot be merged. Download them individually instead.",mergeFailed:"Merged video export failed. Try downloading the segments individually."},zh:{sectionEyebrow:"视频教程",sectionTitle:"录屏预览",loading:"正在加载已保存的视频片段，文档预览仍可继续使用。",segmentLabel:"片段",segmentOption:e=>`片段 ${e+1}`,currentUrl:"网址",duration:"时长",durationUnknown:"暂不可用",partialStatus:"部分视频片段未成功录制，但文档内容仍然完整。",partialWarning:e=>`${e} 个已保存的视频片段暂时无法加载。`,failedWarning:"当前无法使用已保存的视频，但书面文档仍可正常查看。",playbackWarning:"部分已保存的视频片段无法播放。",downloadVideo:"下载视频",downloadSegment:"下载当前片段",downloadMergedVideo:"下载合并视频",mergeMimeMismatch:"各视频片段编码不一致，无法合并导出，请改为逐段下载。",mergeFailed:"合并视频导出失败，请尝试逐段下载。"}},Bn={loading:!0,loadErrorCount:0,loadedSources:[]};function il({session:e,steps:t,activeStepIndex:n,seekRequestToken:i=0,uiLanguage:r,guideLanguage:a=Ne,onActiveStepIndexChange:s}){const o=e.videoManifest??[],c=(r??Ie)==="zh"?Dn.zh:Dn.en,d=h=>$(r??Ie,h),[u,x]=y.useState(Bn),[f,m]=y.useState(null),[T,z]=y.useState([]),[E,D]=y.useState(!1),[R,O]=y.useState(null),[Q,ee]=y.useState(!1),[Y,ie]=y.useState(!1),Z=y.useRef(null),_=y.useRef(null),J=y.useRef(null),H=y.useRef({}),oe=y.useRef(!1),le=y.useRef(!1),k=y.useRef(null),M=o.map(h=>`${h.id}:${h.videoBlobKey}:${h.size}:${h.endedAt??""}`).join("|"),U=typeof window<"u"&&"speechSynthesis"in window&&typeof SpeechSynthesisUtterance<"u",F=a==="zh"?"zh-CN":"en-US";y.useEffect(()=>{var h;m(null),z([]),D(!1),O(null),ie(!1),(h=J.current)==null||h.cancel(),Me()},[e.id,M]),y.useEffect(()=>()=>{var h;(h=J.current)==null||h.cancel(),Me()},[]),y.useEffect(()=>{const h=()=>Ce.getAll().then(P=>{H.current={voiceName:P.ttsVoice||void 0,rate:gt(P.ttsRate)}}).catch(()=>{});h();const C=(P,w)=>{on(P,w)&&h()};return chrome.storage.onChanged.addListener(C),()=>chrome.storage.onChanged.removeListener(C)},[]),y.useEffect(()=>{if(!_n(e.trackBStatus)||o.length===0)return;let h=!1;const C=[];return x(Bn),Promise.all(o.map(async P=>{try{const w=await Pt.get(P.videoBlobKey);if(!w||w.size===0)return{segmentId:P.id,url:null};const pe=URL.createObjectURL(w);return C.push(pe),{segmentId:P.id,url:pe}}catch{return{segmentId:P.id,url:null}}})).then(P=>{if(h)return;const w=P.flatMap(pe=>pe.url?[{segmentId:pe.segmentId,url:pe.url}]:[]);x({loading:!1,loadErrorCount:P.length-w.length,loadedSources:w})}),()=>{h=!0,C.forEach(P=>URL.revokeObjectURL(P))}},[o,M,e.trackBStatus]);const X=y.useMemo(()=>Zs(o,u.loadedSources,new Set(T)),[u.loadedSources,o,T]),fe=Js(f,X),te=y.useMemo(()=>oi(t,o),[o,t]),Se=y.useMemo(()=>Os(te,t),[te,t]),ae=y.useMemo(()=>new Vs(Se,X.map(h=>h.segment.id)),[X,Se]),ne=te.find(h=>h.stepIndex===n)??null,L=X.find(h=>h.segment.id===fe)??null;if(y.useEffect(()=>{fe!==f&&m(fe)},[f,fe]),y.useEffect(()=>{if(ne){if(_.current===n){_.current=null;return}if((L==null?void 0:L.segment.id)!==ne.segmentId){X.some(h=>h.segment.id===ne.segmentId)&&m(ne.segmentId);return}Un(Z.current,ne.startMs)}},[ne,n,X,i,L==null?void 0:L.segment.id]),!_n(e.trackBStatus)||o.length===0)return null;const me=T.length,v=u.loadErrorCount+me,B=e.trackBStatus==="partial",ue=!u.loading&&X.length===0&&v>0,we=!ue&&v>0,He=U&&Se.length>0&&!!L,Ee=Ws(X.map(h=>h.segment.mimeType)),Ve=X.length>=2&&!Ee;function qe(){if(!U)return null;if(!J.current){const h={cancel:()=>window.speechSynthesis.cancel(),getVoices:()=>window.speechSynthesis.getVoices(),speak:C=>window.speechSynthesis.speak(C),paused:()=>window.speechSynthesis.paused,resume:()=>window.speechSynthesis.resume()};J.current=new wi(h,C=>new SpeechSynthesisUtterance(C))}return J.current}function Me(){k.current&&(clearTimeout(k.current),k.current=null)}function ze(h){const C=qe();if(!C)return;O(h.text),_.current=h.stepIndex,s(h.stepIndex);const P=()=>{var pe;ae.onNarrationEnd().type==="resume"&&((pe=Z.current)==null||pe.play().catch(()=>{}))};if(window.speechSynthesis.getVoices().length===0){P();return}const w=Z.current;w&&!w.paused&&(oe.current=!0,w.pause()),C.play([{id:String(h.stepIndex),text:h.text}],{language:Si(h.text,F),voiceName:H.current.voiceName,rate:H.current.rate,onComplete:()=>{Me(),P()}}),Me(),k.current=setTimeout(()=>{var pe;k.current=null,ae.isNarrating&&((pe=J.current)==null||pe.cancel(),P())},Qs(h.text))}function b(){const h=Z.current;if(!h||!fe||!He)return;D(!0);const C=ae.start(fe,h.currentTime*1e3);C.type==="narrate"?ze(C.cue):h.play().catch(()=>{})}function j(){var h,C;ae.stop(),(h=J.current)==null||h.cancel(),Me(),oe.current=!1,le.current=!1,D(!1),O(null),(C=Z.current)==null||C.pause()}function I(h){E&&j(),z(C=>C.includes(h)?C:[...C,h])}function N(h){E&&j(),m(h);const C=te.find(P=>P.segmentId===h);C&&s(C.stepIndex)}function q(h,C){if(ae.isActive){const w=ae.onTimeUpdate(C,h.currentTime*1e3);if(w.type==="narrate"){ze(w.cue);return}}const P=mo(te,C,h.currentTime*1e3);P===null||P===n||(_.current=P,s(P))}function re(h,C){if(!ae.isActive)return;const P=ae.onPlay(C,h.currentTime*1e3);P.type==="narrate"&&ze(P.cue)}function ge(){var h;if(oe.current){oe.current=!1;return}ae.isActive&&(ae.onUserPause(),(h=J.current)==null||h.cancel())}function he(){var h;ae.isActive&&(ae.onUserSeek(),(h=J.current)==null||h.cancel())}function ce(h){if(!ae.isActive)return;const C=ae.onSegmentEnded(h);C.type==="advance-segment"?(le.current=!0,m(C.segmentId)):C.type==="finish"&&(D(!1),O(null))}function G(h,C){if(le.current){le.current=!1,h.currentTime=0,h.play().catch(()=>{});return}(ne==null?void 0:ne.segmentId)===C&&Un(h,ne.startMs)}function W(){if(!L)return;const h=document.createElement("a");h.href=L.url,h.download=el(e.title,L.index,o.length),document.body.appendChild(h),h.click(),h.remove()}async function V(){if(!(!Ee||Q)){ee(!0),ie(!1);try{const h=await Promise.all(X.map(async w=>{const pe=await Pt.get(w.segment.videoBlobKey);if(!pe||pe.size===0)throw new Error(`Missing video blob for segment ${w.segment.id}`);return{blob:pe,mimeType:w.segment.mimeType}})),C=await Fs(h),P=URL.createObjectURL(C.blob);try{const w=document.createElement("a");w.href=P,w.download=tl(e.title),document.body.appendChild(w),w.click(),w.remove()}finally{setTimeout(()=>URL.revokeObjectURL(P),1e3)}}catch{ie(!0)}finally{ee(!1)}}}return l.jsxs("section",{style:en,"aria-label":c.sectionTitle,children:[l.jsxs("div",{style:fi,children:[l.jsxs("div",{children:[l.jsx("div",{style:Jt,children:c.sectionEyebrow}),l.jsx("h2",{style:hi,children:c.sectionTitle})]}),X.length>1&&l.jsxs("label",{style:La,children:[l.jsx("span",{children:c.segmentLabel}),l.jsx("select",{"aria-label":c.segmentLabel,style:{...nt,...Na},value:fe??"",onChange:h=>N(h.target.value),children:X.map(h=>l.jsx("option",{value:h.segment.id,children:c.segmentOption(h.index)},h.segment.id))})]})]}),u.loading&&l.jsx("div",{style:Pa,"aria-live":"polite",children:c.loading}),B&&l.jsx("div",{style:Le("info"),"aria-live":"polite",children:c.partialStatus}),we&&l.jsx("div",{style:Le("warning"),"aria-live":"polite",children:u.loadErrorCount>0?c.partialWarning(u.loadErrorCount):c.playbackWarning}),ue&&l.jsx("div",{style:Le("warning"),"aria-live":"polite",children:c.failedWarning}),Ve&&l.jsx("div",{style:Le("warning"),"aria-live":"polite",children:c.mergeMimeMismatch}),Y&&l.jsx("div",{style:Le("warning"),"aria-live":"polite",children:c.mergeFailed}),!U&&l.jsx("div",{style:Le("warning"),"aria-live":"polite",children:d("preview.syncSpeechUnavailable")}),U&&!u.loading&&L&&Se.length===0&&l.jsx("div",{style:Le("info"),"aria-live":"polite",children:d("preview.syncNoNarration")}),L&&l.jsxs(l.Fragment,{children:[l.jsxs("div",{style:Da,children:[l.jsx("video",{ref:Z,style:_a,src:L.url,controls:!0,controlsList:"nodownload",preload:"metadata",playsInline:!0,onLoadedMetadata:h=>G(h.currentTarget,L.segment.id),onTimeUpdate:h=>q(h.currentTarget,L.segment.id),onPlay:h=>re(h.currentTarget,L.segment.id),onPause:ge,onSeeking:he,onEnded:()=>ce(L.segment.id),onError:()=>I(L.segment.id)},L.segment.id),E&&R&&l.jsx("div",{style:Ba,"aria-live":"polite",children:R})]}),l.jsxs("div",{style:Ua,children:[l.jsxs("div",{style:Mn,children:[l.jsx("span",{style:$n,children:c.currentUrl}),L.segment.navUrl?l.jsx("a",{style:pi,href:L.segment.navUrl,target:"_blank",rel:"noreferrer",children:L.segment.navUrl}):l.jsx("span",{children:e.url})]}),l.jsxs("div",{style:Mn,children:[l.jsx("span",{style:$n,children:c.duration}),l.jsx("span",{children:L.durationMs===null?c.durationUnknown:Fi(Math.max(0,L.durationMs))})]}),l.jsxs("button",{style:{...ke,marginLeft:"auto"},disabled:!E&&!He,onClick:E?j:b,children:[E?l.jsx(Vn,{size:14}):l.jsx(Wi,{size:15}),d(E?"preview.syncStop":"preview.syncPlay")]}),l.jsxs("button",{style:ke,onClick:W,children:[l.jsx(_t,{size:15}),o.length>1?c.downloadSegment:c.downloadVideo]}),X.length>1&&l.jsxs("button",{style:ke,disabled:!Ee||Q,onClick:()=>void V(),children:[l.jsx(_t,{size:15}),c.downloadMergedVideo]})]})]}),!u.loading&&!L&&l.jsx("p",{style:ht,children:c.failedWarning})]})}function Un(e,t){if(!e||e.readyState<1)return;const n=Math.max(0,t/1e3);Math.abs(e.currentTime-n)>.08&&(e.currentTime=n)}function rl({steps:e,activeStepIndex:t,editing:n,uiLanguage:i=Ie,guideLanguage:r=Ne,onPatchStep:a,onActiveStepIndexChange:s,onStepSelect:o}){const[c,d]=y.useState(!1),[u,x]=y.useState([]),[f,m]=y.useState(""),[T,z]=y.useState(1),E=y.useRef(null),D=typeof window<"u"&&"speechSynthesis"in window&&typeof SpeechSynthesisUtterance<"u",R=Math.min(t,Math.max(e.length-1,0)),O=e[R],Q=r==="zh"?"zh-CN":"en-US",ee=y.useMemo(()=>e.map(k=>ol(k)),[e]),Y=y.useMemo(()=>Ks(u,Q),[Q,u]),ie=Y.find(k=>k.name===f),Z=ie&&(Ae(ie)>0||!ki(u,Q))?f:"";if(y.useEffect(()=>{t!==R&&s(R)},[t,s,R]),y.useEffect(()=>()=>{var k;return(k=E.current)==null?void 0:k.cancel()},[]),y.useEffect(()=>{if(!D)return;const k=()=>x(window.speechSynthesis.getVoices());return k(),window.speechSynthesis.addEventListener("voiceschanged",k),()=>window.speechSynthesis.removeEventListener("voiceschanged",k)},[D]),y.useEffect(()=>{const k=(U,F)=>{m(U??""),z(gt(F))};Ce.getAll().then(U=>k(U.ttsVoice,U.ttsRate)).catch(()=>{});const M=(U,F)=>{on(U,F)&&Ce.getAll().then(X=>k(X.ttsVoice,X.ttsRate)).catch(()=>{})};return chrome.storage.onChanged.addListener(M),()=>chrome.storage.onChanged.removeListener(M)},[]),!O||e.length===0)return null;const _=k=>$(i,k);function J(){if(!D)return null;if(!E.current){const k={cancel:()=>window.speechSynthesis.cancel(),getVoices:()=>window.speechSynthesis.getVoices(),speak:M=>window.speechSynthesis.speak(M),paused:()=>window.speechSynthesis.paused,resume:()=>window.speechSynthesis.resume()};E.current=new wi(k,M=>new SpeechSynthesisUtterance(M))}return E.current}function H(k){const M=J();M&&(d(!0),M.play(k,{language:Si(k.map(U=>U.text).join(" "),Q),voiceName:Z||void 0,rate:T,onItemStart:U=>{const F=Number(U.id);Number.isNaN(F)||s(F)},onComplete:()=>d(!1)}))}function oe(){var k;(k=E.current)==null||k.cancel(),d(!1)}function le(k){oe();const M=Math.max(0,Math.min(e.length-1,R+k));o?o(M):s(M)}return l.jsxs("section",{style:en,"aria-label":_("preview.voiceoverTitle"),children:[l.jsxs("div",{style:fi,children:[l.jsxs("div",{children:[l.jsx("div",{style:Jt,children:_("preview.voiceover")}),l.jsx("h2",{style:hi,children:_("preview.voiceoverTitle")})]}),l.jsxs("div",{style:Wa,children:[l.jsx("button",{style:Qe,disabled:R===0,onClick:()=>le(-1),title:_("preview.previousVoiceStep"),"aria-label":_("preview.previousVoiceStep"),children:l.jsx(Gn,{size:15})}),l.jsxs("span",{style:Fa,children:[_("preview.voiceStep")," ",R+1," / ",e.length]}),l.jsx("button",{style:Qe,disabled:R===e.length-1,onClick:()=>le(1),title:_("preview.nextVoiceStep"),"aria-label":_("preview.nextVoiceStep"),children:l.jsx(Yn,{size:15})})]})]}),l.jsx(Ye,{value:ee[R],editing:n,multiline:!0,placeholder:_("preview.voicePlaceholder"),onChange:k=>a(R,{voiceScript:k}),style:ht,inputStyle:{...mt,minHeight:58,padding:"8px 9px"}},`voice-script-${R}-${O.stepNumber}`),!D&&l.jsx("div",{style:Le("warning"),children:_("preview.voiceUnavailable")}),l.jsxs("div",{style:Oa,children:[D&&Y.length>0&&l.jsxs("label",{style:Cn,children:[l.jsx("span",{children:_("preview.voice")}),l.jsxs("select",{style:{...nt,width:240,minHeight:36,fontSize:13},value:Z,onChange:k=>{const M=k.target.value;m(M),Ce.set("ttsVoice",M).catch(()=>{})},children:[l.jsx("option",{value:"",children:_("preview.automaticVoice")}),Y.map(k=>l.jsxs("option",{value:k.name,children:[k.name," (",k.lang,")"]},`${k.name}-${k.lang}`))]})]}),D&&l.jsxs("label",{style:Cn,children:[l.jsx("span",{children:_("preview.voiceRate")}),l.jsx("input",{type:"range",min:.5,max:2,step:.25,value:T,style:{width:110},onChange:k=>{const M=gt(Number(k.target.value));z(M),Ce.set("ttsRate",M).catch(()=>{})}}),l.jsxs("span",{children:[T,"×"]})]}),l.jsxs("button",{style:ke,disabled:!D||!ee[R].trim(),onClick:()=>H([{id:String(R),text:ee[R]}]),children:[l.jsx(Tr,{size:15}),_("preview.readCurrent")]}),l.jsxs("button",{style:ke,disabled:!D||ee.every(k=>!k.trim()),onClick:()=>H(ee.map((k,M)=>({id:String(M),text:k}))),children:[l.jsx(ur,{size:15}),_("preview.readAll")]}),l.jsxs("button",{style:ke,disabled:!c,onClick:oe,children:[l.jsx(Vn,{size:14}),_("preview.stopVoice")]})]})]})}const ol=vi;function Nt(e){const t=new Set;return e.map((n,i)=>{var a;let r=(a=n.id)==null?void 0:a.trim();return(!r||t.has(r))&&(r=dl(n,i,t)),t.add(r),n.id===r?n:{...n,id:r}})}function al(e,t){return e.filter((n,i)=>i!==t).map((n,i)=>({...n,stepNumber:i+1}))}function sl(e,t){const n=xt(e,t);return n<0?e:al(e,n)}function ll(e,t,n){const i=xt(e,t),r=i+n;if(i<0||r<0||r>=e.length)return e;const a=[...e];return[a[i],a[r]]=[a[r],a[i]],a.map((s,o)=>({...s,stepNumber:o+1}))}function xt(e,t){return e.findIndex(n=>Ze(n)===t)}function cl(e,t,n){const i=Math.max(0,Math.min(n,e.length));return[...e.slice(0,i),{...t},...e.slice(i)].map((r,a)=>({...r,stepNumber:a+1}))}function Ze(e){return e.id||`${e.screenshotId||"no-shot"}:${e.timestamp}:${e.selector||e.actionType}`}function dl(e,t,n){const i=`${e.screenshotId||""}|${e.timestamp}|${e.selector||""}|${e.actionType}|${e.title}|${t}`;let r=2166136261;for(let c=0;c<i.length;c+=1)r^=i.charCodeAt(c),r=Math.imul(r,16777619);const a=`step-${(r>>>0).toString(36)}`;let s=a,o=2;for(;n.has(s);)s=`${a}-${o}`,o+=1;return s}class ul{constructor(){Ge(this,"tail",Promise.resolve())}enqueue(t,n){this.tail=this.tail.then(t).catch(i=>{n==null||n(i)})}whenIdle(){return this.tail}}const pl=10;function fl(e,t=pl){const n=Math.max(0,Math.floor(e)),i=Math.max(1,Math.floor(t)),r=[];for(let a=0;a<n;a+=i){const s=Math.min(n-1,a+i-1);r.push({startIndex:a,endIndex:s,stepIndexes:Array.from({length:s-a+1},(o,c)=>a+c)})}return r}function hl(e){const t=Math.max(0,e),n=t/(1024*1024);return n>=1?`${n.toFixed(n>=10?0:1)} MB`:`${Math.max(1,Math.round(t/1024))} KB`}function ml(e,t){const n=new Map(t.steps.map(i=>[Ze(i),i]));return{...e,title:t.title,outline:t.outline,documentStatus:t.documentStatus,refinement:t.refinement,steps:e.steps.map((i,r)=>gl(i,n.get(Ze(i)),r))}}function gl(e,t,n){return t?{...e,stepNumber:n+1,title:t.title,description:t.description,voiceScript:t.voiceScript,generatedVoiceScript:t.generatedVoiceScript,voiceoverMode:t.voiceoverMode}:{...e,stepNumber:n+1}}function xl(){var sn;const e=new URLSearchParams(typeof location<"u"?location.search:""),t=e.get("sessionId"),n=e.get("edit")==="1",[i,r]=y.useState(null),[a,s]=y.useState(null),[o,c]=y.useState(null),[d,u]=y.useState(n),[x,f]=y.useState(!1),[m,T]=y.useState(!1),[z,E]=y.useState(null),[D,R]=y.useState(!0),[O,Q]=y.useState(null),[ee,Y]=y.useState(null),[ie,Z]=y.useState(0),[_,J]=y.useState(0),[H,oe]=y.useState(!1),[le,k]=y.useState(null),[M,U]=y.useState(null),[F,X]=y.useState(null),fe=y.useRef(null),te=y.useRef(null),Se=y.useRef(null),ae=y.useRef(new ul),ne=y.useRef(null),L=y.useRef(null);y.useEffect(()=>{fe.current=i},[i]),y.useEffect(()=>()=>{ne.current!==null&&window.clearTimeout(ne.current),L.current!==null&&window.clearTimeout(L.current)},[]),y.useEffect(()=>{const p=document.documentElement,g=Wt(o==null?void 0:o.themeColor);p.style.setProperty("--fs-brand",g),p.style.setProperty("--fs-focus",Ot(g,o==null?void 0:o.focusColor))},[o==null?void 0:o.themeColor,o==null?void 0:o.focusColor]),y.useEffect(()=>{let p=!1;return(async()=>{const g=await Ce.getAll().catch(()=>null);if(!p){if(c(g),Se.current=(g==null?void 0:g.guideLanguage)??Ne,!t){R(!1);return}try{const S=await kn(t,(g==null?void 0:g.guideLanguage)??Ne);if(p)return;if(!S){E($(g==null?void 0:g.uiLanguage,"preview.loadFailed")),R(!1);return}r(S.session);const A={...S.guide,steps:Nt(S.guide.steps)};te.current=A,s(A),me(A),R(!1)}catch{if(p)return;E($(g==null?void 0:g.uiLanguage,"preview.loadError")),R(!1)}}})(),()=>{p=!0}},[t]),y.useEffect(()=>{const p=(g,S)=>{on(g,S)&&Ce.getAll().then(async A=>{if(c(A),!t||A.guideLanguage===Se.current)return;const xe=await kn(t,A.guideLanguage);if(!xe)return;Se.current=A.guideLanguage,r(xe.session);const Re={...xe.guide,steps:Nt(xe.guide.steps)};te.current=Re,s(Re),me(Re)}).catch(()=>{})};return chrome.storage.onChanged.addListener(p),()=>chrome.storage.onChanged.removeListener(p)},[t]);function me(p){t&&chrome.runtime.sendMessage({action:"GUIDE_STEP_COUNT_UPDATE",payload:{sessionId:t,stepCount:p.steps.length}}).catch(()=>{})}function v(p){const g={...p,steps:Nt(p.steps)};te.current=g,s(g),me(g);const S=fe.current;S&&ae.current.enqueue(()=>pa(S,g),()=>E($(o==null?void 0:o.uiLanguage,"preview.saveFailed")))}function B(p){const g=te.current;if(!g)return null;const S=p(g);return S!==g&&v(S),S}function ue(p,g){const S=te.current,A=S==null?void 0:S.steps[p];A&&we(Ze(A),g)}function we(p,g){B(S=>{const A=xt(S.steps,p);if(A<0)return S;const xe=S.steps.map((Re,yt)=>yt===A?{...Re,...g}:Re);return{...S,steps:xe}})}function He(p,g){B(S=>({...S,screenshots:S.screenshots.map(A=>A.id===p?{...A,...g}:A)}))}function Ee(p){B(g=>({...g,outline:{...g.outline??{},...p}}))}function Ve(p,g){const S=te.current;if(!S)return;const A=ll(S.steps,p,g);A!==S.steps&&(v({...S,steps:A}),Y(p),L.current!==null&&window.clearTimeout(L.current),L.current=window.setTimeout(()=>{Y(null),L.current=null},500))}function qe(p){const g=te.current;if(!g)return;const S=xt(g.steps,p),A=g.steps[S];if(S<0||!A)return;const xe=sl(g.steps,p);v({...g,steps:xe}),X({step:A,index:S}),ne.current!==null&&window.clearTimeout(ne.current),ne.current=window.setTimeout(()=>{X(null),ne.current=null},6e3)}function Me(){const p=te.current;if(!p||!F)return;const g=cl(p.steps,F.step,F.index);v({...p,steps:g}),X(null),ne.current!==null&&(window.clearTimeout(ne.current),ne.current=null)}async function ze(){const p=te.current;if(!p||!i)return;const g=await Ce.getAll();if(c(g),!ln(g)){E($(g.uiLanguage,"preview.noModelNotice"));return}const S=Ri(g);if(console.log("[StepMark] refine (page fetch)",{provider:S.aiProvider,hasKey:!!S.apiKey,model:S.aiModel,endpoint:S.apiEndpoint||"(default → normalized)"}),S.aiProvider==="mock"){E("Mock mode does not call an API. Configure a real model in Settings.");return}f(!0),E(null);try{const A=await Bi(i,p,{settings:S}),xe=te.current;v(xe&&xe!==p?ml(xe,A):A),u(!1)}catch(A){E(String(A))}finally{f(!1)}}async function b(){const p=await Ce.getAll().catch(()=>null);return p&&c(p),p??o}function j(p=o,g={}){if(!a)throw new Error("Guide is unavailable");const S=a.language;return ho(a,{selectedStepIndexes:g.selectedStepIndexes??a.steps.map((A,xe)=>xe),includeSummary:!0,includeSource:!1,includeScreenshots:g.includeScreenshots??!0,includeNarration:!1,screenshotMode:"annotated",themeColor:(p==null?void 0:p.themeColor)??"#2563eb",focusColor:(p==null?void 0:p.focusColor)??"",focusShape:(p==null?void 0:p.focusShape)??"circle",language:S??(p==null?void 0:p.guideLanguage)??Ne})}async function I(p,g,S=!0){if(H)return!1;oe(!0),k(null),E(null);try{return await co(p,void 0,{includeHeader:S}),k(g),!0}catch{return E($(o==null?void 0:o.uiLanguage,"materials.copyFailed")),!1}finally{oe(!1)}}function N(){if(!a||H)return;const p=j(),g=so(p);if(g.shouldWarn){k(null),U({assessment:g,batches:fl(a.steps.length),activeBatchIndex:0});return}I(p,$(o==null?void 0:o.uiLanguage,"materials.copied"))}async function q(){if(!M)return;const p=M.batches[M.activeBatchIndex];if(!p)return;const g=M.activeBatchIndex<M.batches.length-1;await I(j(o,{selectedStepIndexes:p.stepIndexes}),$(o==null?void 0:o.uiLanguage,g?"materials.segmentCopied":"materials.finalSegmentCopied"),M.activeBatchIndex===0)&&U(A=>A?{...A,activeBatchIndex:Math.min(A.batches.length-1,A.activeBatchIndex+1)}:null)}function re(){I(j(o,{includeScreenshots:!1}),$(o==null?void 0:o.uiLanguage,"materials.textCopied"))}async function ge(){await I(j(),$(o==null?void 0:o.uiLanguage,"materials.copied"))&&U(null)}async function he(p){if(!a)return;const g=await b(),S=We.export(a,p,{themeColor:g==null?void 0:g.themeColor,focusColor:g==null?void 0:g.focusColor,focusShape:g==null?void 0:g.focusShape}),A=new Blob([S.content],{type:S.mimeType});G(A,S.filename)}async function ce(){if(!(!a||!i||m)){T(!0),E(null);try{const p=[];for(const S of i.videoManifest??[]){const A=await Pt.get(S.videoBlobKey);A!=null&&A.size&&p.push({segment:S,blob:A})}const g=await xo(a,i,p);G(new Blob([g.content],{type:g.mimeType}),g.filename)}catch(p){E(`${$(o==null?void 0:o.uiLanguage,"preview.tutorialExportFailed")}: ${String(p)}`)}finally{T(!1)}}}function G(p,g){const S=URL.createObjectURL(p),A=document.createElement("a");A.href=S,A.download=g,document.body.appendChild(A),A.click(),A.remove(),URL.revokeObjectURL(S)}async function W(){if(!a)return;const p=await b(),g=We.export(a,"pdf",{themeColor:p==null?void 0:p.themeColor,focusColor:p==null?void 0:p.focusColor,focusShape:p==null?void 0:p.focusShape}),S=window.open("","_blank");if(!S){E("Unable to open the print window. Please check popup blocking settings.");return}S.document.open(),S.document.write(g.content),S.document.close(),S.onload=()=>S.print()}function V(){chrome.runtime.openOptionsPage()}if(D)return l.jsx("div",{style:Ct,children:l.jsx("div",{style:Tt,children:l.jsx("div",{style:At,children:$(Ie,"preview.loading")})})});if(!a||!i)return l.jsx("div",{style:Ct,children:l.jsx("div",{style:Tt,children:l.jsx("div",{style:At,children:z??$(Ie,"preview.empty")})})});const h=p=>p.screenshotId?a.screenshots.find(g=>g.id===p.screenshotId):void 0,C=o?zi(o):void 0,P=o?ln(o):!1,w=p=>$(o==null?void 0:o.uiLanguage,p),pe=a.language??(o==null?void 0:o.guideLanguage)??Ne,be=p=>$(pe,p),bt=M==null?void 0:M.batches[M.activeBatchIndex],Ci=C?`${w("preview.currentModel")}: ${C.name} · ${C.aiModel||w("preview.noModel")}`:w("preview.noModel"),an=l.jsxs(l.Fragment,{children:[l.jsx("h2",{style:Ha,children:be("preview.toc")}),l.jsx("ol",{style:Va,children:a.steps.map((p,g)=>l.jsx("li",{style:Ga,children:l.jsxs("a",{style:i.tutorialMode==="video_tutorial"&&g===ie?{...Tn,background:"color-mix(in srgb, var(--fs-brand) 10%, #ffffff)",color:"var(--fs-brand)",fontWeight:750}:Tn,href:`#step-${p.stepNumber}`,"aria-current":i.tutorialMode==="video_tutorial"&&g===ie?"step":void 0,onClick:()=>{i.tutorialMode==="video_tutorial"&&(Z(g),J(S=>S+1))},children:[be("preview.steps")," ",p.stepNumber,": ",p.title]})},p.stepNumber))})]});return l.jsxs("div",{style:Ct,children:[l.jsxs("div",{style:Tt,children:[l.jsxs("div",{style:Sa,children:[l.jsxs("div",{style:ka,children:[l.jsx("div",{style:Ma,"aria-hidden":"true",children:"SP"}),l.jsxs("div",{style:{minWidth:0},children:[l.jsx("div",{style:$a,children:a.title}),l.jsx("div",{style:Ca,children:w(d?"preview.editMode":"preview.readMode")})]})]}),l.jsxs("button",{style:ja(d),onClick:()=>u(p=>!p),children:[d?l.jsx(qi,{size:15}):l.jsx(mr,{size:15}),w(d?"preview.doneEditing":"preview.edit")]}),l.jsxs("button",{style:Ta(x||!o||!P),disabled:x||!o||!P,onClick:ze,title:w("preview.aiPolishTitle"),children:[l.jsx(Sr,{size:15}),w(o?x?"preview.polishing":"preview.aiPolish":"preview.loadingSettings")]}),l.jsxs("button",{style:{...ke,opacity:H?.6:1},disabled:H,onClick:N,title:w("materials.copyDocumentTitle"),children:[l.jsx(vt,{size:15}),w(H?"materials.copying":"materials.copyDocument")]}),l.jsxs("button",{style:ke,onClick:()=>void he("html"),title:w("preview.downloadDocumentHtmlTitle"),children:[l.jsx(_t,{size:15}),w("preview.downloadDocumentHtml")]}),i.tutorialMode==="video_tutorial"&&(((sn=i.videoManifest)==null?void 0:sn.length)??0)>0&&l.jsxs("button",{style:{...ke,opacity:m?.6:1},disabled:m,onClick:()=>void ce(),title:w("preview.downloadTutorialHtmlTitle"),children:[l.jsx(sr,{size:15}),w(m?"preview.exportingTutorialHtml":"preview.downloadTutorialHtml")]}),l.jsxs("button",{style:ke,onClick:()=>void W(),title:w("preview.printPdfTitle"),children:[l.jsx(or,{size:15}),"PDF"]}),l.jsxs("button",{style:{...ke,marginLeft:"auto"},onClick:V,children:[l.jsx(cn,{size:15}),w("common.settings")]})]}),M&&bt&&l.jsxs("section",{style:bl,"aria-label":w("materials.longGuideTitle"),children:[l.jsxs("div",{style:yl,children:[l.jsxs("div",{children:[l.jsx("div",{style:vl,children:w("materials.longGuideTitle")}),l.jsx("div",{style:wl,children:w("materials.longGuideHint")})]}),l.jsx("button",{type:"button",style:Cl,"aria-label":w("materials.closePlan"),title:w("materials.closePlan"),onClick:()=>U(null),children:l.jsx(Ar,{size:17})})]}),l.jsxs("div",{style:Sl,children:[a.steps.length," ",w("preview.steps")," · ",M.assessment.screenshotCount," ",w("materials.screenshots")," · ~",hl(M.assessment.estimatedSourceBytes)]}),l.jsxs("div",{style:kl,children:[l.jsxs("div",{style:Ml,children:[l.jsx("button",{type:"button",style:Fn,disabled:M.activeBatchIndex===0,"aria-label":w("materials.previousSegment"),title:w("materials.previousSegment"),onClick:()=>U(p=>p?{...p,activeBatchIndex:Math.max(0,p.activeBatchIndex-1)}:null),children:l.jsx(Gn,{size:16})}),l.jsxs("span",{style:$l,children:[(o==null?void 0:o.uiLanguage)==="zh"?`${M.activeBatchIndex+1}/${M.batches.length} ${w("materials.segment")}`:`${w("materials.segment")} ${M.activeBatchIndex+1}/${M.batches.length}`," · ",w("preview.steps")," ",bt.startIndex+1,"–",bt.endIndex+1]}),l.jsx("button",{type:"button",style:Fn,disabled:M.activeBatchIndex>=M.batches.length-1,"aria-label":w("materials.nextSegment"),title:w("materials.nextSegment"),onClick:()=>U(p=>p?{...p,activeBatchIndex:Math.min(p.batches.length-1,p.activeBatchIndex+1)}:null),children:l.jsx(Yn,{size:16})})]}),l.jsxs("button",{type:"button",style:$i,disabled:H,onClick:()=>void q(),children:[l.jsx(vt,{size:16}),w(H?"materials.copying":"materials.copySegment")]}),l.jsxs("button",{type:"button",style:Wn,disabled:H,onClick:re,children:[l.jsx(Oi,{size:16}),w("materials.copyTextOnly")]}),l.jsxs("button",{type:"button",style:Wn,disabled:H,onClick:()=>void ge(),children:[l.jsx(vt,{size:16}),w("materials.copyAllAnyway")]})]})]}),le&&l.jsxs("div",{role:"status",style:Tl,children:[l.jsx(Ji,{size:18}),l.jsx("span",{children:le})]}),F&&l.jsxs("div",{role:"status",style:jl,children:[l.jsxs("span",{children:[be("step.deleted")," ",F.step.stepNumber,": ",F.step.title]}),l.jsxs("button",{style:Al,onClick:Me,children:[l.jsx($r,{size:15}),be("step.undo")]})]}),o&&!P&&l.jsxs("div",{style:It(!1),children:[w("preview.noModelNotice"),l.jsxs("button",{style:{...ke,marginLeft:10},onClick:V,children:[l.jsx(cn,{size:15}),w("preview.openSettings")]})]}),x&&o&&C&&l.jsxs("div",{style:It(!0),children:[w("preview.polishNotice")," ",C.name," · ",C.aiModel||w("preview.noModel"),". ",w("preview.doNotClose"),_i(C.aiModel)?` ${w("preview.visionSlow")}`:Di(C.aiModel)?` ${w("preview.reasoningSlow")}`:""]}),!x&&o&&P&&l.jsx("div",{style:cs,children:Ci}),z&&l.jsx("div",{style:In,children:z}),a.captureFailureReason&&l.jsxs("div",{style:In,children:[w("preview.captureIssue"),": ",a.captureFailureReason]}),a.truncatedSteps?l.jsx("div",{style:It(!1),children:w("preview.truncatedNotice").replace("{count}",String(a.truncatedSteps))}):null,l.jsxs("div",{className:"fs-preview-layout",style:va,children:[l.jsxs("div",{className:"fs-preview-main",style:wa,children:[l.jsx(il,{session:i,steps:a.steps,activeStepIndex:ie,seekRequestToken:_,uiLanguage:o==null?void 0:o.uiLanguage,guideLanguage:o==null?void 0:o.guideLanguage,onActiveStepIndexChange:Z}),i.tutorialMode==="video_tutorial"&&l.jsx(rl,{steps:a.steps,activeStepIndex:ie,editing:d,uiLanguage:o==null?void 0:o.uiLanguage,guideLanguage:o==null?void 0:o.guideLanguage,onPatchStep:ue,onActiveStepIndexChange:Z,onStepSelect:p=>{Z(p),J(g=>g+1)}}),l.jsxs("section",{style:Aa,children:[l.jsx("div",{style:Ia,"aria-hidden":"true"}),l.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10,marginBottom:8},children:[l.jsx("div",{style:Jt,children:be("preview.document")}),a.documentStatus&&jt[a.documentStatus]&&l.jsx("span",{style:{...Ra,background:jt[a.documentStatus].bg,color:jt[a.documentStatus].text},children:be(`preview.status.${a.documentStatus}`)})]}),l.jsx(Ye,{value:a.title,editing:d,placeholder:be("preview.titlePlaceholder"),onChange:p=>B(g=>({...g,title:p})),style:Ea,inputStyle:{...nt,fontSize:28,fontWeight:800}}),l.jsxs("div",{style:za,children:[i.url?l.jsxs("a",{style:pi,href:i.url,target:"_blank",rel:"noopener noreferrer",title:w("preview.openUrl"),children:[l.jsx(cr,{size:14,style:{verticalAlign:-2,marginRight:4}}),i.url]}):l.jsx("span",{children:be("preview.urlNA")}),l.jsxs("span",{children:[be("preview.updated"),": ",new Date(a.createdAt).toLocaleString()]})]})]}),a.outline&&l.jsxs("section",{style:en,children:[a.outline.purpose!==void 0&&l.jsxs("div",{style:{marginBottom:10},children:[l.jsx("div",{style:jn,children:be("preview.purpose")}),l.jsx(Ye,{value:a.outline.purpose,editing:d,multiline:!0,onChange:p=>Ee({purpose:p}),style:ht,inputStyle:mt})]}),a.outline.summary!==void 0&&l.jsxs("div",{style:{marginBottom:10},children:[l.jsx("div",{style:jn,children:be("preview.summary")}),l.jsx(Ye,{value:a.outline.summary,editing:d,multiline:!0,onChange:p=>Ee({summary:p}),style:ht,inputStyle:mt})]})]}),a.steps.length>0&&l.jsx("nav",{className:"fs-preview-toc-mobile",style:Ya,"aria-label":be("preview.tocAria"),children:an}),l.jsxs("section",{style:Xa,children:[l.jsx("h2",{style:qa,children:be("preview.steps")}),a.steps.map((p,g)=>{const S=Ze(p);return l.jsx(hs,{step:p,screenshot:h(p),editing:d,defaultFocusShape:(o==null?void 0:o.focusShape)??"circle",uiLanguage:pe,justMoved:ee===S,canUp:g>0,canDown:g<a.steps.length-1,onPatch:A=>we(S,A),onMoveUp:()=>Ve(S,-1),onMoveDown:()=>Ve(S,1),onDelete:()=>qe(S),onScreenshotPatch:A=>p.screenshotId&&He(p.screenshotId,A),onZoom:(A,xe,Re,yt)=>Q({shot:A,focus:xe,additionalFocuses:Re,annotations:yt})},S)}),a.steps.length===0&&l.jsx("div",{style:At,children:be("preview.noSteps")})]})]}),a.steps.length>0&&l.jsx("nav",{className:"fs-preview-toc",style:mi,"aria-label":be("preview.tocAria"),children:an})]})]}),O&&l.jsx(fs,{screenshot:O.shot,focus:O.focus,additionalFocuses:O.additionalFocuses,annotations:O.annotations,defaultFocusShape:(o==null?void 0:o.focusShape)??"circle",uiLanguage:o==null?void 0:o.uiLanguage,onClose:()=>Q(null)})]})}const bl={marginTop:10,padding:14,border:"1px solid #bfdbfe",borderRadius:8,background:"#eff6ff",color:"#1e3a8a"},yl={display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12},vl={fontSize:14,fontWeight:800},wl={marginTop:3,color:"#476b68",fontSize:12,lineHeight:1.5},Sl={marginTop:9,color:"#1d4ed8",fontSize:12,fontWeight:750},kl={display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",marginTop:12},Ml={display:"inline-flex",alignItems:"center",minHeight:34,border:"1px solid #bfdbfe",borderRadius:7,background:"#fff"},$l={minWidth:150,padding:"0 8px",textAlign:"center",color:"#234e4a",fontSize:12,fontWeight:750},Fn={display:"inline-flex",alignItems:"center",justifyContent:"center",width:32,height:32,padding:0,border:0,background:"transparent",color:"#1d4ed8",cursor:"pointer"},$i={display:"inline-flex",alignItems:"center",gap:7,minHeight:34,padding:"7px 11px",border:"1px solid #2563eb",borderRadius:7,background:"#2563eb",color:"#fff",font:"inherit",fontSize:12,fontWeight:800,cursor:"pointer"},Wn={...$i,border:"1px solid #bfdbfe",background:"#fff",color:"#234e4a"},Cl={display:"inline-flex",alignItems:"center",justifyContent:"center",width:32,height:32,flex:"0 0 32px",padding:0,border:"1px solid #bfdbfe",borderRadius:7,background:"#fff",color:"#476b68",cursor:"pointer"},Tl={marginTop:10,display:"flex",alignItems:"center",gap:8,padding:"11px 13px",border:"1px solid #93c5fd",borderRadius:7,background:"#ecfdf5",color:"#1d4ed8",fontSize:14,fontWeight:750,boxShadow:"0 8px 20px -16px rgba(15, 118, 110, .65)"},jl={marginTop:10,display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,padding:"10px 13px",border:"1px solid #fecdd3",borderRadius:7,background:"#fff1f2",color:"#9f1239",fontSize:14,fontWeight:700},Al={display:"inline-flex",alignItems:"center",gap:6,padding:"6px 9px",border:"1px solid #fda4af",borderRadius:6,background:"#fff",color:"#9f1239",font:"inherit",fontWeight:750,cursor:"pointer"};Li.createRoot(document.getElementById("root")).render(l.jsx(xl,{}));
