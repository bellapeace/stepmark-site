var zi=Object.defineProperty;var Ri=(e,t,n)=>t in e?zi(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n;var Xe=(e,t,n)=>Ri(e,typeof t!="symbol"?t+"":t,n);import"./index-Dks-HI8O.js";import{n as Pe,s as Ae,I as Ue,M as ve,o as Yn,p as Li,B as Ni,L as Ht,S as Xn,a as x,j as l,t as $,D as ze,q as Pi,g as _i,v as fn,w as Di,l as Bi}from"./theme-B224iPtC.js";import{n as tt,C as Ui,R as Fi,i as Wi,a as Oi,r as Hi}from"./GuideRefiner-CIex_dqW.js";import{o as Vi,v as Bt}from"./videoStore-B_VD-dao.js";import{c as ce}from"./createLucideIcon-J7DFeaYk.js";import{f as Gi}from"./utils-zwI8c19Y.js";import{S as qn,P as Yi,a as hn,F as Xi}from"./square-XaUbwN9P.js";/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const qi=[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]],Ki=ce("arrow-down",qi);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Qi=[["path",{d:"m5 12 7-7 7 7",key:"hav0vg"}],["path",{d:"M12 19V5",key:"x0mq9r"}]],Zi=ce("arrow-up",Qi);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ji=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],er=ce("check",Ji);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tr=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],Kn=ce("chevron-left",tr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nr=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],Qn=ce("chevron-right",nr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ir=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],rr=ce("circle-check",ir);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const or=[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2",key:"4jdomd"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v4",key:"3hqy98"}],["path",{d:"M21 14H11",key:"1bme5i"}],["path",{d:"m15 10-4 4 4 4",key:"5dvupr"}]],St=ce("clipboard-copy",or);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ar=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"22",x2:"18",y1:"12",y2:"12",key:"l9bcsi"}],["line",{x1:"6",x2:"2",y1:"12",y2:"12",key:"13hhkx"}],["line",{x1:"12",x2:"12",y1:"6",y2:"2",key:"10w3f3"}],["line",{x1:"12",x2:"12",y1:"22",y2:"18",key:"15g9kq"}]],sr=ce("crosshair",ar);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lr=[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]],Ut=ce("download",lr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const cr=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M12 18v-6",key:"17g6i2"}],["path",{d:"m9 15 3 3 3-3",key:"1npd3o"}]],dr=ce("file-down",cr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ur=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M15.033 13.44a.647.647 0 0 1 0 1.12l-4.065 2.352a.645.645 0 0 1-.968-.56v-4.704a.645.645 0 0 1 .967-.56z",key:"1tzo1f"}]],pr=ce("file-play",ur);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fr=[["path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",key:"1cjeqo"}],["path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",key:"19qd67"}]],hr=ce("link",fr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const mr=[["path",{d:"M21 5H3",key:"1fi0y6"}],["path",{d:"M10 12H3",key:"1ulcyk"}],["path",{d:"M10 19H3",key:"108z41"}],["path",{d:"M15 12.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997a1 1 0 0 1-1.517-.86z",key:"ms4nik"}]],gr=ce("list-video",mr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const xr=[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}],["path",{d:"M12 8v6",key:"1ib9pf"}],["path",{d:"M9 11h6",key:"1fldmi"}]],br=ce("message-square-plus",xr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const yr=[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]],vr=ce("pencil",yr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const wr=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],Sr=ce("plus",wr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const kr=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],Mr=ce("rotate-ccw",kr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $r=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],kt=ce("shield",$r);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Cr=[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],Tr=ce("sparkles",Cr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jr=[["path",{d:"M10 11v6",key:"nco0om"}],["path",{d:"M14 11v6",key:"outv1u"}],["path",{d:"M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6",key:"miytrc"}],["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2",key:"e791ji"}]],ot=ce("trash-2",jr);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Ar=[["path",{d:"M9 14 4 9l5-5",key:"102s5s"}],["path",{d:"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",key:"f3b9sd"}]],Ir=ce("undo-2",Ar);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Er=[["path",{d:"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",key:"uqj9uw"}],["path",{d:"M16 9a5 5 0 0 1 0 6",key:"1q6k2b"}],["path",{d:"M19.364 18.364a9 9 0 0 0 0-12.728",key:"ijwkga"}]],zr=ce("volume-2",Er);/**
 * @license lucide-react v1.23.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Rr=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Lr=ce("x",Rr),Nr="#2563eb";function Zn(e){return typeof e=="string"&&/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(e.trim())}function Vt(e){return Zn(e)?e.trim():Nr}function Gt(e,t){return Zn(t)?t.trim():Vt(e)}const Pr=.8,_r=.65,Dr=.42;function Br(e){var t,n;return!e||e.x===void 0||e.y===void 0||!((t=e.viewport)!=null&&t.width)||!((n=e.viewport)!=null&&n.height)?null:{left:`${Ft(mn(e.x/e.viewport.width*100))}%`,top:`${Ft(mn(e.y/e.viewport.height*100))}%`}}function Yt(e,t="circle"){if(!e)return null;if((e.shape??t)==="rectangle"){const r=Wr(e);if(r)return{shape:"rectangle",...r}}const i=Br(e);return i?{shape:"circle",...i}:null}function ut(e){const t=e.viewport;if(!(t!=null&&t.width)||!t.height)return{...e,shape:"rectangle"};const n=e.detectedRect??e.rect,i=e.rect&&(e.rectAdjusted||ei(e.rect,t.width,t.height))?Ke(e.rect,t.width,t.height):null,r=Math.min(220,Math.max(72,t.width*.16)),a=Math.min(100,Math.max(36,t.height*.08)),s=Ke({x:(e.x??t.width/2)-r/2,y:(e.y??t.height/2)-a/2,width:r,height:a},t.width,t.height),o=i??s;return{...e,shape:"rectangle",x:o.x+o.width/2,y:o.y+o.height/2,rect:o,detectedRect:n,rectAdjusted:!i||e.rectAdjusted}}function Jn(e,t,n){const i=ut(e),r=i.viewport,a=i.rect;if(!(r!=null&&r.width)||!r.height||!a)return i;const s=Ke({...a,x:pt(t,0,1)*r.width-a.width/2,y:pt(n,0,1)*r.height-a.height/2},r.width,r.height);return{...i,x:s.x+s.width/2,y:s.y+s.height/2,rect:s,rectAdjusted:!0}}function Ur(e,t,n,i){const r=ut(e),a=r.viewport,s=r.rect;if(!(a!=null&&a.width)||!a.height||!s)return r;const o=Math.max(28,a.width*.025),c=Math.max(22,a.height*.025),d=n*a.width,f=i*a.height;let b=s.x,p=s.x+s.width,m=s.y,T=s.y+s.height;t.includes("left")&&(b=Math.min(p-o,b+d)),t.includes("right")&&(p=Math.max(b+o,p+d)),t.includes("top")&&(m=Math.min(T-c,m+f)),t.includes("bottom")&&(T=Math.max(m+c,T+f));const z=Ke({x:b,y:m,width:p-b,height:T-m},a.width,a.height);return{...r,x:z.x+z.width/2,y:z.y+z.height/2,rect:z,rectAdjusted:!0}}function Fr(e){var n;if(!e.detectedRect||!((n=e.viewport)!=null&&n.width)||!e.viewport.height)return e;const t=Ke(e.detectedRect,e.viewport.width,e.viewport.height);return{...e,x:t.x+t.width/2,y:t.y+t.height/2,rect:t,rectAdjusted:!1}}function Wr(e){const t=e.viewport,n=e.rect;if(!(t!=null&&t.width)||!t.height||!n||!e.rectAdjusted&&!ei(n,t.width,t.height))return null;const i=Ke(n,t.width,t.height);return i.width<=0||i.height<=0?null:Or(i.x/t.width*100,i.y/t.height*100,i.width/t.width*100,i.height/t.height*100)}function ei(e,t,n){if(e.width<6||e.height<6||t<=0||n<=0)return!1;const i=e.width/t,r=e.height/n;return i<=Pr&&r<=_r&&i*r<=Dr}function Ke(e,t,n){const i=Math.min(t,Math.max(1,e.width)),r=Math.min(n,Math.max(1,e.height));return{x:pt(e.x,0,t-i),y:pt(e.y,0,n-r),width:i,height:r}}function mn(e,t=100){return Math.max(0,Math.min(t,e))}function pt(e,t,n){return Math.max(t,Math.min(n,e))}function Or(e,t,n,i){const r=a=>`${Ft(a)}`;return{left:r(e)+"%",top:r(t)+"%",width:r(n)+"%",height:r(i)+"%"}}function Ft(e){return Math.round(e*100)/100}const Mt=5,ti=240,gn=.06;function nt(e){const{focusId:t,...n}=e;return{...n,text:e.text.slice(0,ti),x:ft(e.x,.01,.99),y:ft(e.y,.01,.88)}}function Hr(e,t,n,i={}){const r=nt({...e,x:e.x+t,y:e.y+n});return{...r,x:ft(r.x,.01,i.maxX??.99),y:ft(r.y,.01,i.maxY??.88)}}function Xt(e,t){var o,c;const n=(o=t==null?void 0:t.viewport)==null?void 0:o.width,i=(c=t==null?void 0:t.viewport)==null?void 0:c.height;if((t==null?void 0:t.x)===void 0||t.y===void 0||!n||n<=0||!i||i<=0)return e.x<.5?"right":"left";const r=(t==null?void 0:t.x)!==void 0&&n&&n>0?t.x/n:.5,a=(t==null?void 0:t.y)!==void 0&&i&&i>0?t.y/i:.5,s=e.y-a;return s<=-gn?"down":s>=gn?"up":e.x<r?"right":"left"}function ni(e){const t=nt(e);return{left:`${xn(t.x*100)}%`,top:`${xn(t.y*100)}%`}}function ft(e,t,n){return Math.max(t,Math.min(n,Number.isFinite(e)?e:t))}function xn(e){return Math.round(e*1e3)/1e3}const je="primary",lt=5;function it(e,t=[]){const n=[];e&&n.push({id:je,focus:e,primary:!0});for(const i of t.slice(0,Math.max(0,lt-n.length)))i.id&&n.push({id:i.id,focus:i,primary:!1});return n}function qt(e,t,n=[]){const i=it(t,n).map(s=>s.focus);if(i.length<=1)return i[0];let r,a=Number.POSITIVE_INFINITY;for(const s of i){const o=Vr(s);if(!o)continue;const c=Math.hypot(e.x-o.x,e.y-o.y);c<a&&(r=s,a=c)}return r??i[0]}function Vr(e){const t=e.viewport;if(!(t!=null&&t.width)||!t.height)return;const n=e.x??(e.rect?e.rect.x+e.rect.width/2:void 0),i=e.y??(e.rect?e.rect.y+e.rect.height/2:void 0);if(!(n===void 0||i===void 0))return{x:n/t.width,y:i/t.height}}const ii={includeScreenshots:!0,includeMetadata:!0,includeTableOfContents:!0,includeStepNumbers:!0,includeFooter:!0,printOptimized:!1,themeColor:"#2563eb",focusColor:"",focusShape:"circle"};class $t{static renderMarkdown(t,n={}){var c;const i=bn(n),r=Be(t),a=[`# ${t.title}`,""],s=ai(t);if(i.includeMetadata&&(a.push(`> ${r.url}: ${t.url||"N/A"}`),a.push(`> ${r.updated}: ${new Date(t.createdAt).toLocaleString()}`),a.push("")),t.outline?Jr(a,t):s&&(a.push(`## ${r.summary}`,""),a.push(s,"")),i.includeTableOfContents&&t.steps.length>0){a.push(`## ${r.contents}`,"");for(const d of t.steps)a.push(`- ${Kt(d,i,t.language)} ${d.title}`);a.push("")}const o=tt((c=t.outline)==null?void 0:c.chapters,t.steps);for(const[d,f]of t.steps.entries()){const b=o==null?void 0:o.find(m=>m.startStepNumber===d+1);b&&a.push(`## ${b.title}`,""),a.push(`## ${Zr(f,i,t.language)}`,""),a.push(f.description||"","");const p=ri(t,f);i.includeScreenshots&&p&&a.push(`![${r.step} ${f.stepNumber} ${r.screenshot}](${p.maskedDataUrl||p.dataUrl})`,""),a.push("---","")}return a.join(`
`)}static renderHtml(t,n={}){const i=bn(n),r=Be(t),a=new Date(t.createdAt).toLocaleString();return`<!DOCTYPE html>
<html lang="${t.language==="en"?"en":"zh-CN"}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${ge(t.title)}</title>
  <style>
    :root {
      color-scheme: light;
      --ink: #151c2e;
      --muted: #667085;
      --soft: #f7faf9;
      --panel: #ffffff;
      --line: #e4ece9;
      --brand: ${vn(i.themeColor)};
      --focus: ${vn(i.focusColor)};
      --brand-soft: color-mix(in srgb, var(--brand) 9%, #ffffff);
      --brand-faint: color-mix(in srgb, var(--brand) 5%, #f8fbfa);
      --click-soft: color-mix(in srgb, var(--focus) 14%, #ffffff);
      --shadow-sm: 0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 22px -18px rgba(15, 23, 42, 0.3);
      --shadow-md: 0 18px 44px -26px color-mix(in srgb, var(--brand) 34%, #0f172a);
      --radius-lg: 16px;
      --radius-md: 10px;
    }
    *, *::before, *::after { box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body {
      margin: 0;
      background:
        linear-gradient(180deg, color-mix(in srgb, var(--brand) 9%, #f8fbfa) 0, color-mix(in srgb, var(--brand) 4%, #f8fbfa) 260px, color-mix(in srgb, var(--brand) 6%, #f3f7f6) 100%);
      color: var(--ink);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
      line-height: 1.65;
      -webkit-font-smoothing: antialiased;
    }
    .topbar {
      position: sticky;
      top: 0;
      z-index: 10;
      display: flex;
      align-items: center;
      gap: 12px;
      height: 58px;
      padding: 0 24px;
      border-bottom: 1px solid color-mix(in srgb, var(--line) 84%, transparent);
      background: rgba(255, 255, 255, 0.88);
      backdrop-filter: blur(14px) saturate(160%);
    }
    .mark {
      width: 30px;
      height: 30px;
      border-radius: 9px;
      display: grid;
      place-items: center;
      color: #fff;
      background: linear-gradient(135deg, var(--brand), color-mix(in srgb, var(--brand) 68%, #0f172a));
      font-weight: 900;
      font-size: 12px;
      box-shadow: 0 8px 22px -12px var(--brand);
    }
    .topbar-title {
      min-width: 0;
      font-size: 14px;
      font-weight: 750;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .layout {
      width: min(1220px, calc(100% - 48px));
      margin: 0 auto;
      padding: 24px 0 64px;
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(220px, 280px);
      gap: 24px;
    }
    .layout.no-sidebar {
      grid-template-columns: minmax(0, 1fr);
      width: min(1040px, calc(100% - 48px));
    }
    .sidebar {
      position: sticky;
      top: 82px;
      align-self: start;
      max-height: calc(100dvh - 106px);
      overflow: auto;
    }
    .page {
      min-width: 0;
    }
    .cover {
      position: relative;
      overflow: hidden;
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      background: var(--panel);
      padding: 30px 34px 32px;
      margin-bottom: 22px;
      box-shadow: var(--shadow-sm);
    }
    .cover::before {
      content: '';
      position: absolute;
      inset: 0 0 auto;
      height: 4px;
      background: linear-gradient(90deg, var(--brand), color-mix(in srgb, var(--brand) 30%, #38bdf8), color-mix(in srgb, var(--brand) 30%, #f43f5e));
    }
    .eyebrow {
      color: var(--brand);
      font-size: 12px;
      font-weight: 800;
      letter-spacing: .08em;
      text-transform: uppercase;
      margin-bottom: 8px;
    }
    h1 {
      font-size: clamp(30px, 4vw, 48px);
      line-height: 1.12;
      margin: 0 0 16px;
      letter-spacing: 0;
    }
    .meta-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 10px;
      margin-top: 18px;
    }
    .meta-item {
      border: 1px solid var(--line);
      background: var(--brand-faint);
      border-radius: 8px;
      padding: 10px 12px;
      min-width: 0;
    }
    .meta-label {
      color: var(--muted);
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      margin-bottom: 2px;
    }
    .meta-value {
      color: var(--ink);
      font-size: 13px;
      overflow-wrap: anywhere;
    }
    .meta-value a {
      color: var(--brand);
      text-decoration: none;
      font-weight: 500;
    }
    .meta-value a:hover {
      text-decoration: underline;
    }
    .toc {
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      padding: 14px;
      margin: 0;
      background: #fff;
      box-shadow: var(--shadow-sm);
    }
    .toc h2 {
      margin: 0 0 10px;
      padding: 0 4px 10px;
      border-bottom: 1px solid var(--line);
      font-size: 12px;
      color: var(--muted);
      letter-spacing: .08em;
      text-transform: uppercase;
    }
    .steps h2 {
      margin: 0 0 12px;
      font-size: 18px;
    }
    .toc ol {
      margin: 0;
      padding-left: 0;
      list-style: none;
    }
    .toc li {
      margin: 3px 0;
      color: var(--muted);
    }
    .toc .toc-chapter {
      margin: 14px 10px 3px;
      color: var(--brand);
      font-size: 11px;
      font-weight: 800;
      text-transform: uppercase;
    }
    .toc a {
      display: block;
      border-radius: 8px;
      padding: 8px 10px;
      color: var(--ink);
      text-decoration: none;
      font-size: 13px;
      line-height: 1.45;
    }
    .toc a:hover {
      background: var(--brand-soft);
      color: var(--brand);
    }
    .toc-mobile {
      display: none;
      margin-bottom: 22px;
      max-height: min(42dvh, 360px);
      overflow-y: auto;
      overscroll-behavior: contain;
    }
    .overview {
      border: 1px solid var(--line);
      border-top: 4px solid var(--brand);
      border-radius: var(--radius-lg);
      padding: 18px 20px;
      margin-bottom: 22px;
      background: var(--brand-soft);
      box-shadow: var(--shadow-sm);
    }
    .overview h2 {
      margin: 14px 0 8px;
      font-size: 16px;
    }
    .overview h2:first-child {
      margin-top: 0;
    }
    .overview p {
      margin: 0;
      color: #475467;
      font-size: 14px;
      line-height: 1.85;
    }
    .overview ul {
      margin: 6px 0 0;
      padding-left: 20px;
      color: #475467;
      font-size: 14px;
    }
    .steps {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }
    .steps > h2 {
      margin: 4px 0 0;
      color: var(--muted);
      font-size: 12px;
      letter-spacing: .08em;
      text-transform: uppercase;
    }
    .step {
      overflow: hidden;
      border: 1px solid var(--line);
      border-radius: var(--radius-lg);
      background: var(--panel);
      box-shadow: var(--shadow-sm);
      break-inside: avoid;
      scroll-margin-top: 82px;
      transition: border-color .18s ease, box-shadow .18s ease;
    }
    .chapter-heading {
      display: flex;
      align-items: center;
      gap: 10px;
      margin: 18px 2px 0;
      color: var(--ink);
      font-size: 20px;
      font-weight: 800;
      scroll-margin-top: 82px;
    }
    .chapter-index {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 30px;
      height: 30px;
      border-radius: 7px;
      background: var(--brand);
      color: #fff;
      font-size: 12px;
    }
    .step:hover {
      border-color: color-mix(in srgb, var(--brand) 24%, var(--line));
      box-shadow: var(--shadow-md);
    }
    .step-head {
      display: grid;
      grid-template-columns: auto minmax(0, 1fr);
      gap: 14px;
      padding: 18px 22px 14px;
    }
    .step-num {
      width: 34px;
      height: 34px;
      border-radius: 999px;
      background: var(--brand);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
      font-weight: 800;
      box-shadow: 0 8px 18px -10px var(--brand);
    }
    .step-title {
      margin: 0 0 6px;
      font-size: 19px;
      line-height: 1.4;
      letter-spacing: -0.02em;
      color: var(--ink);
      font-weight: 700;
    }
    .step-desc {
      color: #475467;
      margin: 0 0 14px;
      font-size: 15px;
      line-height: 1.7;
    }
    .screenshot-wrap {
      position: relative;
      margin: 0 22px 20px;
      overflow: hidden;
      border: 1px solid var(--line);
      border-radius: 12px;
      background: var(--soft);
    }
    .screenshot {
      width: 100%;
      display: block;
    }
    .click-circle {
      position: absolute;
      left: var(--focus-x, 50%);
      top: var(--focus-y, 50%);
      width: 44px;
      height: 44px;
      border: 3px solid var(--focus);
      border-radius: 50%;
      transform: translate(-50%, -50%);
      pointer-events: none;
      box-shadow: 0 0 0 3px #fff, 0 0 18px 4px color-mix(in srgb, var(--focus) 35%, transparent);
      animation: click-pulse 2.4s ease-in-out infinite;
      z-index: 3;
    }
    .focus-dim {
      position: absolute;
      inset: 0;
      pointer-events: none;
      opacity: 0;
      transition: opacity 160ms ease;
      z-index: 1;
      background: radial-gradient(circle 46px at var(--focus-x, 50%) var(--focus-y, 50%), transparent 0 46px, rgba(15, 23, 42, 0.10) 70px, rgba(15, 23, 42, 0.22) 100%);
    }
    .focus-rect {
      position: absolute;
      left: var(--focus-left, 40%);
      top: var(--focus-top, 40%);
      width: var(--focus-width, 20%);
      height: var(--focus-height, 10%);
      border: 3px solid var(--focus);
      border-radius: 7px;
      outline: 3px solid #fff;
      outline-offset: 2px;
      pointer-events: none;
      box-shadow: 0 5px 18px rgba(15, 23, 42, .32), 0 0 16px 3px color-mix(in srgb, var(--focus) 30%, transparent);
      transform-origin: center;
      animation: focus-rect-pulse 2.4s ease-in-out infinite;
      z-index: 3;
    }
    .focus-rect-dim {
      position: absolute;
      left: var(--focus-left, 40%);
      top: var(--focus-top, 40%);
      width: var(--focus-width, 20%);
      height: var(--focus-height, 10%);
      border-radius: 7px;
      box-shadow: 0 0 0 9999px rgba(15, 23, 42, 0.20);
      pointer-events: none;
      opacity: 0;
      transition: opacity 160ms ease;
      z-index: 1;
    }
    .focus-secondary {
      opacity: .78;
      animation: none;
    }
    .click-circle.focus-secondary {
      box-shadow: 0 0 0 2px rgba(255, 255, 255, .9), 0 3px 10px rgba(15, 23, 42, .22);
    }
    .focus-rect.focus-secondary {
      outline-width: 2px;
      box-shadow: 0 3px 12px rgba(15, 23, 42, .24);
    }
    .screenshot-note {
      position: absolute;
      max-width: min(32%, calc(99% - var(--annotation-x, 0%)));
      padding: 8px 14px;
      border: 0;
      border-radius: 7px;
      background: linear-gradient(180deg, color-mix(in srgb, var(--focus) 92%, #fff) 0%, var(--focus) 62%, color-mix(in srgb, var(--focus) 94%, #000) 100%);
      color: #fff;
      box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .3), inset 0 1px rgba(255, 255, 255, .18);
      filter: drop-shadow(0 0 5px color-mix(in srgb, var(--focus) 20%, transparent)) drop-shadow(0 3px 2px rgba(15, 23, 42, .25)) drop-shadow(0 8px 10px rgba(15, 23, 42, .22));
      font-size: clamp(12px, 1.45vw, 16px);
      font-weight: 700;
      line-height: 1.4;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
      pointer-events: auto;
      transform: translateY(-1px);
      transition: transform 160ms ease, filter 160ms ease;
      z-index: 5;
    }
    .screenshot-note::before {
      position: absolute;
      top: 50%;
      width: 12px;
      height: 22px;
      background: var(--focus);
      content: '';
      transform: translateY(-50%);
    }
    .screenshot-note-left {
      margin-left: 9px;
    }
    .screenshot-note-left::before {
      left: -9px;
      clip-path: polygon(100% 0, 100% 100%, 0 50%);
    }
    .screenshot-note-right {
      margin-right: 9px;
    }
    .screenshot-note-right::before {
      right: -9px;
      clip-path: polygon(0 0, 100% 50%, 0 100%);
    }
    .screenshot-note-up {
      margin-top: 9px;
    }
    .screenshot-note-up::before {
      top: -9px;
      left: 50%;
      width: 22px;
      height: 12px;
      clip-path: polygon(50% 0, 100% 100%, 0 100%);
      transform: translateX(-50%);
    }
    .screenshot-note-down {
      margin-bottom: 9px;
    }
    .screenshot-note-down::before {
      top: auto;
      bottom: -9px;
      left: 50%;
      width: 22px;
      height: 12px;
      clip-path: polygon(0 0, 100% 0, 50% 100%);
      transform: translateX(-50%);
    }
    .screenshot-note:hover {
      transform: translateY(-4px);
      filter: drop-shadow(0 0 7px color-mix(in srgb, var(--focus) 28%, transparent)) drop-shadow(0 4px 3px rgba(15, 23, 42, .3)) drop-shadow(0 12px 14px rgba(15, 23, 42, .27));
    }
    .screenshot-wrap:hover .focus-dim,
    .screenshot-wrap:hover .focus-rect-dim {
      opacity: 1;
    }
    @keyframes click-pulse {
      0%, 100% { box-shadow: 0 0 0 3px #fff, 0 0 18px 4px color-mix(in srgb, var(--focus) 35%, transparent); transform: translate(-50%, -50%) scale(1); }
      50% { box-shadow: 0 0 0 3px #fff, 0 0 28px 8px color-mix(in srgb, var(--focus) 50%, transparent); transform: translate(-50%, -50%) scale(1.08); }
    }
    @keyframes focus-rect-pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.025); }
    }
    .step-action-tag {
      display: inline-flex;
      align-items: center;
      width: fit-content;
      max-width: calc(100% - 44px);
      margin: -2px 22px 20px;
      padding: 7px 10px;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 800;
      line-height: 1;
      letter-spacing: .02em;
    }
    .step-action-tag.click { color: #1d4ed8; background: #dbeafe; border: 1px solid #bfdbfe; }
    .step-action-tag.form { color: #166534; background: #dcfce7; border: 1px solid #bbf7d0; }
    .step-action-tag.select { color: #92400e; background: #fef3c7; border: 1px solid #fde68a; }
    .step-action-tag.selection { color: #6d28d9; background: #ede9fe; border: 1px solid #ddd6fe; }
    .step-action-tag.keyboard { color: #075985; background: #e0f2fe; border: 1px solid #bae6fd; }
    .step-action-tag.navigation { color: #be123c; background: #ffe4e6; border: 1px solid #fecdd3; }
    .step-action-tag.initial { color: #3730a3; background: #e0e7ff; border: 1px solid #c7d2fe; }
    .step-action-tag.generic { color: #334155; background: #e2e8f0; border: 1px solid #cbd5e1; }
    .footer {
      border-top: 1px solid var(--line);
      color: var(--muted);
      font-size: 12px;
      margin-top: 32px;
      padding-top: 18px;
    }
    @media (max-width: 1080px) {
      .topbar { padding: 0 16px; }
      .layout, .layout.no-sidebar {
        width: min(100% - 28px, 1040px);
        grid-template-columns: minmax(0, 1fr);
        padding-top: 18px;
      }
      .sidebar {
        display: none;
      }
      .toc-mobile {
        display: block;
      }
      .cover { padding: 24px 20px; }
      .step-head { padding: 16px 16px 12px; }
      .screenshot-wrap { margin: 0 16px 16px; }
      .step-num { width: 30px; height: 30px; }
    }
    @media print {
      @page { size: A4 portrait; margin: ${i.printOptimized?"0":"14mm 13mm 16mm"}; }
      html, body { width: 100%; background: #fff; }
      body {
        color: #111827;
        font-size: 10.5pt;
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
      }
      .topbar, .sidebar { display: none; }
      .layout, .layout.no-sidebar { display: block; width: auto; padding: 0; }
      .page {
        width: auto;
        max-width: none;
        padding: ${i.printOptimized?"14mm 13mm 16mm":"0"};
        box-decoration-break: clone;
        -webkit-box-decoration-break: clone;
      }
      .toc, .meta-item, .cover, .step { background: #fff; box-shadow: none; }
      .cover {
        min-height: 245mm;
        display: flex;
        flex-direction: column;
        justify-content: center;
        border: 0;
        border-top: 5px solid var(--brand);
        border-radius: 0;
        padding: 22mm 10mm;
        break-after: page;
      }
      .cover h1 { max-width: 150mm; font-size: 28pt; line-height: 1.18; }
      .meta-grid { margin-top: 18mm; }
      .overview { break-inside: avoid; box-shadow: none; }
      .toc-mobile {
        display: block;
        max-height: none;
        overflow: visible;
        break-inside: avoid;
        margin-bottom: 10mm;
        box-shadow: none;
      }
      .steps { display: block; }
      .steps > h2 { margin: 0 0 8mm; font-size: 11pt; }
      .chapter-heading { margin: 8mm 0 4mm; break-after: avoid; }
      .step {
        break-inside: avoid-page;
        page-break-inside: avoid;
        margin: 0 0 7mm;
        border-radius: 3mm;
      }
      .step-head { padding: 5mm 6mm 4mm; }
      .screenshot-wrap { margin: 0 6mm 5mm; border-radius: 2mm; }
      .screenshot { height: auto; max-height: none; }
      .step-action-tag { margin: -1mm 6mm 5mm; }
      .footer { margin-top: 10mm; padding-top: 5mm; }
      a { color: inherit; text-decoration: underline; }
    }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="mark" aria-hidden="true">SP</div>
    <div class="topbar-title">${ge(t.title)}</div>
  </header>
  <div class="layout${i.includeTableOfContents&&t.steps.length>0?"":" no-sidebar"}">
    <main class="page">
      <section class="cover">
        <div class="eyebrow">${r.eyebrow}</div>
        <h1>${ge(t.title)}</h1>
        ${i.includeMetadata?Gr(t,a):""}
      </section>
      ${Xr(t)}
      ${i.includeTableOfContents&&t.steps.length>0?`<div class="toc-mobile">${yn(t,i)}</div>`:""}
      <section class="steps">
        <h2>${r.steps}</h2>
        ${Yr(t,i)}
      </section>
      ${i.includeFooter?`<footer class="footer">${r.footer}</footer>`:""}
    </main>
    ${i.includeTableOfContents&&t.steps.length>0?`<aside class="sidebar">${yn(t,i)}</aside>`:""}
  </div>
</body>
</html>`}}function bn(e={}){const t={...ii,...e},n=Vt(t.themeColor);return{...t,themeColor:n,focusColor:Gt(n,t.focusColor)}}function Gr(e,t){const n=Be(e),i=e.url?`<a href="${ge(e.url)}" target="_blank" rel="noopener noreferrer">${ge(e.url)}</a>`:"N/A";return`<div class="meta-grid">
        <div class="meta-item">
          <div class="meta-label">${n.url}</div>
          <div class="meta-value">${i}</div>
        </div>
        <div class="meta-item">
          <div class="meta-label">${n.updated}</div>
          <div class="meta-value">${ge(t)}</div>
        </div>
      </div>`}function yn(e,t){var r;if(e.steps.length===0)return"";const n=Be(e),i=tt((r=e.outline)==null?void 0:r.chapters,e.steps);return`<nav class="toc" aria-label="${n.contents}">
      <h2>${n.contents}</h2>
      <ol>
${e.steps.map((a,s)=>{const o=i==null?void 0:i.find(c=>c.startStepNumber===s+1);return`${o?`        <li class="toc-chapter">${ge(o.title)}</li>
`:""}        <li><a href="#step-${oi(a)}">${ge(`${Kt(a,t,e.language)} ${a.title}`.trim())}</a></li>`}).join(`
`)}
      </ol>
    </nav>`}function Yr(e,t){var i;const n=tt((i=e.outline)==null?void 0:i.chapters,e.steps);return e.steps.map((r,a)=>{const s=n==null?void 0:n.find(c=>c.startStepNumber===a+1);return`${s?`<h2 class="chapter-heading" id="chapter-${ge(s.id)}"><span class="chapter-index">${((n==null?void 0:n.indexOf(s))??0)+1}</span>${ge(s.title)}</h2>
`:""}${Kr(e,r,t)}`}).join(`
`)}function Xr(e){if(!e.outline)return qr(e);const t=Be(e),n=['<section class="overview" id="overview">'];return e.outline.purpose&&n.push(`<h2>${t.purpose}</h2><p>${ge(e.outline.purpose)}</p>`),e.outline.summary&&n.push(`<h2>${t.summary}</h2><p>${ge(e.outline.summary)}</p>`),n.push("</section>"),n.join(`
`)}function qr(e){const t=ai(e);return t?`<section class="overview" id="overview">
      <h2>${Be(e).summary}</h2>
      <p>${ge(t)}</p>
    </section>`:""}function Kr(e,t,n){var f;const i=ri(e,t),r=it(t.focus,t.additionalFocuses).flatMap(b=>{const p=Yt(b.focus,n.focusShape);if(!p)return[];const m=b.primary?"":" focus-secondary";if(p.shape==="rectangle"){const z=`--focus-left: ${p.left}; --focus-top: ${p.top}; --focus-width: ${p.width}; --focus-height: ${p.height}`;return[`${b.primary?`<div class="focus-rect-dim" style="${z}"></div>`:""}<div class="focus-rect${m}" style="${z}"></div>`]}const T=`--focus-x: ${p.left}; --focus-y: ${p.top}`;return[`${b.primary?`<div class="focus-dim" style="${T}"></div>`:""}<div class="click-circle${m}" style="${T}"></div>`]}).join(""),a=(t.annotations??[]).flatMap(b=>{const p=nt(b),m=p.text.trim();if(!m)return[];const T=ni(p);return[`<div class="screenshot-note screenshot-note-${Xt(p,qt(p,t.focus,t.additionalFocuses))}" style="--annotation-x: ${T.left}; left: ${T.left}; top: ${T.top}">${ge(m)}</div>`]}).join(""),s=Qr(t.actionType,(f=t.focus)==null?void 0:f.type,e.language),o=Be(e),c=n.includeScreenshots&&i?`<div class="screenshot-wrap"><img class="screenshot" src="${ge(i.maskedDataUrl||i.dataUrl)}" alt="${ge(`${o.step} ${t.stepNumber} ${o.screenshot}`)}">${r}${a}</div>`:"",d=n.includeStepNumbers?`<div class="step-num" aria-hidden="true">${t.stepNumber}</div>`:"<div></div>";return`<article class="step" id="step-${oi(t)}">
        <div class="step-head">
          ${d}
          <div>
          <h3 class="step-title">${ge(t.title)}</h3>
          <p class="step-desc">${ge(t.description)}</p>
          </div>
        </div>
        ${c}
        <div class="step-action-tag ${s.tone}">${s.label}</div>
      </article>`}function Qr(e,t,n){const i=n==="en";switch((t&&t!=="generic"?t:e||"").toLowerCase()){case"click":return{label:i?"Click":"点击操作",tone:"click"};case"input":case"change":case"focus":case"blur":return{label:i?"Form input":"填写表单",tone:"form"};case"select":return{label:i?"Select option":"下拉选单",tone:"select"};case"selection":return{label:i?"Text selection":"选中文本",tone:"selection"};case"keypress":return{label:i?"Keyboard input":"键盘输入",tone:"keyboard"};case"navigation":return{label:i?"Navigation":"页面跳转",tone:"navigation"};case"initial_screen":return{label:i?"Starting page":"起始页面",tone:"initial"};default:return{label:i?"Workflow step":"操作截图",tone:"generic"}}}function ri(e,t){return t.screenshotId?e.screenshots.find(n=>n.id===t.screenshotId):void 0}function Kt(e,t,n){return t.includeStepNumbers?`${n==="en"?"Step":"步骤"} ${e.stepNumber}:`:""}function Zr(e,t,n){const i=Kt(e,t,n);return i?`${i} ${e.title}`:e.title}function oi(e){return String(e.stepNumber)}function ai(e){const t=e.steps.map(r=>{var a;return(a=r.title)==null?void 0:a.trim()}).filter(Boolean).slice(0,5);if(t.length===0)return"";if(e.language==="en"){const r=t.join(", "),a=e.steps.length>t.length?", and more":"";return`This guide walks through "${e.title}" in ${e.steps.length} steps, including ${r}${a}.`}const n=t.join("、"),i=e.steps.length>t.length?"等操作":"操作";return`本篇 demo 演示“${e.title}”的完整操作流程，共 ${e.steps.length} 个步骤，主要包括：${n}${i}。`}function Jr(e,t){if(!t.outline)return;const n=Be(t);t.outline.purpose&&e.push(`## ${n.purpose}`,"",t.outline.purpose,""),t.outline.summary&&e.push(`## ${n.summary}`,"",t.outline.summary,"")}function Be(e){return e.language==="en"?{eyebrow:"StepMark guide",url:"Source URL",updated:"Updated",purpose:"Purpose",summary:"Summary",contents:"Contents",steps:"Steps",step:"Step",screenshot:"screenshot",footer:"Generated by StepMark. Review the content before publishing."}:{eyebrow:"StepMark 文档",url:"访问链接 URL",updated:"文档更新时间",purpose:"目的",summary:"操作概要",contents:"目录",steps:"步骤",step:"步骤",screenshot:"截图",footer:"由 StepMark 生成。发布前请检查内容。"}}function ge(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function vn(e){return typeof e=="string"&&/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(e.trim())?e.trim():"#2563eb"}class He{static export(t,n,i={}){switch(n){case"markdown":return this.toMarkdown(t,i);case"html":return this.toHtml(t,i);case"pdf":return this.toPdfForPrint(t,i);default:return this.toMarkdown(t,i)}}static getFilename(t,n){return`${t.title.replace(/[^a-zA-Z0-9\u4e00-\u9fa5\s-]/g,"").replace(/\s+/g,"-").toLowerCase().slice(0,50)||"guide"}.${{markdown:"md",html:"html",pdf:"pdf"}[n]}`}static getDefaultOptions(){return{...ii}}static toMarkdown(t,n){return{content:$t.renderMarkdown(t,n),filename:He.getFilename(t,"markdown"),mimeType:"text/markdown"}}static toHtml(t,n){return{content:$t.renderHtml(t,n),filename:He.getFilename(t,"html"),mimeType:"text/html"}}static toPdfForPrint(t,n){return{content:$t.renderHtml(t,{...n,includeFooter:!1,printOptimized:!0}),filename:He.getFilename(t,"pdf"),mimeType:"text/html"}}}const eo=1600,si=2,to=80;async function li(e,t,n){var f;const i=await co(e.dataUrl),r=i.naturalWidth||i.width,a=i.naturalHeight||i.height,s=no(r,a),o=document.createElement("canvas");o.width=s.width,o.height=s.height;const c=o.getContext("2d");if(!c||o.width<=0||o.height<=0)throw new Error("Could not prepare the screenshot for export");if(c.drawImage(i,0,0,o.width,o.height),t==="annotated")for(const b of it(e.focus,e.additionalFocuses)){const p=Yt(b.focus,b.focus.shape??"circle");if((p==null?void 0:p.shape)==="rectangle")oo(c,{x:at(p.left,o.width),y:at(p.top,o.height),width:at(p.width,o.width),height:at(p.height,o.height),scale:((f=wn(b.focus,o.width,o.height))==null?void 0:f.scale)??1},n);else if(p){const m=wn(b.focus,o.width,o.height);m&&ro(c,o.width,o.height,m,n)}}ao(c,e.annotations??[],o.width,o.height,n,e.focus,e.additionalFocuses);const d=o.toDataURL("image/png");return{dataUrl:d,bytes:io(d),width:o.width,height:o.height}}function no(e,t,n=eo){if(e<=0||t<=0||n<=0)return{width:0,height:0};const i=Math.min(1,n/Math.max(e,t));return{width:Math.max(1,Math.round(e*i)),height:Math.max(1,Math.round(t*i))}}function wn(e,t,n){var o,c;if(!e||e.x===void 0||e.y===void 0)return null;const i=(o=e.viewport)==null?void 0:o.width,r=(c=e.viewport)==null?void 0:c.height,a=i&&i>0?t/i:e.devicePixelRatio||1,s=r&&r>0?n/r:e.devicePixelRatio||1;return{x:Ve(e.x*a,0,t),y:Ve(e.y*s,0,n),scale:Math.max(1,(a+s)/2)}}function io(e){const t=e.indexOf(",");if(t<0)throw new Error("Invalid screenshot data");const n=e.slice(0,t),i=e.slice(t+1),r=/;base64/i.test(n)?atob(i):decodeURIComponent(i),a=new Uint8Array(r.length);for(let s=0;s<r.length;s+=1)a[s]=r.charCodeAt(s);return a}function ro(e,t,n,i,r){const a=Ve(i.scale,1,si),s=Math.min(to,Math.max(40*a,Math.min(t,n)*.04)),o=/^#[0-9a-f]{6}$/i.test(r)?r:"#2563eb";e.save(),e.beginPath(),e.arc(i.x,i.y,s,0,Math.PI*2),e.strokeStyle="#ffffff",e.lineWidth=Math.max(12,12*a),e.shadowColor="rgba(15, 23, 42, 0.52)",e.shadowBlur=Math.max(20,20*a),e.shadowOffsetY=Math.max(6,6*a),e.stroke(),e.restore(),e.save(),e.beginPath(),e.arc(i.x,i.y,s,0,Math.PI*2),e.strokeStyle=o,e.lineWidth=Math.max(5,5*a),e.stroke(),e.restore()}function oo(e,t,n){const i=Ve(t.scale,1,si),r=/^#[0-9a-f]{6}$/i.test(n)?n:"#2563eb";e.save(),e.strokeStyle="#ffffff",e.lineWidth=Math.max(12,12*i),e.shadowColor="rgba(15, 23, 42, 0.52)",e.shadowBlur=Math.max(20,20*i),e.shadowOffsetY=Math.max(6,6*i),Sn(e,t),e.restore(),e.save(),e.strokeStyle=r,e.lineWidth=Math.max(5,5*i),Sn(e,t),e.restore()}function ao(e,t,n,i,r,a,s=[]){const o=/^#[0-9a-f]{6}$/i.test(r)?r:"#2563eb",c=Ve(Math.round(n*.015),14,22),d=Math.round(c*.72),f=Math.round(c*.5),b=Math.round(c*.58),p=Math.round(c*1.42),m=Math.min(n*.3,390);for(const T of t){const z=nt(T),E=Xt(z,qt(z,a,s)),U=z.text.trim();if(!U)continue;e.save(),e.font=`700 ${c}px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`;const N=so(e,U,m),J=Math.max(...N.map(te=>e.measureText(te).width)),G=E==="left"||E==="right",Y=Math.min(n*.34,J+d*2+(G?b:0)),_=N.length*p+f*2+(G?0:b),oe=Ve(z.x*n,4,Math.max(4,n-Y-4)),ee=Ve(z.y*i,4,Math.max(4,i-_-4)),D=e.createLinearGradient(0,ee,0,ee+_);D.addColorStop(0,kn(o,"#ffffff",.08)),D.addColorStop(.62,o),D.addColorStop(1,kn(o,"#000000",.06)),e.shadowColor="rgba(15, 23, 42, 0.28)",e.shadowBlur=Math.max(14,c*.95),e.shadowOffsetY=Math.max(6,c*.32),e.fillStyle=D,lo(e,oe,ee,Y,_,b,E),e.fill(),e.shadowColor="transparent",e.strokeStyle="rgba(255, 255, 255, 0.36)",e.lineWidth=Math.max(1.5,c*.075),e.stroke(),e.fillStyle="#ffffff",e.textBaseline="top",N.forEach((te,H)=>{const se=E==="left"?oe+b+d:oe+d,de=E==="up"?ee+b+f:ee+f;e.fillText(te,se,de+H*p,m)}),e.restore()}}function so(e,t,n){const i=[];for(const r of t.split(/\r?\n/)){let a="";for(const s of r||" "){const o=a+s;a&&e.measureText(o).width>n?(i.push(a.trimEnd()),a=s.trimStart()):a=o}(a||r==="")&&i.push(a.trim()||" ")}return i.slice(0,8)}function Sn(e,t){e.beginPath(),typeof e.roundRect=="function"?e.roundRect(t.x,t.y,t.width,t.height,10):e.rect(t.x,t.y,t.width,t.height),e.stroke()}function lo(e,t,n,i,r,a,s){const o=s==="left"?t+a:t,c=s==="right"?t+i-a:t+i,d=s==="up"?n+a:n,f=s==="down"?n+r-a:n+r,b=f-d,p=Math.min(8,b*.22),m=(o+c)/2,T=(d+f)/2,z=Math.min(a*.72,b*.28),E=Math.min(a*.9,(c-o)*.18);e.beginPath(),s==="left"?(e.moveTo(o+p,d),e.lineTo(c-p,d),e.quadraticCurveTo(c,d,c,d+p),e.lineTo(c,f-p),e.quadraticCurveTo(c,f,c-p,f),e.lineTo(o+p,f),e.quadraticCurveTo(o,f,o,f-p),e.lineTo(o,T+z),e.lineTo(t,T),e.lineTo(o,T-z),e.lineTo(o,d+p),e.quadraticCurveTo(o,d,o+p,d)):s==="right"?(e.moveTo(o+p,d),e.lineTo(c-p,d),e.quadraticCurveTo(c,d,c,d+p),e.lineTo(c,T-z),e.lineTo(t+i,T),e.lineTo(c,T+z),e.lineTo(c,f-p),e.quadraticCurveTo(c,f,c-p,f),e.lineTo(o+p,f),e.quadraticCurveTo(o,f,o,f-p),e.lineTo(o,d+p),e.quadraticCurveTo(o,d,o+p,d)):s==="up"?(e.moveTo(o+p,d),e.lineTo(m-E,d),e.lineTo(m,n),e.lineTo(m+E,d),e.lineTo(c-p,d),e.quadraticCurveTo(c,d,c,d+p),e.lineTo(c,f-p),e.quadraticCurveTo(c,f,c-p,f),e.lineTo(o+p,f),e.quadraticCurveTo(o,f,o,f-p),e.lineTo(o,d+p),e.quadraticCurveTo(o,d,o+p,d)):(e.moveTo(o+p,d),e.lineTo(c-p,d),e.quadraticCurveTo(c,d,c,d+p),e.lineTo(c,f-p),e.quadraticCurveTo(c,f,c-p,f),e.lineTo(m+E,f),e.lineTo(m,n+r),e.lineTo(m-E,f),e.lineTo(o+p,f),e.quadraticCurveTo(o,f,o,f-p),e.lineTo(o,d+p),e.quadraticCurveTo(o,d,o+p,d)),e.closePath()}function kn(e,t,n){var s,o;const i=(s=e.match(/[0-9a-f]{2}/gi))==null?void 0:s.map(c=>Number.parseInt(c,16)),r=(o=t.match(/[0-9a-f]{2}/gi))==null?void 0:o.map(c=>Number.parseInt(c,16));return!i||!r?e:`#${i.map((c,d)=>Math.round(c+(r[d]-c)*n).toString(16).padStart(2,"0")).join("")}`}function co(e){return new Promise((t,n)=>{const i=new Image;i.onload=()=>t(i),i.onerror=()=>n(new Error("Could not load a screenshot for export")),i.src=e})}function Ve(e,t,n){return Math.max(t,Math.min(n,e))}function at(e,t){return Number.parseFloat(e)/100*t}const uo=24,po=24,fo=40*1024*1024;function ho(e){const t=e.steps.flatMap(i=>i.screenshot?[i.screenshot]:[]),n=t.reduce((i,r)=>i+xo(r.dataUrl),0);return{screenshotCount:t.length,estimatedSourceBytes:n,shouldWarn:e.steps.length>=po||t.length>=uo||n>=fo}}async function mo(e,t=li,n={}){const i=bo(e.language),r=['<article style="font-family:Arial,Helvetica,sans-serif;color:#172033;line-height:1.55">'],a=[];n.includeHeader!==!1&&(r.push(`<h1>${Te(e.title)}</h1>`),a.push(e.title),e.sourceUrl&&(r.push(`<p><strong>${i.source}:</strong> <a href="${Te(e.sourceUrl)}">${Te(e.sourceUrl)}</a></p>`),a.push(`${i.source}: ${e.sourceUrl}`)),e.purpose&&(r.push(`<h2>${i.purpose}</h2><p>${Te(e.purpose)}</p>`),a.push("",i.purpose,e.purpose)),e.summary&&(r.push(`<h2>${i.summary}</h2><p>${Te(e.summary)}</p>`),a.push("",i.summary,e.summary)));for(const s of e.steps){if(s.chapterTitle&&(r.push(`<h2>${Te(s.chapterTitle)}</h2>`),a.push("",s.chapterTitle)),r.push(`<section><h3>${Te(`${i.step} ${s.stepNumber}: ${s.title}`)}</h3>`),a.push("",`${i.step} ${s.stepNumber}: ${s.title}`),s.description&&(r.push(`<p>${Te(s.description)}</p>`),a.push(s.description)),s.screenshot){const o=await t(s.screenshot,e.screenshotMode,e.focusColor);r.push(`<p><img src="${o.dataUrl}" alt="${Te(`${i.step} ${s.stepNumber}`)}" style="max-width:100%;height:auto"></p>`)}s.narration&&(r.push(`<p><strong>${i.narration}:</strong> ${Te(s.narration)}</p>`),a.push(`${i.narration}: ${s.narration}`)),r.push("</section>")}return r.push("</article>"),{html:r.join(""),text:a.join(`
`).replace(/^\n+/,"")}}async function go(e,t=li,n={}){var r;if(!((r=navigator.clipboard)!=null&&r.write)||typeof ClipboardItem>"u")throw new Error("Rich clipboard is unavailable");const i=mo(e,t,n);await navigator.clipboard.write([new ClipboardItem({"text/html":i.then(a=>new Blob([a.html],{type:"text/html"})),"text/plain":i.then(a=>new Blob([a.text],{type:"text/plain"}))})])}function xo(e){const t=e.indexOf(",");if(t<0)return 0;const n=e.slice(0,t),i=e.slice(t+1);if(!/;base64/i.test(n))try{return new TextEncoder().encode(decodeURIComponent(i)).byteLength}catch{return i.length}const r=i.replace(/\s/g,""),a=r.endsWith("==")?2:r.endsWith("=")?1:0;return Math.max(0,Math.floor(r.length*3/4)-a)}function bo(e){return e==="en"?{source:"Source",purpose:"Purpose",summary:"Summary",step:"Step",narration:"Narration"}:{source:"来源",purpose:"目的",summary:"操作概要",step:"步骤",narration:"口播稿"}}function Te(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}const yo={selectedStepIndexes:[],includeSummary:!0,includeSource:!1,includeScreenshots:!0,includeNarration:!1,screenshotMode:"annotated",themeColor:"#2563eb",focusColor:"",focusShape:"circle"};function vo(e,t={}){var o,c,d,f,b;const n={...yo,...t},i=e.language,r=n.selectedStepIndexes.length>0?new Set(n.selectedStepIndexes):new Set(e.steps.map((p,m)=>m)),a=tt((o=e.outline)==null?void 0:o.chapters,e.steps),s=e.steps.flatMap((p,m)=>{var U,N,J,G,Y;if(!r.has(m))return[];const T=n.includeScreenshots&&p.screenshotId?e.screenshots.find(_=>_.id===p.screenshotId):void 0,z=p,E=((U=z.voiceScript)==null?void 0:U.trim())||((N=z.generatedVoiceScript)==null?void 0:N.trim());return[{sourceIndex:m,stepNumber:p.stepNumber,title:p.title.trim(),chapterTitle:(J=a==null?void 0:a.find(_=>_.startStepNumber===m+1))==null?void 0:J.title,description:p.description.trim(),narration:n.includeNarration&&E?E:void 0,screenshot:T?{dataUrl:T.maskedDataUrl||T.dataUrl,focus:p.focus?{...p.focus,shape:p.focus.shape??n.focusShape}:void 0,additionalFocuses:(G=p.additionalFocuses)==null?void 0:G.map(_=>({..._,shape:_.shape??n.focusShape})),annotations:(Y=p.annotations)==null?void 0:Y.map(_=>({..._}))}:void 0}]});return{language:n.language??i??Pe,title:e.title.trim()||((n.language??i)==="en"?"Untitled guide":"未命名文档"),sourceUrl:n.includeSource&&e.url?e.url:void 0,purpose:n.includeSummary&&((d=(c=e.outline)==null?void 0:c.purpose)==null?void 0:d.trim())||void 0,summary:n.includeSummary&&((b=(f=e.outline)==null?void 0:f.summary)==null?void 0:b.trim())||void 0,steps:s,screenshotMode:n.screenshotMode,focusColor:Gt(n.themeColor,n.focusColor),focusShape:n.focusShape}}function ci(e,t){const n=[...t].sort((i,r)=>i.startedAt-r.startedAt);return n.length===0?[]:e.map((i,r)=>{const a=So(i.timestamp,n),s=typeof a.endedAt=="number"?Math.max(0,a.endedAt-a.startedAt):Number.POSITIVE_INFINITY;return{stepIndex:r,segmentId:a.id,startMs:Math.min(s,Math.max(0,i.timestamp-a.startedAt))}})}function wo(e,t,n){const i=e.filter(a=>a.segmentId===t);if(i.length===0)return null;let r=i[0];for(const a of i){if(a.startMs>n)break;r=a}return r.stepIndex}function So(e,t){const n=t.find(i=>e>=i.startedAt&&(typeof i.endedAt!="number"||e<=i.endedAt));return n||t.reduce((i,r)=>Mn(e,r)<Mn(e,i)?r:i)}function Mn(e,t){return e<t.startedAt?t.startedAt-e:typeof t.endedAt=="number"&&e>t.endedAt?e-t.endedAt:0}async function ko(e,t,n){const i=new Map(n.map(o=>[o.segment.id,o])),r=ci(e.steps,t.videoManifest??[]),a=[];for(const o of t.videoManifest??[]){const c=i.get(o.id);!c||c.blob.size===0||a.push({id:o.id,src:await Mo(c.blob,o.mimeType||"video/webm"),cues:r.filter(d=>d.segmentId===o.id).map(d=>{var b,p;const f=e.steps[d.stepIndex];return{stepNumber:f.stepNumber,startMs:d.startMs,title:f.title,text:((b=f.voiceScript)==null?void 0:b.trim())||((p=f.generatedVoiceScript)==null?void 0:p.trim())||f.description||f.title}})})}if(a.length===0)throw new Error("No saved video segment is available for tutorial export");const s=He.getFilename(e,"html").replace(/\.html$/i,"")||"tutorial";return{content:$o(e,a),filename:`${s}-video-tutorial.html`,mimeType:"text/html"}}async function Mo(e,t){const n=new Uint8Array(await e.arrayBuffer());let i="";for(let r=0;r<n.length;r+=32768)i+=String.fromCharCode(...n.subarray(r,r+32768));return`data:${e.type||t};base64,${btoa(i)}`}function $o(e,t){const n=e.language==="en",i=n?{eyebrow:"StepMark video tutorial",voice:"Google voice",automatic:"Automatic (recommended)",segment:"Segment",step:"Step",contents:"Tutorial contents",jump:"Jump to"}:{eyebrow:"StepMark 视频教程",voice:"Google 音色",automatic:"自动选择（推荐）",segment:"片段",step:"步骤",contents:"教程目录",jump:"跳转到"},r=Co({language:n?"en-US":"zh-CN",videos:t,copy:{segment:i.segment,step:i.step,contents:i.contents,jump:i.jump}});return`<!doctype html>
<html lang="${n?"en":"zh-CN"}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${$n(e.title)}</title>
  <style>
    *{box-sizing:border-box}body{margin:0;background:#f3f7f6;color:#172033;font:15px/1.55 system-ui,-apple-system,sans-serif}.page{width:min(1180px,calc(100% - 32px));margin:auto;padding:28px 0 56px}.head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;flex-wrap:wrap;margin-bottom:16px}.eyebrow{color:#1d4ed8;font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}h1{margin:4px 0 0;font-size:clamp(24px,4vw,36px);line-height:1.2}.tools{display:flex;align-items:end;gap:10px;flex-wrap:wrap}.tools label{display:grid;gap:5px;color:#667085;font-size:12px;font-weight:700}.tools select{min-height:38px;border:1px solid #d8e2df;border-radius:7px;background:#fff;color:#172033;padding:7px 11px;font:inherit;font-weight:700}.tutorial{display:grid;grid-template-columns:minmax(220px,280px) minmax(0,1fr);gap:16px;align-items:start}.stage{min-width:0}.chapters{position:sticky;top:16px;max-height:calc(100vh - 32px);overflow:auto;padding:10px;border:1px solid #dfe8e5;border-radius:8px;background:#fff}.chapters-title{padding:4px 5px 10px;border-bottom:1px solid #e7eeec;color:#667085;font-size:12px;font-weight:800;letter-spacing:.06em;text-transform:uppercase}.chapters ol{display:grid;gap:5px;margin:8px 0 0;padding:0;list-style:none}.chapter{display:grid;grid-template-columns:28px minmax(0,1fr);gap:8px;width:100%;min-height:56px;padding:8px 9px;border:1px solid transparent;border-radius:7px;background:transparent;color:#172033;text-align:left;cursor:pointer;font:inherit}.chapter:hover{background:#eff6ff}.chapter.active{border-color:#bfdbfe;background:#eff6ff}.chapter-number{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:#eef3f2;color:#667085;font-size:11px;font-weight:800}.chapter.active .chapter-number{background:#2563eb;color:#fff}.chapter-title{display:block;overflow:hidden;font-size:12px;font-weight:750;line-height:1.35;text-overflow:ellipsis;white-space:nowrap}.chapter-meta{display:block;margin-top:4px;color:#667085;font-size:10px}.player{position:relative;background:#0f172a;border-radius:8px;overflow:hidden;box-shadow:0 18px 48px -30px #0f172a}.player video{display:block;width:100%;max-height:72vh;background:#0f172a}.player video::-webkit-media-controls-mute-button,.player video::-webkit-media-controls-volume-slider,.player video::-webkit-media-controls-volume-slider-container{display:none!important}.caption{position:absolute;left:5%;right:5%;bottom:58px;text-align:center;pointer-events:none}.caption span{display:inline-block;max-width:900px;padding:9px 14px;border-radius:6px;background:rgba(15,23,42,.82);color:#fff;font-size:clamp(15px,2vw,20px);line-height:1.45}.status{display:flex;justify-content:space-between;gap:12px;padding:11px 14px;background:#fff;border:1px solid #dfe8e5;border-top:0;border-radius:0 0 8px 8px;color:#667085;font-size:13px}@media(max-width:820px){.tutorial{grid-template-columns:minmax(0,1fr)}.stage{order:1}.chapters{position:static;order:2;max-height:300px}}@media(max-width:600px){.page{width:min(100% - 20px,1180px);padding-top:18px}.caption{bottom:48px}.status{display:grid}.tools{width:100%}.tools label{flex:1}.tools select{width:100%}}
  </style>
</head>
<body><main class="page">
  <div class="head"><div><div class="eyebrow">${i.eyebrow}</div><h1>${$n(e.title)}</h1></div><div class="tools"><label><span>${i.voice}</span><select id="voice"><option value="">${i.automatic}</option></select></label></div></div>
  <div class="tutorial">
    <aside class="chapters" aria-label="${i.contents}"><div class="chapters-title">${i.contents}</div><ol id="chapters"></ol></aside>
    <div class="stage"><div class="player"><video id="video" controls playsinline preload="metadata"></video><div class="caption"><span id="caption"></span></div></div>
    <div class="status"><span id="segment"></span><span id="step"></span></div></div>
  </div>
</main>
<script>
const DATA=${r};
const synth=window.speechSynthesis||null;
// NOTE: these two helpers are inlined as literals on purpose. Build minifiers
// rename module-scope functions, which breaks any toString() injection —
// the exported HTML must stay self-contained. Keep in sync with
// voiceScore / narrationWatchdogMs in src/core/voice/SpeechQueue.ts.
function voiceScore(voice){return (/^Google\\b/i.test(voice.name||"")?0:100)+(voice.localService?2:0)+(voice.default?1:0)}
function narrationWatchdogMs(text){return Math.min(15000,2000+300*text.length)}
const video=document.getElementById('video'),caption=document.getElementById('caption'),segmentLabel=document.getElementById('segment'),stepLabel=document.getElementById('step'),voiceSelect=document.getElementById('voice'),chapterList=document.getElementById('chapters');
let segmentIndex=0,lastCueKey='',narrating=false,continueAfterNarration=false,tutorialPaused=false,tutorialStarted=false,narrationGeneration=0,activeUtterance=null;
function matchingVoices(){if(!synth)return[];const base=DATA.language.split('-')[0].toLowerCase();return synth.getVoices().filter(v=>v.lang.toLowerCase().startsWith(base+'-')).sort((a,b)=>voiceScore(b)-voiceScore(a))}
function refreshVoices(){const current=voiceSelect.value;voiceSelect.querySelectorAll('option:not(:first-child)').forEach(o=>o.remove());matchingVoices().forEach(v=>{const o=document.createElement('option');o.value=v.name;o.textContent=v.name+' ('+v.lang+')';voiceSelect.appendChild(o)});if([...voiceSelect.options].some(o=>o.value===current))voiceSelect.value=current}
if(synth)synth.addEventListener('voiceschanged',refreshVoices);refreshVoices();
function selectedVoice(){const voices=matchingVoices();return voices.find(v=>v.name===voiceSelect.value)||voices[0]||null}
function currentCue(){const cues=DATA.videos[segmentIndex].cues;let active=cues[0]||null;for(const cue of cues){if(cue.startMs>video.currentTime*1000)break;active=cue}return active}
function cueKey(cue){return cue?segmentIndex+':'+cue.stepNumber:''}
function updateActiveChapter(cue){const key=cueKey(cue);chapterList.querySelectorAll('.chapter').forEach(button=>{const active=button.dataset.key===key;button.classList.toggle('active',active);if(active){button.setAttribute('aria-current','step');button.scrollIntoView({block:'nearest'})}else button.removeAttribute('aria-current')})}
function renderCue(cue){if(!cue){caption.textContent='';stepLabel.textContent='';updateActiveChapter(null);return}caption.textContent=cue.text;stepLabel.textContent=DATA.copy.step+' '+cue.stepNumber;updateActiveChapter(cue)}
function cancelNarration(){narrationGeneration+=1;activeUtterance=null;narrating=false;if(synth&&(synth.speaking||synth.pending||synth.paused))synth.cancel()}
function speakCue(cue){if(!cue)return false;const key=segmentIndex+':'+cue.stepNumber;if(key===lastCueKey)return narrating;lastCueKey=key;renderCue(cue);if(!synth||typeof SpeechSynthesisUtterance==='undefined')return false;if(synth.getVoices().length===0)return false;if(synth.speaking||synth.pending||synth.paused)cancelNarration();if(synth.paused)synth.resume();const generation=++narrationGeneration,utterance=new SpeechSynthesisUtterance(cue.text),voice=selectedVoice();utterance.lang=DATA.language;utterance.rate=1;if(voice)utterance.voice=voice;activeUtterance=utterance;narrating=true;video.pause();let watchdog=null;const resume=()=>{if(generation!==narrationGeneration||!narrating)return;if(watchdog){clearTimeout(watchdog);watchdog=null}activeUtterance=null;narrating=false;if(continueAfterNarration&&!tutorialPaused)video.play().catch(()=>{})};watchdog=setTimeout(()=>{if(generation!==narrationGeneration)return;try{synth.cancel()}catch(error){}resume()},narrationWatchdogMs(cue.text));utterance.onend=resume;utterance.onerror=resume;try{synth.speak(utterance);return true}catch(error){resume();return false}}
function seekAndPlay(startMs,cue){const target=Math.max(0,startMs/1000),play=()=>{if(cue)renderCue(cue);video.play().catch(()=>{})};if(Math.abs(video.currentTime-target)<.01){play();return}video.addEventListener('seeked',play,{once:true});video.currentTime=target}
function loadSegment(index,autoplay=false,startMs=0,selectedCue=null){segmentIndex=index;lastCueKey='';cancelNarration();const item=DATA.videos[index];video.src=item.src;video.addEventListener('loadedmetadata',()=>{if(autoplay)seekAndPlay(startMs,selectedCue);else{const target=Math.max(0,startMs/1000);if(Math.abs(video.currentTime-target)>=.01)video.currentTime=target;if(selectedCue)renderCue(selectedCue)}},{once:true});video.load();segmentLabel.textContent=DATA.copy.segment+' '+(index+1)+' / '+DATA.videos.length;renderCue(selectedCue||item.cues[0]||null)}
function formatTime(ms){const total=Math.max(0,Math.floor(ms/1000));return Math.floor(total/60)+':'+String(total%60).padStart(2,'0')}
function jumpToCue(videoIndex,cueIndex){const cue=DATA.videos[videoIndex]?.cues[cueIndex];if(!cue)return;tutorialPaused=false;tutorialStarted=true;continueAfterNarration=true;lastCueKey='';cancelNarration();if(videoIndex!==segmentIndex){loadSegment(videoIndex,true,cue.startMs,cue);return}seekAndPlay(cue.startMs,cue)}
function renderChapters(){DATA.videos.forEach((item,videoIndex)=>item.cues.forEach((cue,cueIndex)=>{const li=document.createElement('li'),button=document.createElement('button'),number=document.createElement('span'),body=document.createElement('span'),title=document.createElement('span'),meta=document.createElement('span');button.type='button';button.className='chapter';button.dataset.key=videoIndex+':'+cue.stepNumber;button.setAttribute('aria-label',DATA.copy.jump+' '+DATA.copy.step+' '+cue.stepNumber+': '+cue.title);number.className='chapter-number';number.textContent=cue.stepNumber;title.className='chapter-title';title.textContent=cue.title;meta.className='chapter-meta';meta.textContent=DATA.copy.segment+' '+(videoIndex+1)+' · '+formatTime(cue.startMs);body.append(title,meta);button.append(number,body);button.addEventListener('click',()=>jumpToCue(videoIndex,cueIndex));li.appendChild(button);chapterList.appendChild(li)}))}
video.addEventListener('pointerdown',()=>{if(!tutorialStarted&&video.paused&&!narrating){tutorialStarted=true;tutorialPaused=false;continueAfterNarration=true;speakCue(currentCue())}});
video.addEventListener('play',()=>{tutorialStarted=true;tutorialPaused=false;continueAfterNarration=true;if(speakCue(currentCue()))video.pause()});
video.addEventListener('pause',()=>{if(!narrating){tutorialPaused=true;continueAfterNarration=false}});
video.addEventListener('timeupdate',()=>speakCue(currentCue()));
video.addEventListener('seeking',()=>{lastCueKey='';cancelNarration()});
video.addEventListener('ended',()=>{if(segmentIndex<DATA.videos.length-1)loadSegment(segmentIndex+1,true);else{continueAfterNarration=false;tutorialStarted=false;tutorialPaused=false}});
window.addEventListener('beforeunload',cancelNarration);
renderChapters();
loadSegment(0);
<\/script></body></html>`}function Co(e){return JSON.stringify(e).replace(/</g,"\\u003c").replace(/>/g,"\\u003e")}function $n(e){return String(e??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}const To=new Set(["click","change","input","selection","navigation","keypress"]),Cn=30;function jo(e,t="zh",n={}){const i=n.domainProfile??"generic",r=e.screenshots||[],{events:a,truncatedSteps:s}=Eo(e.events||[],i),o=Ao(r,a),c=o?1:0;let d=a.map((b,p)=>Ko(b,p+c,r,e,t));if(o&&d.length>0&&(d=[Io(o,e,t),...d]),d.length===0)return{id:`guide-${e.id}`,language:t,title:e.title||`Guide - ${new Date(e.startedAt).toLocaleString()}`,createdAt:Date.now(),steps:[],screenshots:r,url:e.url,duration:e.endedAt?e.endedAt-e.startedAt:0,documentStatus:"capture_failed",captureFailureReason:t==="zh"?"未提取到可用操作步骤:可能未捕获到点击/输入事件,或所捕获事件被判定为噪声。请确认录制在该页面正常工作后重试。":"No usable interaction steps could be extracted: either no clicks/inputs were captured, or all captured events were filtered as noise. Verify recording works on this page and retry."};const f=ha(e,d,t,i);return{id:`guide-${e.id}`,language:t,title:e.title||`Guide - ${new Date(e.startedAt).toLocaleString()}`,createdAt:Date.now(),steps:d,screenshots:r,url:e.url,duration:e.endedAt?e.endedAt-e.startedAt:0,outline:f,documentStatus:"rule_draft",truncatedSteps:s>0?s:void 0}}function Ao(e,t){if(e.length===0||t.length===0)return;const n=e.find(r=>r.captureReason==="initial");if(n)return n;const i=t[0].timestamp;return e.filter(r=>r.timestamp<=i).sort((r,a)=>r.timestamp-a.timestamp)[0]}function Io(e,t,n){return n==="zh"?{stepNumber:1,title:"查看起始页面",description:`确认“${t.title||"当前页面"}”的起始界面。`,voiceScript:"确认起始页面已加载完成，然后开始后续操作。",generatedVoiceScript:"确认起始页面已加载完成，然后开始后续操作。",voiceoverMode:"original",actionType:"initial_screen",screenshotId:e.id,timestamp:e.timestamp}:{stepNumber:1,title:"Review the starting page",description:`Confirm the starting screen for ${t.title||"this workflow"}.`,voiceScript:"Confirm that the starting page is ready before continuing.",generatedVoiceScript:"Confirm that the starting page is ready before continuing.",voiceoverMode:"original",actionType:"initial_screen",screenshotId:e.id,timestamp:e.timestamp}}function Eo(e,t){const n=e.filter(s=>To.has(s.type)).filter(s=>!Fo(s)).sort((s,o)=>s.timestamp-o.timestamp),i=[];for(const s of n){const o=i[i.length-1];if(o&&Go(o,s)){i[i.length-1]=Yo(o,s);continue}if(o&&Vo(o,s)){i[i.length-1]=Tn(o,s);continue}o&&Ho(o,s)?i[i.length-1]=Tn(o,s):i.push(s)}const r=t==="cdp"?Ro(zo(i)):i,a=Math.max(0,r.length-Cn);return{events:r.slice(0,Cn).map((s,o)=>({...s,timestamp:s.timestamp||Date.now()+o})),truncatedSteps:a}}function zo(e){const t=new Set,n=[];for(let i=0;i<e.length;i+=1){if(t.has(i))continue;const r=No(e,i,t);if(r){n.push(r);continue}const a=_o(e,i,t);if(a){n.push(a);continue}const s=Do(e,i,t);if(s){n.push(s);continue}n.push(e[i])}return n}function Ro(e){if(!e.some(r=>{const a=`${pe(r)} ${r.nearbyText||""}`;return/创建分群|分群主体|用户历史行为|线下购物|门店名称|消费金额|分群名称/.test(a)}))return e;const n=new Set,i=[];for(let r=0;r<e.length;r+=1){if(n.has(r))continue;const a=e[r],s=pe(a);if(/^选择行为数据源|^添加筛选条件|^设置统计条件/.test(a.semanticTitle||"")){i.push(a),n.add(r);continue}if(a.controlAction==="select"&&/分群主体/.test(a.controlLabel||"")&&/C端用户/.test(a.selectedOption||s)){const o=We(e,r+1,n,c=>/确定/.test(pe(c)),5e3);n.add(r),o>=0&&n.add(o),i.push(Ie([a,o>=0?e[o]:void 0].filter(Boolean),"选择分群主体“C端用户”","在创建弹窗中选择分群主体「C端用户」，并确认创建。"));continue}if(/最近\d+天|做过/.test(s)){const o=/做过/.test(s)?r:We(e,r+1,n,c=>/做过/.test(pe(c)),5e3);n.add(r),o>=0&&n.add(o),i.push(Ie([a,o>=0?e[o]:void 0].filter(Boolean),"设置行为时间和关系","设置行为时间范围和行为关系，例如「最近1天」内「做过」指定行为。"));continue}if(/行为事件|浏览商品|用户历史行为|线下购物/.test(`${s} ${a.innerText||""} ${a.nearbyText||""}`)){const o=We(e,r+1,n,c=>/门店名称/.test(pe(c)),8e3);if(n.add(r),o>=0&&n.add(o),i.push(Ie([a,o>=0?e[o]:void 0].filter(Boolean),"选择行为数据源“用户历史行为 > 线下购物”","在规则配置中选择行为数据源「用户历史行为 > 线下购物」。")),o>=0){const c=We(e,o+1,n,ui,5e3);c>=0&&(n.add(c),i.push(Ie([e[o],e[c]],`添加筛选条件“门店名称 = ${pe(e[c])}”`,`添加筛选条件：选择属性「门店名称」，并选择目标值「${pe(e[c])}」。`)))}continue}if(a.type==="input"&&/分群名称|分群描述/.test(a.nearbyText||"")){const o=di(e,r,n,3e3).filter(c=>c.event.type==="input"&&/分群名称|分群描述/.test(c.event.nearbyText||""));for(const c of o)n.add(c.index);i.push(Ie(o.map(c=>c.event),"填写分群基础信息","填写分群名称、描述等基础信息，用于保存并识别该用户分群。"));continue}i.push(a)}return Lo(i.filter(r=>{const a=`${r.semanticTitle||""} ${pe(r)}`;return!(/实时 凯德星商城小程序/.test(a)||/input arco-input/i.test(a)||/(快捷选择|天数)/.test(r.semanticTitle||pe(r)))}))}function Lo(e){const t=new Set,n=[];for(const i of e){const r=Z(i.semanticTitle||"");if(/^选择行为数据源|^设置行为时间和关系/.test(r)){if(t.has(r))continue;t.add(r)}n.push(i)}return n}function No(e,t,n){const i=e[t],r=pe(i),a=Z(i.controlLabel||"");if(/用户历史行为|行为数据源/.test(a)&&i.selectedOption)return n.add(t),Ie([i],`选择行为数据源“${a} > ${i.selectedOption}”`,`在规则配置中选择行为数据源「${a} > ${i.selectedOption}」。`);if(!/用户历史行为|行为数据源/.test(r))return null;const s=Po(r),o=s?-1:We(e,t+1,n,f=>{const b=pe(f);return/线下购物|线上购物|会员活动|停车缴费|行为/.test(b)},8e3);if(!s&&o<0)return null;const c=Wt(r,"用户历史行为"),d=s||Wt(pe(e[o]),"线下购物");return n.add(t),o>=0&&n.add(o),Ie([i,o>=0?e[o]:void 0].filter(Boolean),`选择行为数据源“${c} > ${d}”`,`在规则配置中选择行为数据源「${c} > ${d}」。`)}function Po(e){return/线下购物/.test(e)?"线下购物":/线上购物/.test(e)?"线上购物":/会员活动/.test(e)?"会员活动":/停车缴费/.test(e)?"停车缴费":""}function _o(e,t,n){const i=e[t];if(!/添加筛选|筛选条件|添加条件/.test(pe(i)))return null;const r=di(e,t,n,12e3),a=r.find(p=>Bo(p.event)),s=r.find(p=>a&&p.index<=a.index?!1:ui(p.event));if(!a&&!s)return null;const o=a?pe(a.event):"筛选字段",c=s?pe(s.event):"",d=c?`添加筛选条件“${o} = ${c}”`:`添加筛选条件“${o}”`,f=c?`添加筛选条件：选择属性「${o}」，并选择目标值「${c}」。`:`添加筛选条件：选择属性「${o}」。`,b=(s==null?void 0:s.index)??(a==null?void 0:a.index)??t;for(const p of r)p.index<=b&&n.add(p.index);return Ie([i,a==null?void 0:a.event,s==null?void 0:s.event].filter(Boolean),d,f)}function Do(e,t,n){const i=e[t],r=pe(i),a=Z(i.controlLabel||r);if(!/总次数|次数|金额|消费金额/.test(a))return null;const s=i.controlAction==="select"&&i.selectedOption?t:We(e,t+1,n,b=>/≥|>=|大于等于|等于|>|小于|≤|<=/.test(pe(b)),8e3),o=We(e,t+1,n,b=>b.type==="input"&&/\d/.test(b.value||""),8e3);if(o<0)return null;const c=s>=0?Uo(pe(e[s])):"≥",d=Z(e[o].value||pe(e[o])),f=Wt(a,"总次数");return n.add(t),s>=0&&n.add(s),n.add(o),Ie([i,s>=0?e[s]:void 0,e[o]].filter(Boolean),`设置统计条件“${f} ${c} ${d}”`,`设置统计条件「${f} ${c} ${d}」。`)}function Ie(e,t,n){const i=e[0],r=e[e.length-1]||i;return{...r,id:`${i.id}-semantic`,selector:i.selector,label:t,innerText:t,semanticTitle:t,semanticDescription:n,semanticVoiceScript:n,timestamp:r.timestamp}}function di(e,t,n,i){const r=e[t].timestamp,a=[];for(let s=t;s<e.length;s+=1)if(!n.has(s)){if(e[s].timestamp-r>i)break;a.push({index:s,event:e[s]})}return a}function We(e,t,n,i,r){var s,o;const a=((s=e[t-1])==null?void 0:s.timestamp)||((o=e[t])==null?void 0:o.timestamp)||0;for(let c=t;c<e.length;c+=1)if(!n.has(c)){if(e[c].timestamp-a>r)break;if(i(e[c]))return c}return-1}function Bo(e){const t=pe(e);return!t||/添加筛选|请选择|搜索|输入/.test(t)?!1:/(?:门店名称|门店ID|品牌名称|品类|属性|字段|标签|名称|ID|类型)$/.test(t)}function ui(e){const t=pe(e);return!t||/添加筛选|请选择|门店名称|字段|属性/.test(t)?!1:/>>|广场|门店|店|会员|用户|品牌|商场|中心|Mall|mall/.test(t)}function pe(e){return e.semanticTitle?Z(e.semanticTitle):e.controlAction==="select"?Z(e.selectedOption||""):e.type==="input"?Z(e.value||e.label||e.placeholder||""):Z(e.label||e.innerText||e.value||"")}function Wt(e,t){const n=pi(e);return!n||n.includes(t)?t:n}function Uo(e){return/大于等于|>=|≥/.test(e)?"≥":/小于等于|<=|≤/.test(e)?"≤":/等于|=/.test(e)?"=":/大于|>/.test(e)?">":/小于|</.test(e)?"<":e}function Fo(e){if(e.type==="keypress"&&e.value!=="Enter"||e.type==="input"&&!Oo(e)||e.type==="selection"&&!Z(e.value||e.innerText||""))return!0;if(e.type==="click"){const t=Zt(e);if(!t||!e.role&&!["button","a","input","textarea","select"].includes(e.tagName||"")&&!Wo(e,t))return!0}return!1}function Wo(e,t){return!e.coordinates&&!e.rect||!t||t.length>40||/控制台|个人中心|退出登录|使用指南|API 文档|常见问题/.test(t)&&t.length>12?!1:!!Z(e.label||e.innerText||e.value||"")}function Oo(e){return e.tagName==="textarea"?!0:e.tagName!=="input"?!1:!["radio","checkbox","button","submit","reset","hidden","file"].includes(e.elementType||"text")}function Ho(e,t){return e.type!==t.type||e.selector!==t.selector||t.timestamp-e.timestamp>1500?!1:t.type==="input"||t.type==="keypress"||t.type==="click"}function Vo(e,t){return e.type!=="selection"||t.type!=="selection"||t.timestamp-e.timestamp>3e3?!1:Z(e.value||e.innerText||"")===Z(t.value||t.innerText||"")}function Tn(e,t){return{...e,...t,value:t.value??e.value,innerText:t.innerText??e.innerText,timestamp:t.timestamp}}function Go(e,t){return e.type!=="click"||t.type!=="click"||t.timestamp-e.timestamp>3e3?!1:e.role==="combobox"&&t.role==="option"?!0:t.role==="option"&&qo(e)}function Yo(e,t){const n=Xo(e);return{...t,selector:e.selector,role:"combobox",label:e.label||e.innerText,controlAction:"select",controlLabel:n,selectedOption:pi(t.label||t.innerText||t.value||"")}}function Xo(e){const t=ia(e.label||e.innerText||""),n=oa(e.nearbyText||"",t);return n&&ra(t)?n:t||n}function qo(e){const t=Zt(e);return t?/[：:]/.test(t)?!0:e.role==="button"&&/选择|深度|模式|类型|模型|月份|选项/.test(t):!1}function Ko(e,t,n,i,r){var d;const a=Zt(e),s=na(e,i),o=(d=ua(e,n))==null?void 0:d.id,c=ea(e,a,s,r);return{stepNumber:t+1,title:Zo(e,a,r),description:Jo(e,a,s,r),voiceScript:c,generatedVoiceScript:c,voiceoverMode:"original",actionType:e.type,selector:e.selector,focus:Qo(e),screenshotId:o,timestamp:e.timestamp}}function Qo(e){var n,i;const t=e.controlAction==="select"?"select":e.type==="click"||e.type==="input"||e.type==="selection"?e.type:"generic";if(!(!e.coordinates&&!e.rect))return{type:t,x:(n=e.coordinates)==null?void 0:n.x,y:(i=e.coordinates)==null?void 0:i.y,rect:e.rect,viewport:e.viewport,devicePixelRatio:e.devicePixelRatio}}function Zo(e,t,n){return Qt(e.semanticTitle,n)?e.semanticTitle:n==="zh"?e.controlAction==="select"?`选择${e.controlLabel||"选项"}“${e.selectedOption||t}”`:Jt(e)?t?`跳转到“${t}”`:"跳转到页面区块":e.type==="click"?t?`点击“${t}”`:"点击目标元素":e.type==="input"?t?`填写${ca(t)}`:"填写必填信息":e.type==="selection"?t?`选中文本“${t}”`:"选中页面文本":e.type==="keypress"?e.value==="Enter"?"按下 Enter":`按下${e.value||"指定按键"}`:"进入下一页面":e.controlAction==="select"?`Select ${e.selectedOption||t} in ${e.controlLabel||"the dropdown"}`:e.type==="click"?t?`Click "${t}"`:"Click the highlighted element":e.type==="input"?t?`Enter ${t}`:"Enter the required value":e.type==="selection"?t?`Select the text "${t}"`:"Select text on the page":e.type==="keypress"?e.value==="Enter"?"Press Enter":`Press ${e.value||"the key"}`:"Navigate to the next page"}function Jo(e,t,n,i){if(Qt(e.semanticDescription,i))return e.semanticDescription;if(i==="zh"){if(e.controlAction==="select")return`在${e.controlLabel||"当前"}下拉框中选择「${e.selectedOption||t}」。`;if(e.type==="click"){if(Jt(e))return t?`在页面目录中打开“${t}”区块。`:"在页面目录中打开目标区块。";const a=ta(e.role);return t?`在页面中选择${a||"目标"}“${t}”。`:"在页面中选择当前高亮的目标元素。"}return e.type==="input"?t?`在“${t}”中填写所需信息。`:"在当前输入框中填写所需信息。":e.type==="selection"?t?`在页面中圈选文本“${t}”。`:"在页面中圈选需要关注的文本内容。":e.type==="keypress"?e.value==="Enter"?"按下 Enter 提交当前内容或继续下一步。":`按下${e.value||"录制中的按键"}继续操作。`:"等待页面跳转或内容更新。"}const r=n?` in ${n}`:"";if(e.controlAction==="select")return`In the dropdown, select "${e.selectedOption||t}" for ${e.controlLabel||"the field"}.`;if(e.type==="click"){const a=e.role&&e.role!=="generic"?` ${e.role}`:"";return t?`Select the${a} labeled "${t}"${r}.`:`Select the target element${r}.`}return e.type==="input"?t?`Fill in "${t}"${r}.`:`Fill in the active field${r}.`:e.type==="selection"?t?`Select the text "${t}"${r}.`:`Select the relevant text${r}.`:e.type==="keypress"?e.value==="Enter"?`Press Enter to submit or continue${r}.`:`Use the ${e.value||"recorded"} key to continue${r}.`:`Wait for the page to navigate or update${r}.`}function ea(e,t,n,i){if(Qt(e.semanticVoiceScript,i))return e.semanticVoiceScript;if(i==="zh")return e.controlAction==="select"?`在${e.controlLabel||"当前"}下拉框中选择「${e.selectedOption||t}」。`:e.type==="click"?Jt(e)?t?`打开“${t}”区块。`:"打开页面中的目标区块。":t?`点击“${t}”。`:"点击当前需要操作的页面元素。":e.type==="input"?t?`在“${t}”中填写所需信息。`:"填写当前步骤需要的信息。":e.type==="selection"?t?`圈选文本“${t}”。`:"圈选页面中需要关注的文本内容。":e.type==="keypress"?e.value==="Enter"?"按下 Enter，确认当前操作。":`按下${e.value||"指定按键"}，继续当前流程。`:"页面将进入下一步。请等待新页面或新内容加载完成后再继续操作。";const r=n?` in ${n}`:"";return e.controlAction==="select"?`In the dropdown, select ${e.selectedOption||t} for ${e.controlLabel||"the field"}, then confirm the selected value before continuing.`:e.type==="click"?t?`Click ${t}${r}. Then wait for the page to respond before moving on.`:`Click the highlighted item${r}. Then wait for the page to respond.`:e.type==="input"?t?`Enter the required information in ${t}${r}. Check the value before continuing.`:`Enter the required information${r}. Check the value before continuing.`:e.type==="selection"?t?`Select the text ${t}${r}.`:`Select the relevant text${r}.`:e.type==="keypress"?e.value==="Enter"?`Press Enter to confirm this step${r}.`:`Press ${e.value||"the recorded key"} to continue${r}.`:"The workflow navigates to the next page. Wait until the new screen finishes loading."}function Qt(e,t){if(!e)return!1;const n=/[\u3400-\u9fff]/.test(e);return t==="zh"?n:!n}function ta(e){return e&&{button:"按钮",link:"链接",textbox:"输入框",combobox:"下拉选择框",tab:"标签页",checkbox:"复选框",radio:"单选项",menu:"菜单",dialog:"弹窗"}[e]||""}function Zt(e){if(e.type==="selection")return Z(e.value||e.innerText||"");if(e.type==="input")return aa(e);const t=[e.label,e.innerText,e.placeholder,e.value];return Z(t.find(n=>Z(n||""))||"")}function na(e,t){const n=[e.nearbyText,e.pageTitle,t.title],i=Z(n.find(r=>Z(r||""))||"");return i.length>80?`${i.slice(0,77)}...`:i}function Z(e){return e.replace(/\s+/g," ").replace(/[|→]+/g," ").trim().slice(0,80)}function ia(e){var n;const t=Z(e);return((n=t.split(/[：:]/)[0])==null?void 0:n.trim())||t}function ra(e){const t=Z(e);return!t||/^(请选择|选择|全部|默认|基准|无)$/.test(t)?!0:t.length<=2}function oa(e,t){const n=Z(e);if(!n)return"";const i=Z(t),r=i&&n.includes(i)?n.slice(0,n.indexOf(i)).trim():n,a=r.split(/\s+/).filter(Boolean),o=[...a.length>0?a:[r]].reverse().find(c=>/(?:类型|名称|字段|方式|模式|分组|范围|条件|ID|Id|id)$/.test(c));return ht(o||"")}function pi(e){const t=Z(e);if(!t)return"";const n=t.match(/^(.+?)(?:\s+(?:适合|用于|支持|开启|关闭|快速|深度|中\s|低\s|高\s))/);if(n!=null&&n[1])return n[1].trim();const[i]=t.split(/\s+/);return i&&i.length<=12&&t.length>i.length?i:t}function ht(e){return Z(e).replace(/[：:].*$/,"").replace(/^请选择/,"").replace(/^请输入/,"").trim()}function aa(e){const t=ht(e.label||"");if(t)return t;const n=la(e.nearbyText||"",e.placeholder||e.value||"");if(n)return n;const i=ht(e.placeholder||"");return i&&!sa(i)?i:Z(da(e.selector))}function sa(e){return/^≤?\d+字符$|^请输入|^请选择|^input\b/i.test(Z(e))}function la(e,t){const n=Z(e);if(!n)return"";const i=Z(t),s=[...(i&&n.includes(i)?n.slice(0,n.indexOf(i)).trim():n).split(/\s+/).filter(Boolean)].reverse().find(o=>/(?:名称|描述|主体|类型|字段|备注|标签|条件)$/.test(o));return ht(s||"")}function ca(e){return/^[A-Za-z0-9]/.test(e)?` ${e}`:e}function da(e){var n;return e?(((n=e.split(">").pop())==null?void 0:n.trim())||e).replace(/:nth-child\(\d+\)/g,"").replace(/[#.]/g," ").replace(/\[[^\]]+\]/g,"").trim():""}function ua(e,t){if(fi(e)){const n=fa(e.timestamp,t,5e3);if(n)return n}return pa(e.timestamp,t)}function fi(e){return e.type==="click"&&(e.role==="link"||e.tagName==="a")}function Jt(e){return fi(e)&&/href=["']?#/.test(e.selector||"")}function pa(e,t){if(t.length!==0)return t.reduce((n,i)=>{const r=Math.abs(n.timestamp-e);return Math.abs(i.timestamp-e)<r?i:n},t[0])}function fa(e,t,n){return t.filter(i=>i.timestamp<=e&&e-i.timestamp<=n).sort((i,r)=>r.timestamp-i.timestamp)[0]}function ha(e,t,n,i){if(n!=="zh")return;if(i!=="cdp")return{summary:Ct(e,t)};const r=`${e.title} ${t.map(a=>`${a.title} ${a.description}`).join(" ")}`;return/用户分群|创建分群|分群主体|门店名称|用户历史行为/.test(r)?{purpose:"创建用户分群，并通过行为数据源、筛选属性和统计条件圈选目标用户。",scope:"适用于需要在客户数据平台中创建用户分群，并根据历史行为、门店、次数或金额条件筛选用户的场景。",prerequisites:["已登录客户数据平台。","当前账号具备创建和保存用户分群的权限。","已明确分群主体、行为数据源和筛选条件。"],summary:Ct(e,t),verification:["分群主体已选择为目标用户主体，例如「C端用户」。","行为数据源、筛选属性和筛选值已正确显示，例如「用户历史行为 > 线下购物」和「门店名称」。","统计条件已正确设置，例如「总次数 ≥ 1」或消费金额条件。","查询结果和分群基础信息确认无误后再保存。"],conclusion:"完成以上配置后，即可保存该规则型用户分群，并在后续营销或分析场景中使用。"}:{summary:Ct(e,t)}}function Ct(e,t){const n=t.map(i=>i.title).filter(i=>i&&!/^查看/.test(i)).slice(0,6);return n.length===0?`本篇演示围绕“${e.title||"当前流程"}”记录关键操作。`:`本篇演示围绕“${e.title||"当前流程"}”，展示${n.join("、")}等关键操作。`}const ma="stepmark-db",ga=1,Fe="sessions";let Tt=null;function Je(){return Tt||(Tt=Vi(ma,ga,{upgrade(e){if(!e.objectStoreNames.contains(Fe)){const t=e.createObjectStore(Fe,{keyPath:"id"});t.createIndex("startedAt","startedAt"),t.createIndex("status","status")}}})),Tt}const ct={async saveSession(e){await(await Je()).put(Fe,e)},async getSession(e){return(await Je()).get(Fe,e)},async getAllSessions(){return(await(await Je()).getAll(Fe)).sort((n,i)=>i.startedAt-n.startedAt)},async deleteSession(e){await(await Je()).delete(Fe,e)},async clearAll(){await(await Je()).clear(Fe)}};async function jn(e,t=Pe){const n=await ct.getSession(e);if(!n)return null;if(n.guide){const a=n.guide.language??xa(n.guide);if(a===t)return n.guide.language||(n.guide.language=a,await ct.saveSession(n)),{session:n,guide:n.guide}}const i=await Ae.get("domainProfile"),r=jo(n,t,{domainProfile:i});return n.guide=r,await ct.saveSession(n),{session:n,guide:r}}function xa(e){var i,r,a;return(((a=[e.title,(i=e.outline)==null?void 0:i.purpose,(r=e.outline)==null?void 0:r.summary,...e.steps.flatMap(s=>[s.title,s.description,s.voiceScript])].filter(Boolean).join(" ").match(/[\u3400-\u9fff]/g))==null?void 0:a.length)??0)>=3?"zh":"en"}async function ba(e,t){e.guide=t,await ct.saveSession(e)}const mt=32,hi="rgba(15, 23, 42, 0.22)",en=10,_e=.018;function rt(e){const t=De(e.width,_e,1),n=De(e.height,_e,1);return{...e,x:De(e.x,0,1-t),y:De(e.y,0,1-n),width:t,height:n}}function ya(e,t,n){return rt({...e,x:e.x+t,y:e.y+n})}function va(e,t,n,i){let r=e.x,a=e.y,s=e.x+e.width,o=e.y+e.height;return t.includes("left")?r+=n:s+=n,t.includes("top")?a+=i:o+=i,r=De(r,0,s-_e),s=De(s,r+_e,1),a=De(a,0,o-_e),o=De(o,a+_e,1),rt({...e,x:r,y:a,width:s-r,height:o-a})}function wa(e){const t=rt(e);return{left:`${t.x*100}%`,top:`${t.y*100}%`,width:`${t.width*100}%`,height:`${t.height*100}%`}}function mi(e){return e.manualMaskRegions===void 0&&e.maskedDataUrl||e.dataUrl}async function Sa(e,t){const n=t.slice(0,en).map(rt),i=mi(e);return n.length===0?{dataUrl:i,maskedDataUrl:void 0,manualMaskRegions:[]}:{dataUrl:i,maskedDataUrl:await ka(i,n),manualMaskRegions:n}}async function ka(e,t){const n=await $a(e),i=n.naturalWidth||n.width,r=n.naturalHeight||n.height,a=document.createElement("canvas");a.width=i,a.height=r;const s=a.getContext("2d");if(!s||i<=0||r<=0)throw new Error("Could not prepare screenshot redaction");s.drawImage(n,0,0,i,r);for(const o of t){const c=rt(o),d=Math.round(c.x*i),f=Math.round(c.y*r),b=Math.max(1,Math.ceil(c.width*i)),p=Math.max(1,Math.ceil(c.height*r));Ma(s,a,d,f,b,p)}return a.toDataURL("image/png")}function Ma(e,t,n,i,r,a){const s=Math.max(1,Math.ceil(r/mt)),o=Math.max(1,Math.ceil(a/mt)),c=document.createElement("canvas");c.width=s,c.height=o;const d=c.getContext("2d");if(!d)throw new Error("Could not prepare screenshot redaction sample");d.drawImage(t,n,i,r,a,0,0,s,o),e.save(),e.imageSmoothingEnabled=!1,e.drawImage(c,0,0,s,o,n,i,r,a),e.fillStyle=hi,e.fillRect(n,i,r,a),e.restore()}function $a(e){return new Promise((t,n)=>{const i=new Image;i.onload=()=>t(i),i.onerror=()=>n(new Error("Could not load screenshot for redaction")),i.src=e})}function De(e,t,n){return Math.min(n,Math.max(t,Number.isFinite(e)?e:t))}const jt={fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif',color:Ue,background:"linear-gradient(180deg, color-mix(in srgb, var(--fs-brand) 9%, #f8fbfa) 0, color-mix(in srgb, var(--fs-brand) 4%, #f8fbfa) 260px, color-mix(in srgb, var(--fs-brand) 6%, #f3f7f6) 100%)",minHeight:"100vh",margin:0,WebkitFontSmoothing:"antialiased"},At={width:"min(1220px, calc(100% - 48px))",margin:"0 auto",padding:"24px 0 64px"},Ca={display:"grid",gridTemplateColumns:"minmax(0, 1fr) minmax(220px, 280px)",gap:24,alignItems:"flex-start"},Ta={minWidth:0},ja={position:"sticky",top:0,zIndex:10,display:"flex",gap:10,alignItems:"center",flexWrap:"wrap",padding:"10px 12px",marginBottom:24,border:"1px solid color-mix(in srgb, var(--fs-brand) 10%, #e4ece9)",borderRadius:16,background:"rgba(255,255,255,0.88)",boxShadow:"0 1px 2px rgba(15, 23, 42, 0.04), 0 14px 34px -28px rgba(15, 23, 42, 0.45)",backdropFilter:"blur(14px) saturate(160%)"},Aa={display:"flex",alignItems:"center",gap:10,minWidth:180,marginRight:6},Ia={width:30,height:30,borderRadius:9,display:"grid",placeItems:"center",color:"#fff",background:"linear-gradient(135deg, var(--fs-brand), color-mix(in srgb, var(--fs-brand) 68%, #0f172a))",fontWeight:900,fontSize:12,boxShadow:"0 8px 22px -12px var(--fs-brand)"},Ea={minWidth:0,fontSize:13,fontWeight:750,color:Ue,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"},za={color:ve,fontSize:11,lineHeight:1.2},tn={display:"inline-flex",alignItems:"center",justifyContent:"center",gap:6,minHeight:34,padding:"7px 12px",fontSize:13,fontWeight:700,border:"none",borderRadius:10,cursor:"pointer",color:"#fff",fontFamily:"inherit"},Ra=e=>({...tn,background:"var(--fs-brand)",opacity:e?.6:1,cursor:e?"wait":"pointer",boxShadow:"0 10px 20px -14px var(--fs-brand)"}),Me={...tn,background:"#fff",color:Ue,border:"1px solid #e4ece9"},La=e=>({...tn,background:e?"var(--fs-brand)":"#fff",color:e?"#fff":ve,border:`1px solid ${e?"var(--fs-brand)":Ht}`,boxShadow:e?"0 10px 20px -14px var(--fs-brand)":"none"}),Na={position:"relative",overflow:"hidden",border:"1px solid #e4ece9",borderRadius:16,background:"#fff",padding:"30px 34px 32px",marginBottom:22,boxShadow:"0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 22px -18px rgba(15, 23, 42, 0.3)"},Pa={position:"absolute",inset:"0 0 auto",height:4,background:"linear-gradient(90deg, var(--fs-brand), color-mix(in srgb, var(--fs-brand) 30%, #38bdf8), color-mix(in srgb, var(--fs-brand) 30%, #f43f5e))"},nn={color:"var(--fs-brand)",fontSize:12,fontWeight:700,letterSpacing:".08em",textTransform:"uppercase",marginBottom:8},_a={fontSize:32,lineHeight:1.15,margin:"0 0 8px",fontWeight:800,letterSpacing:"-0.01em"},Da={color:ve,fontSize:13,marginTop:10,display:"flex",gap:14,flexWrap:"wrap",alignItems:"center"},gi={color:"var(--fs-brand)",textDecoration:"none",fontWeight:500,wordBreak:"break-all",cursor:"pointer"},It={rule_draft:{bg:"#f1f5f9",text:ve},ai_refined:{bg:Ni,text:Li},vision_refined:{bg:"#f5f3ff",text:"#6d28d9"},manual_edited:{bg:"#eff6ff",text:"#1d4ed8"},capture_failed:{bg:"#fee2e2",text:Yn}},Ba={display:"inline-block",fontSize:11,fontWeight:700,padding:"2px 10px",borderRadius:999,letterSpacing:"0.02em",verticalAlign:"middle"},rn={border:"1px solid #e4ece9",borderTop:"4px solid var(--fs-brand)",borderRadius:16,padding:"18px 20px",marginBottom:22,background:"color-mix(in srgb, var(--fs-brand) 9%, #ffffff)",boxShadow:"0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 22px -18px rgba(15, 23, 42, 0.3)"},xi={display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:16,flexWrap:"wrap",marginBottom:16},bi={margin:"2px 0 0",fontSize:22,lineHeight:1.25,color:Ue,fontWeight:750},Ua={display:"flex",flexDirection:"column",gap:6,minWidth:180,fontSize:12,color:ve,fontWeight:700},Fa={minHeight:38,fontSize:14},Wa={color:ve,fontSize:13,margin:"0 0 12px",lineHeight:1.5},Oa={display:"block",width:"100%",maxHeight:"min(52vw, 420px)",marginBottom:14,borderRadius:12,background:"#0f172a"},Ha={position:"relative"},Va={position:"absolute",left:12,right:12,bottom:24,padding:"8px 12px",borderRadius:8,background:"rgba(15, 23, 42, 0.78)",color:"#fff",fontSize:14,lineHeight:1.5,pointerEvents:"none"},Ga={display:"flex",flexWrap:"wrap",gap:14,alignItems:"flex-start"},An={display:"flex",flexWrap:"wrap",gap:6,alignItems:"baseline",fontSize:13,color:"#475467",lineHeight:1.5,minWidth:0,wordBreak:"break-word"},In={color:ve,fontWeight:700},Ne=e=>({margin:"0 0 12px",fontSize:13,lineHeight:1.5,color:e==="info"?"#1d4ed8":"#9a3412"}),Ya={minWidth:76,textAlign:"center",color:ve,fontSize:12,fontWeight:700},Xa={display:"flex",alignItems:"center",gap:8},qa={display:"flex",alignItems:"center",flexWrap:"wrap",gap:8,marginTop:10},En={display:"flex",alignItems:"center",gap:7,minWidth:0,color:ve,fontSize:11,fontWeight:800},yi={position:"sticky",top:92,alignSelf:"flex-start",maxHeight:"calc(100dvh - 116px)",overflowY:"auto",border:"1px solid #e4ece9",borderRadius:16,padding:14,background:"#fff",boxShadow:"0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 22px -18px rgba(15, 23, 42, 0.3)",zIndex:5},Ka={margin:"0 0 10px",padding:"0 4px 10px",borderBottom:"1px solid #e4ece9",fontSize:12,color:ve,letterSpacing:".08em",textTransform:"uppercase"},Qa={margin:0,paddingLeft:0,listStyle:"none"},Za={margin:"3px 0",color:ve},zn={display:"block",borderRadius:8,padding:"8px 10px",color:Ue,textDecoration:"none",cursor:"pointer",fontSize:13,lineHeight:1.45},Ja={...yi,position:"static",top:"auto",maxHeight:"min(42dvh, 360px)",overflowY:"auto",overscrollBehavior:"contain",marginBottom:22},Et={fontSize:16,fontWeight:700,color:Ue,marginBottom:6},gt={fontSize:14,lineHeight:1.85,color:"#475467",margin:0},es={display:"flex",flexDirection:"column",gap:18},ts={fontSize:12,margin:"4px 0 0",color:ve,letterSpacing:".08em",textTransform:"uppercase"},Rn={overflow:"hidden",border:"1px solid #e4ece9",borderRadius:16,background:"#fff",boxShadow:"0 1px 2px rgba(15, 23, 42, 0.04), 0 8px 22px -18px rgba(15, 23, 42, 0.3)",breakInside:"avoid",scrollMarginTop:92},ns={display:"grid",gridTemplateColumns:"auto minmax(0, 1fr)",gap:14,padding:"18px 22px 14px"},is={width:34,height:34,borderRadius:999,background:"var(--fs-brand)",color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",fontSize:15,fontWeight:800,boxShadow:"0 8px 18px -10px var(--fs-brand)"},rs={minWidth:0},os={display:"flex",justifyContent:"flex-end",gap:6,marginBottom:8,flexWrap:"wrap"},et={display:"inline-flex",alignItems:"center",justifyContent:"center",gap:4,minHeight:30,padding:"5px 8px",fontSize:12,fontWeight:700,border:`1px solid ${Ht}`,borderRadius:8,background:"#fff",color:ve,cursor:"pointer",lineHeight:1,fontFamily:"inherit"},as={fontSize:19,lineHeight:1.4,margin:"0 0 6px",fontWeight:700,color:Ue,letterSpacing:"-0.02em"},ss={color:"#475467",margin:"0 0 14px",fontSize:15,lineHeight:1.7},ls={click:{bg:"#dbeafe",text:"#1d4ed8",border:"#bfdbfe"},form:{bg:"#dcfce7",text:"#166534",border:"#bbf7d0"},select:{bg:"#fef3c7",text:"#92400e",border:"#fde68a"},selection:{bg:"#ede9fe",text:"#6d28d9",border:"#ddd6fe"},keyboard:{bg:"#e0f2fe",text:"#075985",border:"#bae6fd"},navigation:{bg:"#ffe4e6",text:"#be123c",border:"#fecdd3"},initial:{bg:"#dbeafe",text:"#1d4ed8",border:"#bfdbfe"},generic:{bg:"#e2e8f0",text:"#334155",border:"#cbd5e1"}},cs=e=>{const t=ls[e];return{display:"inline-flex",alignItems:"center",width:"fit-content",maxWidth:"100%",padding:"7px 10px",border:`1px solid ${t.border}`,borderRadius:999,background:t.bg,color:t.text,fontSize:12,fontWeight:800,lineHeight:1,letterSpacing:"0.02em"}},ds={position:"relative",cursor:"zoom-in",margin:"0 22px 20px",overflow:"hidden",border:"1px solid #e4ece9",borderRadius:12,background:Xn},us={display:"block",width:"100%",background:Xn},Qe={width:"100%",fontSize:15,padding:"6px 8px",border:`1px solid ${Ht}`,borderRadius:6,color:Ue,background:"#fff",fontFamily:"inherit"},xt={...Qe,minHeight:60,resize:"vertical",lineHeight:1.5},ps={position:"fixed",inset:0,background:"rgba(15, 23, 42, 0.85)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:9999,padding:16},fs={width:"min(1040px, 95vw)"},hs={textAlign:"center",color:"#cbd5e1",fontSize:12,marginTop:8},Ln={color:Yn,fontSize:13,marginBottom:12},zt={textAlign:"center",color:ve,fontSize:15,padding:"60px 12px"},ms={color:ve,fontSize:12,marginTop:6},Rt=e=>({display:"flex",alignItems:"center",flexWrap:"wrap",gap:6,margin:"0 0 14px",padding:"12px 14px",borderRadius:12,border:e?"1px solid color-mix(in srgb, var(--fs-brand) 28%, #c7e7df)":"1px solid #fed7aa",background:e?"color-mix(in srgb, var(--fs-brand) 10%, #ffffff)":"#fff7ed",color:e?"#1d4ed8":"#9a3412",fontSize:13,fontWeight:750,lineHeight:1.5});function Nn(e,t,n,i,r,a="circle"){const s=e!=null&&e.devicePixelRatio&&e.devicePixelRatio>0?e.devicePixelRatio:1,o=(e==null?void 0:e.viewport)??{width:i/s,height:r/s,scrollX:0,scrollY:0},c={...e,type:(e==null?void 0:e.type)??"generic",shape:a,x:Math.max(0,Math.min(1,t))*o.width,y:Math.max(0,Math.min(1,n))*o.height,viewport:o,devicePixelRatio:s};return a==="rectangle"?Jn(c,t,n):c}function vi({screenshot:e,focus:t,additionalFocuses:n=[],activeFocusId:i=je,defaultFocusShape:r="circle",stepNumber:a,uiLanguage:s=ze,editing:o=!1,redactionMode:c=!1,onFocusChange:d,onFocusSelect:f,annotations:b=[],activeAnnotationId:p,onAnnotationsChange:m,onAnnotationSelect:T,manualMaskRegions:z=[],activeMaskId:E,onMaskRegionsChange:U,onMaskSelect:N,onZoom:J}){const G=x.useRef(null),Y=x.useRef(null),_=x.useRef(!1),[oe,ee]=x.useState({width:0,height:0}),[D,te]=x.useState(null),H=x.useRef(null),[se,de]=x.useState(null),S=x.useRef(null),[k,F]=x.useState(null),W=Pn(t,oe.width,oe.height),q=n.map(v=>Pn(v,oe.width,oe.height)??v),he=it(W,q).map(v=>(D==null?void 0:D.id)===v.id?{...v,focus:D.focus}:v),ne=he.find(v=>v.id===i)??he[0],Se=(ne==null?void 0:ne.id)??je,le=ne==null?void 0:ne.focus,ie=se??b,P=k??z,xe=o&&!c,y=xe&&!!d;function B(v){if(_.current){_.current=!1;return}if(c)return;if(!y){J==null||J();return}const A=G.current;if(!A||!A.naturalWidth||!A.naturalHeight)return;const j=A.getBoundingClientRect();if(!j.width||!j.height)return;const R=(le==null?void 0:le.shape)??r;d==null||d(Nn(le,(v.clientX-j.left)/j.width,(v.clientY-j.top)/j.height,A.naturalWidth,A.naturalHeight,R),Se)}function fe(v,A,j,R){if(!y)return;v.preventDefault(),v.stopPropagation(),f==null||f(j);const K=G.current;if(!K)return;const ae=K.getBoundingClientRect();if(!ae.width||!ae.height)return;const ye=v.clientX,me=v.clientY,ue=R,Q=X=>{const h=Ur(ue,A,(X.clientX-ye)/ae.width,(X.clientY-me)/ae.height);Y.current={id:j,focus:h},te({id:j,focus:h})},O=()=>{window.removeEventListener("pointermove",Q),window.removeEventListener("pointerup",O),window.removeEventListener("pointercancel",O);const X=Y.current;X&&(d==null||d(X.focus,X.id)),Y.current=null,te(null),_.current=!0};window.addEventListener("pointermove",Q),window.addEventListener("pointerup",O,{once:!0}),window.addEventListener("pointercancel",O,{once:!0})}function we(v,A,j,R){if(!y)return;v.preventDefault(),v.stopPropagation(),f==null||f(A);const K=G.current;if(!K||!K.naturalWidth||!K.naturalHeight)return;const ae=K.getBoundingClientRect();if(!ae.width||!ae.height)return;const ye=v.clientX,me=v.clientY,ue=j,Q=R.shape==="rectangle"?(Number.parseFloat(R.left)+Number.parseFloat(R.width)/2)/100:Number.parseFloat(R.left)/100,O=R.shape==="rectangle"?(Number.parseFloat(R.top)+Number.parseFloat(R.height)/2)/100:Number.parseFloat(R.top)/100,X=I=>{const L=Nn(ue,Q+(I.clientX-ye)/ae.width,O+(I.clientY-me)/ae.height,K.naturalWidth,K.naturalHeight,R.shape);Y.current={id:A,focus:L},te({id:A,focus:L})},h=()=>{window.removeEventListener("pointermove",X),window.removeEventListener("pointerup",h),window.removeEventListener("pointercancel",h);const I=Y.current;I&&(d==null||d(I.focus,I.id)),Y.current=null,te(null),_.current=!0};window.addEventListener("pointermove",X),window.addEventListener("pointerup",h,{once:!0}),window.addEventListener("pointercancel",h,{once:!0})}function Ge(v,A){if(v.stopPropagation(),T==null||T(A),!xe||!m)return;v.preventDefault();const j=G.current;if(!j)return;const R=j.getBoundingClientRect();if(!R.width||!R.height)return;const K=v.currentTarget.getBoundingClientRect(),ae={maxX:Math.max(.01,1-K.width/R.width-.01),maxY:Math.max(.01,1-K.height/R.height-.01)},ye=v.clientX,me=v.clientY,ue=ie,Q=X=>{const h=ue.map(I=>I.id===A?Hr(I,(X.clientX-ye)/R.width,(X.clientY-me)/R.height,ae):I);H.current=h,de(h)},O=()=>{window.removeEventListener("pointermove",Q),window.removeEventListener("pointerup",O),window.removeEventListener("pointercancel",O);const X=H.current;X&&m(X),H.current=null,de(null),_.current=!0};window.addEventListener("pointermove",Q),window.addEventListener("pointerup",O,{once:!0}),window.addEventListener("pointercancel",O,{once:!0})}function Re(v){if(!c||!U||P.length>=en||v.target.closest(".fs-manual-mask"))return;const A=G.current;if(!A)return;const j=A.getBoundingClientRect();if(!j.width||!j.height)return;v.preventDefault();const R=st((v.clientX-j.left)/j.width,0,1),K=st((v.clientY-j.top)/j.height,0,1),ae=`mask-${Date.now()}-${P.length}`,ye=ue=>{const Q=st((ue.clientX-j.left)/j.width,0,1),O=st((ue.clientY-j.top)/j.height,0,1),X={id:ae,x:Math.min(R,Q),y:Math.min(K,O),width:Math.abs(Q-R),height:Math.abs(O-K)},h=[...z,X];S.current=h,F(h)},me=()=>{window.removeEventListener("pointermove",ye),window.removeEventListener("pointerup",me),window.removeEventListener("pointercancel",me);const ue=S.current,Q=ue==null?void 0:ue.find(O=>O.id===ae);ue&&Q&&Q.width>=_e&&Q.height>=_e&&(N==null||N(ae),U(ue)),S.current=null,F(null),_.current=!0};window.addEventListener("pointermove",ye),window.addEventListener("pointerup",me,{once:!0}),window.addEventListener("pointercancel",me,{once:!0})}function Ze(v,A){v.preventDefault(),v.stopPropagation(),N==null||N(A);const j=P.find(Q=>Q.id===A),R=G.current;if(!j||!R||!U)return;const K=R.getBoundingClientRect(),ae=v.clientX,ye=v.clientY,me=P;Ce(Q=>{const O=me.map(X=>X.id===A?ya(X,(Q.clientX-ae)/K.width,(Q.clientY-ye)/K.height):X);S.current=O,F(O)},()=>{const Q=S.current;Q&&U(Q)})}function Ye(v,A,j){v.preventDefault(),v.stopPropagation(),N==null||N(A);const R=P.find(O=>O.id===A),K=G.current;if(!R||!K||!U)return;const ae=K.getBoundingClientRect(),ye=v.clientX,me=v.clientY,ue=P;Ce(O=>{const X=ue.map(h=>h.id===A?va(h,j,(O.clientX-ye)/ae.width,(O.clientY-me)/ae.height):h);S.current=X,F(X)},()=>{const O=S.current;O&&U(O)})}function Ce(v,A){const j=()=>{window.removeEventListener("pointermove",v),window.removeEventListener("pointerup",j),window.removeEventListener("pointercancel",j),A(),S.current=null,F(null),_.current=!0};window.addEventListener("pointermove",v),window.addEventListener("pointerup",j,{once:!0}),window.addEventListener("pointercancel",j,{once:!0})}const Le=c?mi(e):e.maskedDataUrl||e.dataUrl;return l.jsxs("div",{"data-fs-screenshot-wrap":!0,style:{...ds,cursor:c||y?"crosshair":J?"zoom-in":"default"},onClick:B,onPointerDown:Re,title:c?$(s,"step.privacyMaskDrawHint"):y?$(s,"step.adjustFocus"):void 0,children:[l.jsx("img",{ref:G,src:Le,alt:`${$(s,"preview.screenshotAlt")} ${a??""}`,style:us,onLoad:v=>ee({width:v.currentTarget.naturalWidth,height:v.currentTarget.naturalHeight})}),!c&&he.map(v=>{const A=Yt(v.focus,r);if(!A)return null;const j=v.id===Se;return A.shape==="circle"?l.jsxs("div",{children:[!xe&&v.primary&&l.jsx("div",{className:"fs-focus-dim",style:{background:`radial-gradient(circle 46px at ${A.left} ${A.top}, transparent 0 46px, rgba(15, 23, 42, 0.10) 70px, rgba(15, 23, 42, 0.22) 100%)`}}),l.jsx("div",{"data-fs-focus-ring":!0,className:`fs-click-circle${xe?" fs-focus-draggable":v.primary?" fs-click-circle-animated":" fs-focus-secondary"}${j&&xe?" fs-focus-active":""}`,style:{left:A.left,top:A.top},onPointerDown:R=>we(R,v.id,v.focus,A)})]},v.id):l.jsx(xs,{geometry:A,editing:xe,primary:v.primary,active:j,canAdjust:y&&j,onDragStart:R=>we(R,v.id,v.focus,A),onResizeStart:(R,K)=>fe(R,K,v.id,v.focus)},v.id)}),!c&&ie.map(v=>l.jsx("div",{className:`fs-screenshot-annotation fs-screenshot-annotation-${Xt(v,qt(v,W,q))}${xe?" fs-screenshot-annotation-editing":""}${p===v.id?" fs-screenshot-annotation-active":""}`,style:ni(v),onPointerDown:A=>Ge(A,v.id),onClick:xe?A=>A.stopPropagation():void 0,children:v.text},v.id)),c&&P.map(v=>{const A=v.id===E;return l.jsxs("div",{className:`fs-manual-mask${A?" fs-manual-mask-active":""}`,style:wa(v),onPointerDown:j=>Ze(j,v.id),children:[l.jsx(gs,{sourceDataUrl:Le,region:v}),A&&["top-left","top-right","bottom-left","bottom-right"].map(j=>l.jsx("button",{type:"button",className:`fs-manual-mask-handle fs-manual-mask-${j}`,"aria-label":j,onPointerDown:R=>Ye(R,v.id,j)},j))]},v.id)})]})}function gs({sourceDataUrl:e,region:t}){const n=x.useRef(null);return x.useEffect(()=>{let i=!1;const r=new Image;return r.onload=()=>{if(i)return;const a=n.current;if(!a)return;const s=r.naturalWidth||r.width,o=r.naturalHeight||r.height,c=Math.round(t.x*s),d=Math.round(t.y*o),f=Math.max(1,Math.ceil(t.width*s)),b=Math.max(1,Math.ceil(t.height*o)),p=Math.max(1,Math.ceil(f/mt)),m=Math.max(1,Math.ceil(b/mt));a.width=p,a.height=m;const T=a.getContext("2d");T&&(T.drawImage(r,c,d,f,b,0,0,p,m),T.fillStyle=hi,T.fillRect(0,0,p,m))},r.src=e,()=>{i=!0}},[e,t.x,t.y,t.width,t.height]),l.jsx("canvas",{ref:n,className:"fs-manual-mask-preview","aria-hidden":"true"})}function st(e,t,n){return Math.min(n,Math.max(t,e))}function xs({geometry:e,editing:t,primary:n,active:i,canAdjust:r,onDragStart:a,onResizeStart:s}){const o={left:e.left,top:e.top,width:e.width,height:e.height};return l.jsxs(l.Fragment,{children:[!t&&n&&l.jsx("div",{className:"fs-focus-rect-dim",style:o}),l.jsx("div",{"data-fs-focus-ring":!0,className:`fs-focus-rect${t?" fs-focus-draggable":n?" fs-focus-rect-animated":" fs-focus-secondary"}${i&&t?" fs-focus-active":""}`,style:o,onPointerDown:a}),r&&["top-left","top-right","bottom-left","bottom-right"].map(c=>l.jsx("button",{type:"button",className:`fs-focus-resize-handle fs-focus-resize-${c}`,"aria-label":c,title:c,style:bs(e,c),onPointerDown:d=>s(d,c)},c))]})}function bs(e,t){const n=t.includes("left")?e.left:`calc(${e.left} + ${e.width})`,i=t.includes("top")?e.top:`calc(${e.top} + ${e.height})`;return{left:n,top:i}}function Pn(e,t,n){if(!e||e.viewport||!t||!n)return e;const i=e.devicePixelRatio&&e.devicePixelRatio>0?e.devicePixelRatio:1;return{...e,viewport:{width:t/i,height:n/i,scrollX:0,scrollY:0}}}function ys({screenshot:e,focus:t,additionalFocuses:n=[],annotations:i=[],defaultFocusShape:r="circle",uiLanguage:a=ze,onClose:s}){return x.useEffect(()=>{const o=c=>{c.key==="Escape"&&s()};return window.addEventListener("keydown",o),()=>window.removeEventListener("keydown",o)},[s]),l.jsx("div",{style:ps,onClick:s,children:l.jsxs("div",{style:fs,onClick:o=>o.stopPropagation(),children:[l.jsx(vi,{screenshot:e,focus:t,additionalFocuses:n,annotations:i,defaultFocusShape:r,uiLanguage:a}),l.jsx("div",{style:hs,children:$(a,"preview.lightboxHint")})]})})}function Oe({value:e,editing:t,multiline:n,placeholder:i,onChange:r,style:a,inputStyle:s}){const o=x.useRef(null);if(!t)return l.jsx("div",{style:a,children:e||l.jsx("span",{style:{color:"#cbd5e1"},children:i??""})});const c=()=>{var b;const f=(((b=o.current)==null?void 0:b.value)??"").trim();f!==(e??"")&&r(f)},d=n?"textarea":"input";return l.jsx(d,{ref:o,defaultValue:e??"",placeholder:i,style:s,onBlur:c,onKeyDown:f=>{var b,p,m;f.key==="Escape"&&(o.current&&(o.current.value=e??""),(b=o.current)==null||b.blur()),(f.metaKey||f.ctrlKey)&&f.key==="Enter"&&(f.preventDefault(),(p=o.current)==null||p.blur()),!n&&f.key==="Enter"&&(f.preventDefault(),(m=o.current)==null||m.blur())}})}function vs({step:e,screenshot:t,editing:n,defaultFocusShape:i="circle",justMoved:r,canUp:a,canDown:s,onPatch:o,onMoveUp:c,onMoveDown:d,onDelete:f,onScreenshotPatch:b,onZoom:p,uiLanguage:m=ze}){var xe;const[T,z]=x.useState(null),[E,U]=x.useState(je),[N,J]=x.useState(!1),[G,Y]=x.useState(null),[_,oe]=x.useState((t==null?void 0:t.manualMaskRegions)??[]),[ee,D]=x.useState(!1),te=Is(e.actionType,(xe=e.focus)==null?void 0:xe.type,m),H=e.additionalFocuses??[],se=it(e.focus,H),de=se.find(y=>y.id===E)??se[0],S=(de==null?void 0:de.id)??je,k=de==null?void 0:de.focus,F=(k==null?void 0:k.shape)??i,W=(e.annotations??[]).map(nt);x.useEffect(()=>{oe((t==null?void 0:t.manualMaskRegions)??[])},[t==null?void 0:t.id,t==null?void 0:t.manualMaskRegions]);async function q(y){if(!(!t||ee)){oe(y),D(!0);try{b(await Sa(t,y))}catch{oe(t.manualMaskRegions??[])}finally{D(!1)}}}function he(y){if(S===je){o({focus:y});return}o({additionalFocuses:H.map(B=>B.id===S?y:B)})}function ne(){if(!k||se.length>=lt)return;const y=k.viewport,B=`focus-${Date.now()}-${se.length}`,fe=.08*se.length;let we={...k,id:B,detectedRect:void 0,rect:void 0,rectAdjusted:void 0,x:y!=null&&y.width?Math.min(y.width*.92,(k.x??y.width/2)+y.width*fe):k.x,y:y!=null&&y.height?Math.min(y.height*.92,(k.y??y.height/2)+y.height*fe):k.y};(we.shape??i)==="rectangle"&&(y!=null&&y.width)&&y.height&&(we=Jn(ut(we),(we.x??y.width/2)/y.width,(we.y??y.height/2)/y.height)),U(B),o({additionalFocuses:[...H,we]})}function Se(){S!==je&&(U(je),o({additionalFocuses:H.filter(y=>y.id!==S)}))}function le(){if(W.length>=Mt)return;const y={id:`note-${Date.now()}-${W.length}`,text:$(m,"step.annotationDefault"),x:.06+W.length*.03,y:.07+W.length*.05};z(y.id),o({annotations:[...W,y]})}function ie(y,B){o({annotations:W.map(fe=>fe.id===y?{...fe,...B}:fe)})}function P(y){z(B=>B===y?null:B),o({annotations:W.filter(B=>B.id!==y)})}return l.jsxs("article",{id:`step-${e.stepNumber}`,style:r?{...Rn,animation:"fs-step-moved 0.45s ease"}:Rn,children:[l.jsxs("div",{style:ns,children:[l.jsx("div",{style:is,children:e.stepNumber}),l.jsxs("div",{style:rs,children:[n&&l.jsxs("div",{style:os,children:[l.jsxs("button",{type:"button",style:et,disabled:!a,onClick:c,title:$(m,"step.moveUp"),children:[l.jsx(Zi,{size:14}),$(m,"step.moveUp")]}),l.jsxs("button",{type:"button",style:et,disabled:!s,onClick:d,title:$(m,"step.moveDown"),children:[l.jsx(Ki,{size:14}),$(m,"step.moveDown")]}),l.jsxs("button",{type:"button",style:{...et,background:"#fff1f2",color:"#dc2626",borderColor:"#fecdd3"},onClick:f,title:$(m,"step.deleteConfirm"),children:[l.jsx(ot,{size:14}),$(m,"step.delete")]})]}),l.jsx(Oe,{value:e.title,editing:n,placeholder:$(m,"step.titlePlaceholder"),onChange:y=>o({title:y}),style:as,inputStyle:Qe}),l.jsx(Oe,{value:e.description,editing:n,multiline:!0,placeholder:$(m,"step.descPlaceholder"),onChange:y=>o({description:y}),style:ss,inputStyle:xt})]})]}),t&&l.jsxs(l.Fragment,{children:[n&&l.jsx("div",{style:ws,children:N?l.jsxs("div",{style:_n,children:[l.jsxs("div",{style:Lt,children:[l.jsxs("span",{style:Pt,children:[$(m,"step.privacyMask")," · ",_.length,"/",en]}),l.jsxs("span",{style:Nt,children:[l.jsx(kt,{size:13}),$(m,"step.privacyMaskDrawHint")]})]}),l.jsxs("button",{type:"button",style:Bn(!0),onClick:()=>{J(!1),Y(null)},children:[l.jsx(kt,{size:14}),$(m,"step.privacyMaskDone")]}),G&&l.jsx("button",{type:"button",style:_t,disabled:ee,title:$(m,"step.deletePrivacyMask"),"aria-label":$(m,"step.deletePrivacyMask"),onClick:()=>{var B;const y=_.filter(fe=>fe.id!==G);Y(((B=y[0])==null?void 0:B.id)??null),q(y)},children:l.jsx(ot,{size:14})}),_.length>0&&l.jsx("button",{type:"button",style:dt,disabled:ee,onClick:()=>{Y(null),q([])},children:$(m,"step.clearPrivacyMasks")})]}):l.jsxs(l.Fragment,{children:[l.jsxs("div",{style:_n,children:[l.jsxs("div",{style:Lt,children:[l.jsxs("span",{style:Pt,children:[$(m,"step.focusShape")," · ",se.length,"/",lt]}),l.jsxs("span",{style:Nt,children:[l.jsx(sr,{size:13}),$(m,F==="rectangle"?"step.adjustFocusRectHint":"step.adjustFocusHint")]})]}),l.jsxs("div",{style:Ss,children:[se.map((y,B)=>l.jsx("button",{type:"button",style:on(y.id===S),title:`${$(m,"step.focusShape")} ${B+1}`,onClick:()=>U(y.id),children:B+1},y.id)),l.jsx("button",{type:"button",style:ks,disabled:!k||se.length>=lt,title:$(m,"step.addFocus"),"aria-label":$(m,"step.addFocus"),onClick:ne,children:l.jsx(Sr,{size:14})}),S!==je&&l.jsx("button",{type:"button",style:_t,title:$(m,"step.deleteFocus"),"aria-label":$(m,"step.deleteFocus"),onClick:Se,children:l.jsx(ot,{size:14})})]}),l.jsxs("div",{style:Ms,children:[l.jsxs("button",{type:"button",style:Dn(F==="circle"),disabled:!k,onClick:()=>k&&he({...k,shape:"circle"}),children:[l.jsx(Ui,{size:14}),$(m,"step.focusCircle")]}),l.jsxs("button",{type:"button",style:Dn(F==="rectangle"),disabled:!k,onClick:()=>k&&he(ut(k)),children:[l.jsx(Fi,{size:15}),$(m,"step.focusRectangle")]})]}),F==="rectangle"&&(k==null?void 0:k.detectedRect)&&l.jsxs("button",{type:"button",style:dt,title:$(m,"step.resetFocusRect"),onClick:()=>he(Fr(k)),children:[l.jsx(Mr,{size:14}),$(m,"step.resetFocusRect")]}),l.jsxs("button",{type:"button",style:Bn(!1),title:$(m,"step.privacyMaskHint"),onClick:()=>J(!0),children:[l.jsx(kt,{size:14}),$(m,"step.privacyMask"),_.length>0?` · ${_.length}`:""]})]}),l.jsxs("div",{style:$s,children:[l.jsxs("div",{style:Lt,children:[l.jsxs("div",{style:Pt,children:[$(m,"step.textAnnotations")," · ",W.length,"/",Mt]}),l.jsx("div",{style:Nt,children:$(m,"step.annotationHint")})]}),l.jsxs("button",{type:"button",style:dt,disabled:W.length>=Mt,onClick:le,children:[l.jsx(br,{size:14}),$(m,"step.addTextAnnotation")]})]}),W.length>0&&l.jsx("div",{style:Cs,children:W.map((y,B)=>l.jsxs("div",{style:Ts,children:[l.jsx("button",{type:"button",style:js(T===y.id),title:`${$(m,"step.textAnnotations")} ${B+1}`,onClick:()=>z(y.id),children:B+1}),l.jsx("input",{value:y.text,maxLength:ti,"aria-label":$(m,"step.annotationPlaceholder"),placeholder:$(m,"step.annotationPlaceholder"),style:As(T===y.id),onFocus:()=>z(y.id),onChange:fe=>ie(y.id,{text:fe.target.value})}),l.jsx("button",{type:"button",style:_t,title:$(m,"step.deleteAnnotation"),"aria-label":$(m,"step.deleteAnnotation"),onClick:()=>P(y.id),children:l.jsx(ot,{size:14})})]},y.id))})]})}),l.jsx(vi,{screenshot:t,focus:e.focus,additionalFocuses:H,activeFocusId:S,defaultFocusShape:i,stepNumber:e.stepNumber,uiLanguage:m,editing:n,redactionMode:N,onFocusChange:(y,B)=>{U(B),o(B===je?{focus:y}:{additionalFocuses:H.map(fe=>fe.id===B?y:fe)})},onFocusSelect:U,annotations:W,activeAnnotationId:T,onAnnotationsChange:y=>o({annotations:y}),onAnnotationSelect:z,manualMaskRegions:_,activeMaskId:G,onMaskSelect:Y,onMaskRegionsChange:y=>void q(y),onZoom:()=>p(t,e.focus,H,W)})]}),l.jsx("div",{style:{padding:"0 22px 18px",display:"grid",gap:8,justifyItems:"start"},children:l.jsx("span",{style:cs(te.tone),children:te.label})})]})}const ws={margin:"0 22px 10px",padding:"9px 11px",border:"1px solid #bfdbfe",borderRadius:7,background:"#ecfdf5"},_n={display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"},Lt={display:"inline-flex",alignItems:"center",gap:9,minWidth:0,flex:"1 1 320px"},Nt={display:"inline-flex",alignItems:"center",gap:5,color:"#52736f",fontSize:11,fontWeight:650,lineHeight:1.35},Ss={display:"inline-flex",alignItems:"center",gap:5},on=e=>({display:"grid",placeItems:"center",width:30,height:30,padding:0,border:`1px solid ${e?"#2563eb":"#bfdbfe"}`,borderRadius:6,background:e?"#2563eb":"#fff",color:e?"#fff":"#365b57",fontSize:12,fontWeight:800,cursor:"pointer"}),ks={...on(!1),cursor:"pointer"},Pt={color:"#476b68",fontSize:12,fontWeight:800},Ms={display:"inline-flex",border:"1px solid #bfdbfe",borderRadius:6,overflow:"hidden",background:"#fff"},Dn=e=>({display:"inline-flex",alignItems:"center",gap:5,minHeight:30,padding:"5px 9px",border:0,borderRight:"1px solid #cce7e3",background:e?"#2563eb":"#fff",color:e?"#fff":"#365b57",fontSize:12,fontWeight:750,cursor:"pointer"}),dt={display:"inline-flex",alignItems:"center",gap:5,minHeight:30,padding:"5px 8px",border:"1px solid #bfdbfe",borderRadius:6,background:"#fff",color:"#1d4ed8",fontSize:12,fontWeight:750,cursor:"pointer"},Bn=e=>({...dt,borderColor:e?"#1d4ed8":"#bfdbfe",background:e?"#1d4ed8":"#fff",color:e?"#fff":"#365b57"}),$s={display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,marginTop:10,paddingTop:10,borderTop:"1px solid #bfe8e2"},Cs={display:"grid",gap:6,marginTop:8},Ts={display:"grid",gridTemplateColumns:"26px minmax(0, 1fr) 32px",gap:6,alignItems:"center"},js=e=>({...on(e),width:26,height:26,borderRadius:999}),As=e=>({minWidth:0,height:34,padding:"6px 9px",border:`1px solid ${e?"#2563eb":"#bfdbfe"}`,borderRadius:6,outline:e?"2px solid rgba(13, 148, 136, .12)":"none",background:"#fff",color:"#172033",fontSize:12}),_t={display:"grid",placeItems:"center",width:32,height:32,padding:0,border:"1px solid #fecdd3",borderRadius:6,background:"#fff1f2",color:"#dc2626",cursor:"pointer"};function Is(e,t,n=ze){switch((t&&t!=="generic"?t:e||"").toLowerCase()){case"click":return{label:$(n,"step.action.click"),tone:"click"};case"input":case"change":case"focus":case"blur":return{label:$(n,"step.action.form"),tone:"form"};case"select":return{label:$(n,"step.action.select"),tone:"select"};case"selection":return{label:$(n,"step.action.selection"),tone:"selection"};case"keypress":return{label:$(n,"step.action.keyboard"),tone:"keyboard"};case"navigation":return{label:$(n,"step.action.navigation"),tone:"navigation"};case"initial_screen":return{label:$(n,"step.action.initial"),tone:"initial"};default:return{label:$(n,"step.action.generic"),tone:"generic"}}}const Es=408125543,zs=524531317,wi=231,Rs=163,Ls=160,Ns=161,Ps=33;function an(e){if(!e)throw new Error("Invalid EBML vint: leading zero byte");let t=1,n=128;for(;!(e&n);)if(n>>=1,t+=1,t>8)throw new Error("Invalid EBML vint: length exceeds 8 bytes");return t}function _s(e,t){const n=an(e[t]);let i=0;for(let r=0;r<n;r+=1)i=i*256+e[t+r];return{id:i,length:n}}function Ds(e,t){const n=an(e[t]),i=255>>n;let r=e[t]&i,a=r===i;for(let s=1;s<n;s+=1){const o=e[t+s];r=r*256+o,o!==255&&(a=!1)}return{value:a?null:r,length:n}}function Ot(e,t,n){const{id:i,length:r}=_s(e,t),a=t+r,s=Ds(e,a),o=a+s.length,c=s.value??n-o;return{id:i,sizePos:a,sizeLength:s.length,sizeValue:s.value,dataStart:o,end:Math.min(o+c,n)}}function Bs(e,t,n){let i=0;for(let r=0;r<n;r+=1)i=i*256+e[t+r];return i}function sn(e,t,n,i){let r=n;for(let a=i-1;a>=0;a-=1)e[t+a]=r&255,r=Math.floor(r/256)}function Us(e){let t=1;for(;e>=2**(8*t);)t+=1;return t}function Si(e,t){const n=new Uint8Array(t);return sn(n,0,e,t),n[0]|=1<<8-t,n}function Fs(e){let t=1;for(;e>2**(7*t)-2;)t+=1;return t}function Un(e,t){const n=an(e[t]),i=e[t+n]<<8|e[t+n+1];return i>=32768?i-65536:i}function Ws(e,t,n){let i=t.dataStart;const r=t.end;let a=null,s=null;const o=[];for(;i<r;){const d=Ot(e,i,r);if(d.end<=i)throw new Error("Corrupt EBML: non-advancing element");if(d.id===wi&&s===null)a=Bs(e,d.dataStart,d.end-d.dataStart),s={elementPos:i,dataPos:d.dataStart,dataLength:d.end-d.dataStart,sizeLength:d.sizeLength};else if(d.id===Rs)o.push(Un(e,d.dataStart));else if(d.id===Ls){let f=d.dataStart;for(;f<d.end;){const b=Ot(e,f,d.end);if(b.end<=f)break;b.id===Ns&&o.push(Un(e,b.dataStart)),f=b.end}}i=d.end}const c=a??0;for(const d of o)n.push(c+d);return{sizePos:t.sizePos,sizeLength:t.sizeLength,sizeValue:t.sizeValue,timecode:c,timecodeField:s}}function Os(e){const t=[],n=[];ki(e,0,e.length,t,n);let i=Ps,r=0;if(n.length>0){const a=[...n].sort((o,c)=>o-c);r=a[a.length-1];let s=1/0;for(let o=1;o<a.length;o+=1){const c=a[o]-a[o-1];c>0&&c<s&&(s=c)}s!==1/0&&(i=s)}return{clusters:t,blockTimecodes:n,durationMs:r+i}}function ki(e,t,n,i,r){let a=t;for(;a<n;){const s=Ot(e,a,n);if(s.end<=a)throw new Error("Corrupt EBML: non-advancing element");if(s.id===zs){const o=s.sizeValue===null?Hs(e,s.dataStart,n):s.end;i.push(Ws(e,{...s,end:o},r)),a=o;continue}s.id===Es&&ki(e,s.dataStart,s.end,i,r),a=s.end}}function Hs(e,t,n){for(let i=t;i+4<=n;i+=1)if(!(e[i]!==31&&e[i]!==26)&&(e[i]===31&&e[i+1]===67&&e[i+2]===182&&e[i+3]===117||e[i]===26&&e[i+1]===69&&e[i+2]===223&&e[i+3]===163))return i;return n}function Vs(e,t,n){const i=new Uint8Array(1+n+t);return i[0]=wi,i.set(Si(t,n),1),sn(i,1+n,e,t),i}function Gs(e,t,n){if(n===0)return[e];const i=t.clusters.filter(s=>s.timecodeField!==null);if(i.length===0)return[e];const r=[];let a=0;for(const s of i){const o=s.timecodeField,c=s.timecode+n,d=Us(c);if(d<=o.dataLength){r.push(e.subarray(a,o.dataPos));const T=new Uint8Array(o.dataLength);sn(T,0,c,o.dataLength),r.push(T),a=o.dataPos+o.dataLength;continue}const f=d>2**(7*o.sizeLength)-2?Fs(d):o.sizeLength,b=Vs(c,d,f),p=o.dataPos+o.dataLength-o.elementPos,m=b.length-p;if(s.sizeValue!==null){const T=s.sizeValue+m;if(T>2**(7*s.sizeLength)-2)throw new Error("Cannot remap cluster timecode: declared Cluster size field too small");r.push(e.subarray(a,s.sizePos)),r.push(Si(T,s.sizeLength)),r.push(e.subarray(s.sizePos+s.sizeLength,o.elementPos))}else r.push(e.subarray(a,o.elementPos));r.push(b),a=o.elementPos+p}return r.push(e.subarray(a)),r}async function Ys(e){if(e.length===0)throw new Error("No video segments to merge");const t=e[0].mimeType;if(e.some(s=>s.mimeType!==t))throw new Error(`Cannot merge video segments with different encodings (${t} vs other)`);if(e.length===1)return{blob:e[0].blob,mimeType:t};const n=await Promise.all(e.map(async s=>new Uint8Array(await s.blob.arrayBuffer()))),i=n.map(Os),r=[];let a=0;return n.forEach((s,o)=>{o>0?r.push(...Gs(s,i[o],a)):r.push(s),a+=i[o].durationMs}),{blob:new Blob(r,{type:t}),mimeType:t}}function Xs(e){return e.length>=2&&new Set(e).size===1}function Mi(e){var t,n,i,r;return((t=e.voiceScript)==null?void 0:t.trim())||((n=e.generatedVoiceScript)==null?void 0:n.trim())||((i=e.description)==null?void 0:i.trim())||((r=e.title)==null?void 0:r.trim())||""}function qs(e,t){return e.flatMap(n=>{const i=t[n.stepIndex];if(!i)return[];const r=Mi(i);return r?[{...n,stepNumber:i.stepNumber,text:r}]:[]})}function Ks(e,t,n){let i=null;for(const r of e)if(r.segmentId===t){if(r.startMs>n)break;i=r}return i}class Qs{constructor(t,n){Xe(this,"lastCueKey",null);Xe(this,"narrating",!1);Xe(this,"active",!1);this.cues=t,this.segmentOrder=n}get isActive(){return this.active}get isNarrating(){return this.narrating}start(t,n){return this.active=!0,this.narrating=!1,this.lastCueKey=null,this.evaluate(t,n)}onTimeUpdate(t,n){return!this.active||this.narrating?{type:"none"}:this.evaluate(t,n)}onPlay(t,n){return!this.active||this.narrating?{type:"none"}:this.evaluate(t,n)}onNarrationEnd(){return!this.active||!this.narrating?{type:"none"}:(this.narrating=!1,{type:"resume"})}onUserPause(){this.active&&(this.narrating=!1,this.lastCueKey=null)}onUserSeek(){this.onUserPause()}onSegmentEnded(t){if(!this.active)return{type:"none"};this.narrating=!1,this.lastCueKey=null;const n=this.segmentOrder.indexOf(t),i=n>=0?this.segmentOrder[n+1]:void 0;return i?{type:"advance-segment",segmentId:i}:(this.active=!1,{type:"finish"})}stop(){this.active=!1,this.narrating=!1,this.lastCueKey=null}evaluate(t,n){const i=Ks(this.cues,t,n);if(!i)return{type:"none"};const r=`${i.segmentId}:${i.stepIndex}`;return r===this.lastCueKey?{type:"none"}:(this.lastCueKey=r,this.narrating=!0,{type:"narrate",cue:i})}}class $i{constructor(t,n){Xe(this,"generation",0);this.synthesis=t,this.createUtterance=n}play(t,n){this.cancel();const i=t.filter(o=>o.text.trim().length>0),r=this.generation,a=tl(this.synthesis.getVoices(),n.language,n.voiceName),s=o=>{var b,p,m,T,z;if(r!==this.generation)return;const c=i[o];if(!c){(b=n.onComplete)==null||b.call(n);return}const d=this.createUtterance(c.text.trim());d.lang=n.language,d.rate=bt(n.rate),d.voice=a,d.onstart=()=>{var E;r===this.generation&&((E=n.onItemStart)==null||E.call(n,c))};const f=()=>s(o+1);d.onend=f,d.onerror=f,(m=(p=this.synthesis).paused)!=null&&m.call(p)&&((z=(T=this.synthesis).resume)==null||z.call(T)),this.synthesis.speak(d)};s(0)}cancel(){this.generation+=1,this.synthesis.cancel()}}const Zs=.5,Js=2,el=1;function bt(e){return typeof e!="number"||!Number.isFinite(e)?el:Math.min(Js,Math.max(Zs,e))}function Ci(e,t){var r,a;const n=((r=e.match(/[\u3400-\u9fff]/g))==null?void 0:r.length)??0,i=((a=e.match(/[a-z]/gi))==null?void 0:a.length)??0;return n>=2&&i===0?"zh-CN":i>=3&&n===0?"en-US":t}function tl(e,t,n){var a;const i=(a=t.split("-")[0])==null?void 0:a.toLowerCase();if(n){const s=e.find(o=>o.name===n&&o.lang.toLowerCase().startsWith(`${i}-`));if(s&&Ee(s)>0||s&&!Ti(e,t))return s}const r=e.filter(s=>s.lang.toLowerCase()===t.toLowerCase()).sort((s,o)=>Ee(o)-Ee(s))[0];return r||(e.filter(s=>s.lang.toLowerCase().startsWith(`${i}-`)).sort((s,o)=>Ee(o)-Ee(s))[0]??null)}function Ti(e,t){var i;const n=(i=t.split("-")[0])==null?void 0:i.toLowerCase();return e.some(r=>r.lang.toLowerCase().startsWith(`${n}-`)&&Ee(r)>0)}function nl(e,t){var i;const n=(i=t.split("-")[0])==null?void 0:i.toLowerCase();return e.filter(r=>r.lang.toLowerCase().startsWith(`${n}-`)).sort((r,a)=>Ee(a)-Ee(r))}function Ee(e){return(/^Google\b/i.test(e.name??"")?0:100)+(e.localService?2:0)+(e.default?1:0)}function il(e){return Math.min(15e3,2e3+300*e.length)}function ln(e,t){return t==="local"&&Object.prototype.hasOwnProperty.call(e,Pi)}function Fn(e){return e==="ok"||e==="partial"}function rl(e,t,n=new Set){const i=new Map(t.map(r=>[r.segmentId,r.url]));return e.flatMap((r,a)=>{const s=i.get(r.id);return!s||n.has(r.id)?[]:[{index:a,segment:r,url:s,durationMs:ll(r)}]})}function ol(e,t){return t.length===0?null:e&&t.some(n=>n.segment.id===e)?e:t[0].segment.id}function al(e,t,n){const i=n>1?`-${String(t+1).padStart(2,"0")}`:"";return`${ji(e)}-video${i}.webm`}function sl(e,t=new Date){const n=[t.getFullYear(),String(t.getMonth()+1).padStart(2,"0"),String(t.getDate()).padStart(2,"0")].join("");return`${ji(e)}-video-merged-${n}.webm`}function ji(e){return e.replace(/[^a-zA-Z0-9\u4e00-\u9fa5\s-]/g,"").replace(/\s+/g,"-").toLowerCase().slice(0,50)||"tutorial"}function ll(e){if(typeof e.endedAt!="number")return null;const t=e.endedAt-e.startedAt;return t>=0?t:null}const Wn={en:{sectionEyebrow:"Video tutorial",sectionTitle:"Walkthrough preview",loading:"Loading saved video segments. The document preview stays available.",segmentLabel:"Segment",segmentOption:e=>`Segment ${e+1}`,currentUrl:"URL",duration:"Duration",durationUnknown:"Not available",partialStatus:"Some video segments were not captured, but the written guide is complete.",partialWarning:e=>`${e} saved video segment${e===1?"":"s"} could not be loaded.`,failedWarning:"Saved video is unavailable right now. The written guide is still ready.",playbackWarning:"One or more saved video segments could not be played back.",downloadVideo:"Download video",downloadSegment:"Download segment",downloadMergedVideo:"Download merged video",mergeMimeMismatch:"Video segments use different encodings, so they cannot be merged. Download them individually instead.",mergeFailed:"Merged video export failed. Try downloading the segments individually."},zh:{sectionEyebrow:"视频教程",sectionTitle:"录屏预览",loading:"正在加载已保存的视频片段，文档预览仍可继续使用。",segmentLabel:"片段",segmentOption:e=>`片段 ${e+1}`,currentUrl:"网址",duration:"时长",durationUnknown:"暂不可用",partialStatus:"部分视频片段未成功录制，但文档内容仍然完整。",partialWarning:e=>`${e} 个已保存的视频片段暂时无法加载。`,failedWarning:"当前无法使用已保存的视频，但书面文档仍可正常查看。",playbackWarning:"部分已保存的视频片段无法播放。",downloadVideo:"下载视频",downloadSegment:"下载当前片段",downloadMergedVideo:"下载合并视频",mergeMimeMismatch:"各视频片段编码不一致，无法合并导出，请改为逐段下载。",mergeFailed:"合并视频导出失败，请尝试逐段下载。"}},On={loading:!0,loadErrorCount:0,loadedSources:[]};function cl({session:e,steps:t,activeStepIndex:n,seekRequestToken:i=0,uiLanguage:r,guideLanguage:a=Pe,onActiveStepIndexChange:s}){const o=e.videoManifest??[],c=(r??ze)==="zh"?Wn.zh:Wn.en,d=h=>$(r??ze,h),[f,b]=x.useState(On),[p,m]=x.useState(null),[T,z]=x.useState([]),[E,U]=x.useState(!1),[N,J]=x.useState(null),[G,Y]=x.useState(!1),[_,oe]=x.useState(!1),ee=x.useRef(null),D=x.useRef(null),te=x.useRef(null),H=x.useRef({}),se=x.useRef(!1),de=x.useRef(!1),S=x.useRef(null),k=o.map(h=>`${h.id}:${h.videoBlobKey}:${h.size}:${h.endedAt??""}`).join("|"),F=typeof window<"u"&&"speechSynthesis"in window&&typeof SpeechSynthesisUtterance<"u",W=a==="zh"?"zh-CN":"en-US";x.useEffect(()=>{var h;m(null),z([]),U(!1),J(null),oe(!1),(h=te.current)==null||h.cancel(),Ce()},[e.id,k]),x.useEffect(()=>()=>{var h;(h=te.current)==null||h.cancel(),Ce()},[]),x.useEffect(()=>{const h=()=>Ae.getAll().then(L=>{H.current={voiceName:L.ttsVoice||void 0,rate:bt(L.ttsRate)}}).catch(()=>{});h();const I=(L,V)=>{ln(L,V)&&h()};return chrome.storage.onChanged.addListener(I),()=>chrome.storage.onChanged.removeListener(I)},[]),x.useEffect(()=>{if(!Fn(e.trackBStatus)||o.length===0)return;let h=!1;const I=[];return b(On),Promise.all(o.map(async L=>{try{const V=await Bt.get(L.videoBlobKey);if(!V||V.size===0)return{segmentId:L.id,url:null};const M=URL.createObjectURL(V);return I.push(M),{segmentId:L.id,url:M}}catch{return{segmentId:L.id,url:null}}})).then(L=>{if(h)return;const V=L.flatMap(M=>M.url?[{segmentId:M.segmentId,url:M.url}]:[]);b({loading:!1,loadErrorCount:L.length-V.length,loadedSources:V})}),()=>{h=!0,I.forEach(L=>URL.revokeObjectURL(L))}},[o,k,e.trackBStatus]);const q=x.useMemo(()=>rl(o,f.loadedSources,new Set(T)),[f.loadedSources,o,T]),he=ol(p,q),ne=x.useMemo(()=>ci(t,o),[o,t]),Se=x.useMemo(()=>qs(ne,t),[ne,t]),le=x.useMemo(()=>new Qs(Se,q.map(h=>h.segment.id)),[q,Se]),ie=ne.find(h=>h.stepIndex===n)??null,P=q.find(h=>h.segment.id===he)??null;if(x.useEffect(()=>{he!==p&&m(he)},[p,he]),x.useEffect(()=>{if(ie){if(D.current===n){D.current=null;return}if((P==null?void 0:P.segment.id)!==ie.segmentId){q.some(h=>h.segment.id===ie.segmentId)&&m(ie.segmentId);return}Hn(ee.current,ie.startMs)}},[ie,n,q,i,P==null?void 0:P.segment.id]),!Fn(e.trackBStatus)||o.length===0)return null;const xe=T.length,y=f.loadErrorCount+xe,B=e.trackBStatus==="partial",fe=!f.loading&&q.length===0&&y>0,we=!fe&&y>0,Ge=F&&Se.length>0&&!!P,Re=Xs(q.map(h=>h.segment.mimeType)),Ze=q.length>=2&&!Re;function Ye(){if(!F)return null;if(!te.current){const h={cancel:()=>window.speechSynthesis.cancel(),getVoices:()=>window.speechSynthesis.getVoices(),speak:I=>window.speechSynthesis.speak(I),paused:()=>window.speechSynthesis.paused,resume:()=>window.speechSynthesis.resume()};te.current=new $i(h,I=>new SpeechSynthesisUtterance(I))}return te.current}function Ce(){S.current&&(clearTimeout(S.current),S.current=null)}function Le(h){const I=Ye();if(!I)return;J(h.text),D.current=h.stepIndex,s(h.stepIndex);const L=()=>{var M;le.onNarrationEnd().type==="resume"&&((M=ee.current)==null||M.play().catch(()=>{}))};if(window.speechSynthesis.getVoices().length===0){L();return}const V=ee.current;V&&!V.paused&&(se.current=!0,V.pause()),I.play([{id:String(h.stepIndex),text:h.text}],{language:Ci(h.text,W),voiceName:H.current.voiceName,rate:H.current.rate,onComplete:()=>{Ce(),L()}}),Ce(),S.current=setTimeout(()=>{var M;S.current=null,le.isNarrating&&((M=te.current)==null||M.cancel(),L())},il(h.text))}function v(){const h=ee.current;if(!h||!he||!Ge)return;U(!0);const I=le.start(he,h.currentTime*1e3);I.type==="narrate"?Le(I.cue):h.play().catch(()=>{})}function A(){var h,I;le.stop(),(h=te.current)==null||h.cancel(),Ce(),se.current=!1,de.current=!1,U(!1),J(null),(I=ee.current)==null||I.pause()}function j(h){E&&A(),z(I=>I.includes(h)?I:[...I,h])}function R(h){E&&A(),m(h);const I=ne.find(L=>L.segmentId===h);I&&s(I.stepIndex)}function K(h,I){if(le.isActive){const V=le.onTimeUpdate(I,h.currentTime*1e3);if(V.type==="narrate"){Le(V.cue);return}}const L=wo(ne,I,h.currentTime*1e3);L===null||L===n||(D.current=L,s(L))}function ae(h,I){if(!le.isActive)return;const L=le.onPlay(I,h.currentTime*1e3);L.type==="narrate"&&Le(L.cue)}function ye(){var h;if(se.current){se.current=!1;return}le.isActive&&(le.onUserPause(),(h=te.current)==null||h.cancel())}function me(){var h;le.isActive&&(le.onUserSeek(),(h=te.current)==null||h.cancel())}function ue(h){if(!le.isActive)return;const I=le.onSegmentEnded(h);I.type==="advance-segment"?(de.current=!0,m(I.segmentId)):I.type==="finish"&&(U(!1),J(null))}function Q(h,I){if(de.current){de.current=!1,h.currentTime=0,h.play().catch(()=>{});return}(ie==null?void 0:ie.segmentId)===I&&Hn(h,ie.startMs)}function O(){if(!P)return;const h=document.createElement("a");h.href=P.url,h.download=al(e.title,P.index,o.length),document.body.appendChild(h),h.click(),h.remove()}async function X(){if(!(!Re||G)){Y(!0),oe(!1);try{const h=await Promise.all(q.map(async V=>{const M=await Bt.get(V.segment.videoBlobKey);if(!M||M.size===0)throw new Error(`Missing video blob for segment ${V.segment.id}`);return{blob:M,mimeType:V.segment.mimeType}})),I=await Ys(h),L=URL.createObjectURL(I.blob);try{const V=document.createElement("a");V.href=L,V.download=sl(e.title),document.body.appendChild(V),V.click(),V.remove()}finally{setTimeout(()=>URL.revokeObjectURL(L),1e3)}}catch{oe(!0)}finally{Y(!1)}}}return l.jsxs("section",{style:rn,"aria-label":c.sectionTitle,children:[l.jsxs("div",{style:xi,children:[l.jsxs("div",{children:[l.jsx("div",{style:nn,children:c.sectionEyebrow}),l.jsx("h2",{style:bi,children:c.sectionTitle})]}),q.length>1&&l.jsxs("label",{style:Ua,children:[l.jsx("span",{children:c.segmentLabel}),l.jsx("select",{"aria-label":c.segmentLabel,style:{...Qe,...Fa},value:he??"",onChange:h=>R(h.target.value),children:q.map(h=>l.jsx("option",{value:h.segment.id,children:c.segmentOption(h.index)},h.segment.id))})]})]}),f.loading&&l.jsx("div",{style:Wa,"aria-live":"polite",children:c.loading}),B&&l.jsx("div",{style:Ne("info"),"aria-live":"polite",children:c.partialStatus}),we&&l.jsx("div",{style:Ne("warning"),"aria-live":"polite",children:f.loadErrorCount>0?c.partialWarning(f.loadErrorCount):c.playbackWarning}),fe&&l.jsx("div",{style:Ne("warning"),"aria-live":"polite",children:c.failedWarning}),Ze&&l.jsx("div",{style:Ne("warning"),"aria-live":"polite",children:c.mergeMimeMismatch}),_&&l.jsx("div",{style:Ne("warning"),"aria-live":"polite",children:c.mergeFailed}),!F&&l.jsx("div",{style:Ne("warning"),"aria-live":"polite",children:d("preview.syncSpeechUnavailable")}),F&&!f.loading&&P&&Se.length===0&&l.jsx("div",{style:Ne("info"),"aria-live":"polite",children:d("preview.syncNoNarration")}),P&&l.jsxs(l.Fragment,{children:[l.jsxs("div",{style:Ha,children:[l.jsx("video",{ref:ee,style:Oa,src:P.url,controls:!0,controlsList:"nodownload",preload:"metadata",playsInline:!0,onLoadedMetadata:h=>Q(h.currentTarget,P.segment.id),onTimeUpdate:h=>K(h.currentTarget,P.segment.id),onPlay:h=>ae(h.currentTarget,P.segment.id),onPause:ye,onSeeking:me,onEnded:()=>ue(P.segment.id),onError:()=>j(P.segment.id)},P.segment.id),E&&N&&l.jsx("div",{style:Va,"aria-live":"polite",children:N})]}),l.jsxs("div",{style:Ga,children:[l.jsxs("div",{style:An,children:[l.jsx("span",{style:In,children:c.currentUrl}),P.segment.navUrl?l.jsx("a",{style:gi,href:P.segment.navUrl,target:"_blank",rel:"noreferrer",children:P.segment.navUrl}):l.jsx("span",{children:e.url})]}),l.jsxs("div",{style:An,children:[l.jsx("span",{style:In,children:c.duration}),l.jsx("span",{children:P.durationMs===null?c.durationUnknown:Gi(Math.max(0,P.durationMs))})]}),l.jsxs("button",{style:{...Me,marginLeft:"auto"},disabled:!E&&!Ge,onClick:E?A:v,children:[E?l.jsx(qn,{size:14}):l.jsx(Yi,{size:15}),d(E?"preview.syncStop":"preview.syncPlay")]}),l.jsxs("button",{style:Me,onClick:O,children:[l.jsx(Ut,{size:15}),o.length>1?c.downloadSegment:c.downloadVideo]}),q.length>1&&l.jsxs("button",{style:Me,disabled:!Re||G,onClick:()=>void X(),children:[l.jsx(Ut,{size:15}),c.downloadMergedVideo]})]})]}),!f.loading&&!P&&l.jsx("p",{style:gt,children:c.failedWarning})]})}function Hn(e,t){if(!e||e.readyState<1)return;const n=Math.max(0,t/1e3);Math.abs(e.currentTime-n)>.08&&(e.currentTime=n)}function dl({steps:e,activeStepIndex:t,editing:n,uiLanguage:i=ze,guideLanguage:r=Pe,onPatchStep:a,onActiveStepIndexChange:s,onStepSelect:o}){const[c,d]=x.useState(!1),[f,b]=x.useState([]),[p,m]=x.useState(""),[T,z]=x.useState(1),E=x.useRef(null),U=typeof window<"u"&&"speechSynthesis"in window&&typeof SpeechSynthesisUtterance<"u",N=Math.min(t,Math.max(e.length-1,0)),J=e[N],G=r==="zh"?"zh-CN":"en-US",Y=x.useMemo(()=>e.map(S=>ul(S)),[e]),_=x.useMemo(()=>nl(f,G),[G,f]),oe=_.find(S=>S.name===p),ee=oe&&(Ee(oe)>0||!Ti(f,G))?p:"";if(x.useEffect(()=>{t!==N&&s(N)},[t,s,N]),x.useEffect(()=>()=>{var S;return(S=E.current)==null?void 0:S.cancel()},[]),x.useEffect(()=>{if(!U)return;const S=()=>b(window.speechSynthesis.getVoices());return S(),window.speechSynthesis.addEventListener("voiceschanged",S),()=>window.speechSynthesis.removeEventListener("voiceschanged",S)},[U]),x.useEffect(()=>{const S=(F,W)=>{m(F??""),z(bt(W))};Ae.getAll().then(F=>S(F.ttsVoice,F.ttsRate)).catch(()=>{});const k=(F,W)=>{ln(F,W)&&Ae.getAll().then(q=>S(q.ttsVoice,q.ttsRate)).catch(()=>{})};return chrome.storage.onChanged.addListener(k),()=>chrome.storage.onChanged.removeListener(k)},[]),!J||e.length===0)return null;const D=S=>$(i,S);function te(){if(!U)return null;if(!E.current){const S={cancel:()=>window.speechSynthesis.cancel(),getVoices:()=>window.speechSynthesis.getVoices(),speak:k=>window.speechSynthesis.speak(k),paused:()=>window.speechSynthesis.paused,resume:()=>window.speechSynthesis.resume()};E.current=new $i(S,k=>new SpeechSynthesisUtterance(k))}return E.current}function H(S){const k=te();k&&(d(!0),k.play(S,{language:Ci(S.map(F=>F.text).join(" "),G),voiceName:ee||void 0,rate:T,onItemStart:F=>{const W=Number(F.id);Number.isNaN(W)||s(W)},onComplete:()=>d(!1)}))}function se(){var S;(S=E.current)==null||S.cancel(),d(!1)}function de(S){se();const k=Math.max(0,Math.min(e.length-1,N+S));o?o(k):s(k)}return l.jsxs("section",{style:rn,"aria-label":D("preview.voiceoverTitle"),children:[l.jsxs("div",{style:xi,children:[l.jsxs("div",{children:[l.jsx("div",{style:nn,children:D("preview.voiceover")}),l.jsx("h2",{style:bi,children:D("preview.voiceoverTitle")})]}),l.jsxs("div",{style:Xa,children:[l.jsx("button",{style:et,disabled:N===0,onClick:()=>de(-1),title:D("preview.previousVoiceStep"),"aria-label":D("preview.previousVoiceStep"),children:l.jsx(Kn,{size:15})}),l.jsxs("span",{style:Ya,children:[D("preview.voiceStep")," ",N+1," / ",e.length]}),l.jsx("button",{style:et,disabled:N===e.length-1,onClick:()=>de(1),title:D("preview.nextVoiceStep"),"aria-label":D("preview.nextVoiceStep"),children:l.jsx(Qn,{size:15})})]})]}),l.jsx(Oe,{value:Y[N],editing:n,multiline:!0,placeholder:D("preview.voicePlaceholder"),onChange:S=>a(N,{voiceScript:S}),style:gt,inputStyle:{...xt,minHeight:58,padding:"8px 9px"}},`voice-script-${N}-${J.stepNumber}`),!U&&l.jsx("div",{style:Ne("warning"),children:D("preview.voiceUnavailable")}),l.jsxs("div",{style:qa,children:[U&&_.length>0&&l.jsxs("label",{style:En,children:[l.jsx("span",{children:D("preview.voice")}),l.jsxs("select",{style:{...Qe,width:240,minHeight:36,fontSize:13},value:ee,onChange:S=>{const k=S.target.value;m(k),Ae.set("ttsVoice",k).catch(()=>{})},children:[l.jsx("option",{value:"",children:D("preview.automaticVoice")}),_.map(S=>l.jsxs("option",{value:S.name,children:[S.name," (",S.lang,")"]},`${S.name}-${S.lang}`))]})]}),U&&l.jsxs("label",{style:En,children:[l.jsx("span",{children:D("preview.voiceRate")}),l.jsx("input",{type:"range",min:.5,max:2,step:.25,value:T,style:{width:110},onChange:S=>{const k=bt(Number(S.target.value));z(k),Ae.set("ttsRate",k).catch(()=>{})}}),l.jsxs("span",{children:[T,"×"]})]}),l.jsxs("button",{style:Me,disabled:!U||!Y[N].trim(),onClick:()=>H([{id:String(N),text:Y[N]}]),children:[l.jsx(zr,{size:15}),D("preview.readCurrent")]}),l.jsxs("button",{style:Me,disabled:!U||Y.every(S=>!S.trim()),onClick:()=>H(Y.map((S,k)=>({id:String(k),text:S}))),children:[l.jsx(gr,{size:15}),D("preview.readAll")]}),l.jsxs("button",{style:Me,disabled:!c,onClick:se,children:[l.jsx(qn,{size:14}),D("preview.stopVoice")]})]})]})}const ul=Mi;function Dt(e){const t=new Set;return e.map((n,i)=>{var a;let r=(a=n.id)==null?void 0:a.trim();return(!r||t.has(r))&&(r=gl(n,i,t)),t.add(r),n.id===r?n:{...n,id:r}})}function pl(e,t){return e.filter((n,i)=>i!==t).map((n,i)=>({...n,stepNumber:i+1}))}function fl(e,t){const n=yt(e,t);return n<0?e:pl(e,n)}function hl(e,t,n){const i=yt(e,t),r=i+n;if(i<0||r<0||r>=e.length)return e;const a=[...e];return[a[i],a[r]]=[a[r],a[i]],a.map((s,o)=>({...s,stepNumber:o+1}))}function yt(e,t){return e.findIndex(n=>qe(n)===t)}function ml(e,t,n){const i=Math.max(0,Math.min(n,e.length));return[...e.slice(0,i),{...t},...e.slice(i)].map((r,a)=>({...r,stepNumber:a+1}))}function qe(e){return e.id||`${e.screenshotId||"no-shot"}:${e.timestamp}:${e.selector||e.actionType}`}function gl(e,t,n){const i=`${e.screenshotId||""}|${e.timestamp}|${e.selector||""}|${e.actionType}|${e.title}|${t}`;let r=2166136261;for(let c=0;c<i.length;c+=1)r^=i.charCodeAt(c),r=Math.imul(r,16777619);const a=`step-${(r>>>0).toString(36)}`;let s=a,o=2;for(;n.has(s);)s=`${a}-${o}`,o+=1;return s}class xl{constructor(){Xe(this,"tail",Promise.resolve())}enqueue(t,n){this.tail=this.tail.then(t).catch(i=>{n==null||n(i)})}whenIdle(){return this.tail}}const bl=10;function yl(e,t=bl){const n=Math.max(0,Math.floor(e)),i=Math.max(1,Math.floor(t)),r=[];for(let a=0;a<n;a+=i){const s=Math.min(n-1,a+i-1);r.push({startIndex:a,endIndex:s,stepIndexes:Array.from({length:s-a+1},(o,c)=>a+c)})}return r}function vl(e){const t=Math.max(0,e),n=t/(1024*1024);return n>=1?`${n.toFixed(n>=10?0:1)} MB`:`${Math.max(1,Math.round(t/1024))} KB`}function wl(e,t){const n=new Map(t.steps.map(i=>[qe(i),i]));return{...e,title:t.title,outline:t.outline,documentStatus:t.documentStatus,refinement:t.refinement,steps:e.steps.map((i,r)=>Sl(i,n.get(qe(i)),r))}}function Sl(e,t,n){return t?{...e,stepNumber:n+1,title:t.title,description:t.description,voiceScript:t.voiceScript,generatedVoiceScript:t.generatedVoiceScript,voiceoverMode:t.voiceoverMode}:{...e,stepNumber:n+1}}function kl(){var un,pn;const e=new URLSearchParams(typeof location<"u"?location.search:""),t=e.get("sessionId"),n=e.get("edit")==="1",[i,r]=x.useState(null),[a,s]=x.useState(null),[o,c]=x.useState(null),[d,f]=x.useState(n),[b,p]=x.useState(!1),[m,T]=x.useState(!1),[z,E]=x.useState(null),[U,N]=x.useState(!0),[J,G]=x.useState(null),[Y,_]=x.useState(null),[oe,ee]=x.useState(0),[D,te]=x.useState(0),[H,se]=x.useState(!1),[de,S]=x.useState(null),[k,F]=x.useState(null),[W,q]=x.useState(null),he=x.useRef(null),ne=x.useRef(null),Se=x.useRef(null),le=x.useRef(new xl),ie=x.useRef(null),P=x.useRef(null);x.useEffect(()=>{he.current=i},[i]),x.useEffect(()=>()=>{ie.current!==null&&window.clearTimeout(ie.current),P.current!==null&&window.clearTimeout(P.current)},[]),x.useEffect(()=>{const u=document.documentElement,g=Vt(o==null?void 0:o.themeColor);u.style.setProperty("--fs-brand",g),u.style.setProperty("--fs-focus",Gt(g,o==null?void 0:o.focusColor))},[o==null?void 0:o.themeColor,o==null?void 0:o.focusColor]),x.useEffect(()=>{let u=!1;return(async()=>{const g=await Ae.getAll().catch(()=>null);if(!u){if(c(g),Se.current=(g==null?void 0:g.guideLanguage)??Pe,!t){N(!1);return}try{const w=await jn(t,(g==null?void 0:g.guideLanguage)??Pe);if(u)return;if(!w){E($(g==null?void 0:g.uiLanguage,"preview.loadFailed")),N(!1);return}r(w.session);const C={...w.guide,steps:Dt(w.guide.steps)};ne.current=C,s(C),xe(C),N(!1)}catch{if(u)return;E($(g==null?void 0:g.uiLanguage,"preview.loadError")),N(!1)}}})(),()=>{u=!0}},[t]),x.useEffect(()=>{const u=(g,w)=>{ln(g,w)&&Ae.getAll().then(async C=>{if(c(C),!t||C.guideLanguage===Se.current)return;const re=await jn(t,C.guideLanguage);if(!re)return;Se.current=C.guideLanguage,r(re.session);const ke={...re.guide,steps:Dt(re.guide.steps)};ne.current=ke,s(ke),xe(ke)}).catch(()=>{})};return chrome.storage.onChanged.addListener(u),()=>chrome.storage.onChanged.removeListener(u)},[t]);function xe(u){t&&chrome.runtime.sendMessage({action:"GUIDE_STEP_COUNT_UPDATE",payload:{sessionId:t,stepCount:u.steps.length}}).catch(()=>{})}function y(u){const g={...u,steps:Dt(u.steps)};ne.current=g,s(g),xe(g);const w=he.current;w&&le.current.enqueue(()=>ba(w,g),()=>E($(o==null?void 0:o.uiLanguage,"preview.saveFailed")))}function B(u){const g=ne.current;if(!g)return null;const w=u(g);return w!==g&&y(w),w}function fe(u,g){const w=ne.current,C=w==null?void 0:w.steps[u];C&&we(qe(C),g)}function we(u,g){B(w=>{const C=yt(w.steps,u);if(C<0)return w;const re=w.steps.map((ke,wt)=>wt===C?{...ke,...g}:ke);return{...w,steps:re}})}function Ge(u,g){B(w=>({...w,screenshots:w.screenshots.map(C=>C.id===u?{...C,...g}:C)}))}function Re(u){B(g=>({...g,outline:{...g.outline??{},...u}}))}function Ze(u,g){B(w=>{var C,re;return{...w,outline:{...w.outline??{},chapters:(re=(C=w.outline)==null?void 0:C.chapters)==null?void 0:re.map(ke=>ke.id===u?{...ke,...g}:ke)}}})}function Ye(u,g){const w=ne.current;if(!w)return;const C=hl(w.steps,u,g);C!==w.steps&&(y({...w,steps:C}),_(u),P.current!==null&&window.clearTimeout(P.current),P.current=window.setTimeout(()=>{_(null),P.current=null},500))}function Ce(u){const g=ne.current;if(!g)return;const w=yt(g.steps,u),C=g.steps[w];if(w<0||!C)return;const re=fl(g.steps,u);y({...g,steps:re}),q({step:C,index:w}),ie.current!==null&&window.clearTimeout(ie.current),ie.current=window.setTimeout(()=>{q(null),ie.current=null},6e3)}function Le(){const u=ne.current;if(!u||!W)return;const g=ml(u.steps,W.step,W.index);y({...u,steps:g}),q(null),ie.current!==null&&(window.clearTimeout(ie.current),ie.current=null)}async function v(){const u=ne.current;if(!u||!i)return;const g=await Ae.getAll();if(c(g),!fn(g)){E($(g.uiLanguage,"preview.noModelNotice"));return}const w=Di(g);if(console.log("[StepMark] refine (page fetch)",{provider:w.aiProvider,hasKey:!!w.apiKey,model:w.aiModel,endpoint:w.apiEndpoint||"(default → normalized)"}),w.aiProvider==="mock"){E("Mock mode does not call an API. Configure a real model in Settings.");return}p(!0),E(null);try{const C=await Hi(i,u,{settings:w}),re=ne.current;y(re&&re!==u?wl(re,C):C),f(!1)}catch(C){E(String(C))}finally{p(!1)}}async function A(){const u=await Ae.getAll().catch(()=>null);return u&&c(u),u??o}function j(u=o,g={}){if(!a)throw new Error("Guide is unavailable");const w=a.language;return vo(a,{selectedStepIndexes:g.selectedStepIndexes??a.steps.map((C,re)=>re),includeSummary:!0,includeSource:!1,includeScreenshots:g.includeScreenshots??!0,includeNarration:!1,screenshotMode:"annotated",themeColor:(u==null?void 0:u.themeColor)??"#2563eb",focusColor:(u==null?void 0:u.focusColor)??"",focusShape:(u==null?void 0:u.focusShape)??"circle",language:w??(u==null?void 0:u.guideLanguage)??Pe})}async function R(u,g,w=!0){if(H)return!1;se(!0),S(null),E(null);try{return await go(u,void 0,{includeHeader:w}),S(g),!0}catch{return E($(o==null?void 0:o.uiLanguage,"materials.copyFailed")),!1}finally{se(!1)}}function K(){if(!a||H)return;const u=j(),g=ho(u);if(g.shouldWarn){S(null),F({assessment:g,batches:yl(a.steps.length),activeBatchIndex:0});return}R(u,$(o==null?void 0:o.uiLanguage,"materials.copied"))}async function ae(){if(!k)return;const u=k.batches[k.activeBatchIndex];if(!u)return;const g=k.activeBatchIndex<k.batches.length-1;await R(j(o,{selectedStepIndexes:u.stepIndexes}),$(o==null?void 0:o.uiLanguage,g?"materials.segmentCopied":"materials.finalSegmentCopied"),k.activeBatchIndex===0)&&F(C=>C?{...C,activeBatchIndex:Math.min(C.batches.length-1,C.activeBatchIndex+1)}:null)}function ye(){R(j(o,{includeScreenshots:!1}),$(o==null?void 0:o.uiLanguage,"materials.textCopied"))}async function me(){await R(j(),$(o==null?void 0:o.uiLanguage,"materials.copied"))&&F(null)}async function ue(u){if(!a)return;const g=await A(),w=He.export(a,u,{themeColor:g==null?void 0:g.themeColor,focusColor:g==null?void 0:g.focusColor,focusShape:g==null?void 0:g.focusShape}),C=new Blob([w.content],{type:w.mimeType});O(C,w.filename)}async function Q(){if(!(!a||!i||m)){T(!0),E(null);try{const u=[];for(const w of i.videoManifest??[]){const C=await Bt.get(w.videoBlobKey);C!=null&&C.size&&u.push({segment:w,blob:C})}const g=await ko(a,i,u);O(new Blob([g.content],{type:g.mimeType}),g.filename)}catch(u){E(`${$(o==null?void 0:o.uiLanguage,"preview.tutorialExportFailed")}: ${String(u)}`)}finally{T(!1)}}}function O(u,g){const w=URL.createObjectURL(u),C=document.createElement("a");C.href=w,C.download=g,document.body.appendChild(C),C.click(),C.remove(),URL.revokeObjectURL(w)}async function X(){if(!a)return;const u=await A(),g=He.export(a,"pdf",{themeColor:u==null?void 0:u.themeColor,focusColor:u==null?void 0:u.focusColor,focusShape:u==null?void 0:u.focusShape}),w=window.open("","_blank");if(!w){E("Unable to open the print window. Please check popup blocking settings.");return}w.document.open(),w.document.write(g.content),w.document.close(),w.onload=()=>w.print()}function h(){chrome.runtime.openOptionsPage()}if(U)return l.jsx("div",{style:jt,children:l.jsx("div",{style:At,children:l.jsx("div",{style:zt,children:$(ze,"preview.loading")})})});if(!a||!i)return l.jsx("div",{style:jt,children:l.jsx("div",{style:At,children:l.jsx("div",{style:zt,children:z??$(ze,"preview.empty")})})});const I=u=>u.screenshotId?a.screenshots.find(g=>g.id===u.screenshotId):void 0,L=o?_i(o):void 0,V=o?fn(o):!1,M=u=>$(o==null?void 0:o.uiLanguage,u),cn=a.language??(o==null?void 0:o.guideLanguage)??Pe,be=u=>$(cn,u),$e=tt((un=a.outline)==null?void 0:un.chapters,a.steps),vt=k==null?void 0:k.batches[k.activeBatchIndex],Ii=L?`${M("preview.currentModel")}: ${L.name} · ${L.aiModel||M("preview.noModel")}`:M("preview.noModel"),dn=l.jsxs(l.Fragment,{children:[l.jsx("h2",{style:Ka,children:be("preview.toc")}),l.jsx("ol",{style:Qa,children:a.steps.map((u,g)=>{const w=$e==null?void 0:$e.find(C=>C.startStepNumber===g+1);return l.jsxs(x.Fragment,{children:[w&&l.jsx("li",{style:Ml,children:w.title}),l.jsx("li",{style:Za,children:l.jsxs("a",{style:i.tutorialMode==="video_tutorial"&&g===oe?{...zn,background:"color-mix(in srgb, var(--fs-brand) 10%, #ffffff)",color:"var(--fs-brand)",fontWeight:750}:zn,href:`#step-${u.stepNumber}`,"aria-current":i.tutorialMode==="video_tutorial"&&g===oe?"step":void 0,onClick:()=>{i.tutorialMode==="video_tutorial"&&(ee(g),te(C=>C+1))},children:[be("preview.steps")," ",u.stepNumber,": ",u.title]})})]},qe(u))})})]});return l.jsxs("div",{style:jt,children:[l.jsxs("div",{style:At,children:[l.jsxs("div",{style:ja,children:[l.jsxs("div",{style:Aa,children:[l.jsx("div",{style:Ia,"aria-hidden":"true",children:"SP"}),l.jsxs("div",{style:{minWidth:0},children:[l.jsx("div",{style:Ea,children:a.title}),l.jsx("div",{style:za,children:M(d?"preview.editMode":"preview.readMode")})]})]}),l.jsxs("button",{style:La(d),onClick:()=>f(u=>!u),children:[d?l.jsx(er,{size:15}):l.jsx(vr,{size:15}),M(d?"preview.doneEditing":"preview.edit")]}),l.jsxs("button",{style:Ra(b||!o||!V),disabled:b||!o||!V,onClick:v,title:M("preview.aiPolishTitle"),children:[l.jsx(Tr,{size:15}),M(o?b?"preview.polishing":"preview.aiPolish":"preview.loadingSettings")]}),l.jsxs("button",{style:{...Me,opacity:H?.6:1},disabled:H,onClick:K,title:M("materials.copyDocumentTitle"),children:[l.jsx(St,{size:15}),M(H?"materials.copying":"materials.copyDocument")]}),l.jsxs("button",{style:Me,onClick:()=>void ue("html"),title:M("preview.downloadDocumentHtmlTitle"),children:[l.jsx(Ut,{size:15}),M("preview.downloadDocumentHtml")]}),i.tutorialMode==="video_tutorial"&&(((pn=i.videoManifest)==null?void 0:pn.length)??0)>0&&l.jsxs("button",{style:{...Me,opacity:m?.6:1},disabled:m,onClick:()=>void Q(),title:M("preview.downloadTutorialHtmlTitle"),children:[l.jsx(pr,{size:15}),M(m?"preview.exportingTutorialHtml":"preview.downloadTutorialHtml")]}),l.jsxs("button",{style:Me,onClick:()=>void X(),title:M("preview.printPdfTitle"),children:[l.jsx(dr,{size:15}),"PDF"]}),l.jsxs("button",{style:{...Me,marginLeft:"auto"},onClick:h,children:[l.jsx(hn,{size:15}),M("common.settings")]})]}),k&&vt&&l.jsxs("section",{style:El,"aria-label":M("materials.longGuideTitle"),children:[l.jsxs("div",{style:zl,children:[l.jsxs("div",{children:[l.jsx("div",{style:Rl,children:M("materials.longGuideTitle")}),l.jsx("div",{style:Ll,children:M("materials.longGuideHint")})]}),l.jsx("button",{type:"button",style:Bl,"aria-label":M("materials.closePlan"),title:M("materials.closePlan"),onClick:()=>F(null),children:l.jsx(Lr,{size:17})})]}),l.jsxs("div",{style:Nl,children:[a.steps.length," ",M("preview.steps")," · ",k.assessment.screenshotCount," ",M("materials.screenshots")," · ~",vl(k.assessment.estimatedSourceBytes)]}),l.jsxs("div",{style:Pl,children:[l.jsxs("div",{style:_l,children:[l.jsx("button",{type:"button",style:Vn,disabled:k.activeBatchIndex===0,"aria-label":M("materials.previousSegment"),title:M("materials.previousSegment"),onClick:()=>F(u=>u?{...u,activeBatchIndex:Math.max(0,u.activeBatchIndex-1)}:null),children:l.jsx(Kn,{size:16})}),l.jsxs("span",{style:Dl,children:[(o==null?void 0:o.uiLanguage)==="zh"?`${k.activeBatchIndex+1}/${k.batches.length} ${M("materials.segment")}`:`${M("materials.segment")} ${k.activeBatchIndex+1}/${k.batches.length}`," · ",M("preview.steps")," ",vt.startIndex+1,"–",vt.endIndex+1]}),l.jsx("button",{type:"button",style:Vn,disabled:k.activeBatchIndex>=k.batches.length-1,"aria-label":M("materials.nextSegment"),title:M("materials.nextSegment"),onClick:()=>F(u=>u?{...u,activeBatchIndex:Math.min(u.batches.length-1,u.activeBatchIndex+1)}:null),children:l.jsx(Qn,{size:16})})]}),l.jsxs("button",{type:"button",style:Ai,disabled:H,onClick:()=>void ae(),children:[l.jsx(St,{size:16}),M(H?"materials.copying":"materials.copySegment")]}),l.jsxs("button",{type:"button",style:Gn,disabled:H,onClick:ye,children:[l.jsx(Xi,{size:16}),M("materials.copyTextOnly")]}),l.jsxs("button",{type:"button",style:Gn,disabled:H,onClick:()=>void me(),children:[l.jsx(St,{size:16}),M("materials.copyAllAnyway")]})]})]}),de&&l.jsxs("div",{role:"status",style:Ul,children:[l.jsx(rr,{size:18}),l.jsx("span",{children:de})]}),W&&l.jsxs("div",{role:"status",style:Fl,children:[l.jsxs("span",{children:[be("step.deleted")," ",W.step.stepNumber,": ",W.step.title]}),l.jsxs("button",{style:Wl,onClick:Le,children:[l.jsx(Ir,{size:15}),be("step.undo")]})]}),o&&!V&&l.jsxs("div",{style:Rt(!1),children:[M("preview.noModelNotice"),l.jsxs("button",{style:{...Me,marginLeft:10},onClick:h,children:[l.jsx(hn,{size:15}),M("preview.openSettings")]})]}),b&&o&&L&&l.jsxs("div",{style:Rt(!0),children:[M("preview.polishNotice")," ",L.name," · ",L.aiModel||M("preview.noModel"),". ",M("preview.doNotClose"),Wi(L.aiModel)?` ${M("preview.visionSlow")}`:Oi(L.aiModel)?` ${M("preview.reasoningSlow")}`:""]}),!b&&o&&V&&l.jsx("div",{style:ms,children:Ii}),z&&l.jsx("div",{style:Ln,children:z}),a.captureFailureReason&&l.jsxs("div",{style:Ln,children:[M("preview.captureIssue"),": ",a.captureFailureReason]}),a.truncatedSteps?l.jsx("div",{style:Rt(!1),children:M("preview.truncatedNotice").replace("{count}",String(a.truncatedSteps))}):null,l.jsxs("div",{className:"fs-preview-layout",style:Ca,children:[l.jsxs("div",{className:"fs-preview-main",style:Ta,children:[l.jsx(cl,{session:i,steps:a.steps,activeStepIndex:oe,seekRequestToken:D,uiLanguage:o==null?void 0:o.uiLanguage,guideLanguage:o==null?void 0:o.guideLanguage,onActiveStepIndexChange:ee}),i.tutorialMode==="video_tutorial"&&l.jsx(dl,{steps:a.steps,activeStepIndex:oe,editing:d,uiLanguage:o==null?void 0:o.uiLanguage,guideLanguage:o==null?void 0:o.guideLanguage,onPatchStep:fe,onActiveStepIndexChange:ee,onStepSelect:u=>{ee(u),te(g=>g+1)}}),l.jsxs("section",{style:Na,children:[l.jsx("div",{style:Pa,"aria-hidden":"true"}),l.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10,marginBottom:8},children:[l.jsx("div",{style:nn,children:be("preview.document")}),a.documentStatus&&It[a.documentStatus]&&l.jsx("span",{style:{...Ba,background:It[a.documentStatus].bg,color:It[a.documentStatus].text},children:be(`preview.status.${a.documentStatus}`)})]}),l.jsx(Oe,{value:a.title,editing:d,placeholder:be("preview.titlePlaceholder"),onChange:u=>B(g=>({...g,title:u})),style:_a,inputStyle:{...Qe,fontSize:28,fontWeight:800}}),l.jsxs("div",{style:Da,children:[i.url?l.jsxs("a",{style:gi,href:i.url,target:"_blank",rel:"noopener noreferrer",title:M("preview.openUrl"),children:[l.jsx(hr,{size:14,style:{verticalAlign:-2,marginRight:4}}),i.url]}):l.jsx("span",{children:be("preview.urlNA")}),l.jsxs("span",{children:[be("preview.updated"),": ",new Date(a.createdAt).toLocaleString()]})]})]}),a.outline&&l.jsxs("section",{style:rn,children:[a.outline.purpose!==void 0&&l.jsxs("div",{style:{marginBottom:10},children:[l.jsx("div",{style:Et,children:be("preview.purpose")}),l.jsx(Oe,{value:a.outline.purpose,editing:d,multiline:!0,onChange:u=>Re({purpose:u}),style:gt,inputStyle:xt})]}),a.outline.summary!==void 0&&l.jsxs("div",{style:{marginBottom:10},children:[l.jsx("div",{style:Et,children:be("preview.summary")}),l.jsx(Oe,{value:a.outline.summary,editing:d,multiline:!0,onChange:u=>Re({summary:u}),style:gt,inputStyle:xt})]}),$e&&l.jsxs("div",{style:{marginTop:14},children:[l.jsx("div",{style:Et,children:be("preview.chapters")}),l.jsx("div",{style:$l,children:$e.map(u=>l.jsxs("div",{style:Cl,children:[l.jsxs("span",{style:Tl,children:[be("preview.chapterStartsAt")," ",u.startStepNumber]}),l.jsx(Oe,{value:u.title,editing:d,onChange:g=>Ze(u.id,{title:g}),style:jl,inputStyle:{...Qe,minWidth:0}})]},u.id))})]})]}),a.steps.length>0&&l.jsx("nav",{className:"fs-preview-toc-mobile",style:Ja,"aria-label":be("preview.tocAria"),children:dn}),l.jsxs("section",{style:es,children:[l.jsx("h2",{style:ts,children:be("preview.steps")}),a.steps.map((u,g)=>{const w=qe(u),C=$e==null?void 0:$e.find(re=>re.startStepNumber===g+1);return l.jsxs(x.Fragment,{children:[C&&l.jsxs("div",{id:`chapter-${C.id}`,style:Al,children:[l.jsx("span",{style:Il,children:(($e==null?void 0:$e.indexOf(C))??0)+1}),C.title]}),l.jsx(vs,{step:u,screenshot:I(u),editing:d,defaultFocusShape:(o==null?void 0:o.focusShape)??"circle",uiLanguage:cn,justMoved:Y===w,canUp:g>0,canDown:g<a.steps.length-1,onPatch:re=>we(w,re),onMoveUp:()=>Ye(w,-1),onMoveDown:()=>Ye(w,1),onDelete:()=>Ce(w),onScreenshotPatch:re=>u.screenshotId&&Ge(u.screenshotId,re),onZoom:(re,ke,wt,Ei)=>G({shot:re,focus:ke,additionalFocuses:wt,annotations:Ei})},w)]},w)}),a.steps.length===0&&l.jsx("div",{style:zt,children:be("preview.noSteps")})]})]}),a.steps.length>0&&l.jsx("nav",{className:"fs-preview-toc",style:yi,"aria-label":be("preview.tocAria"),children:dn})]})]}),J&&l.jsx(ys,{screenshot:J.shot,focus:J.focus,additionalFocuses:J.additionalFocuses,annotations:J.annotations,defaultFocusShape:(o==null?void 0:o.focusShape)??"circle",uiLanguage:o==null?void 0:o.uiLanguage,onClose:()=>G(null)})]})}const Ml={margin:"14px 10px 4px",color:"var(--fs-brand)",fontSize:12,fontWeight:800,textTransform:"uppercase"},$l={display:"grid",gap:8,marginTop:8},Cl={display:"grid",gridTemplateColumns:"minmax(90px, 120px) minmax(0, 1fr)",alignItems:"center",gap:10,padding:"8px 10px",border:"1px solid rgba(15, 118, 110, .14)",borderRadius:8,background:"rgba(255,255,255,.72)"},Tl={color:"#64748b",fontSize:12,fontWeight:700},jl={minWidth:0,color:"#172033",fontSize:14,fontWeight:750},Al={display:"flex",alignItems:"center",gap:10,margin:"18px 2px 2px",color:"#172033",fontSize:18,fontWeight:850,scrollMarginTop:86},Il={display:"inline-flex",alignItems:"center",justifyContent:"center",width:28,height:28,borderRadius:6,background:"var(--fs-brand)",color:"#fff",fontSize:12},El={marginTop:10,padding:14,border:"1px solid #bfdbfe",borderRadius:8,background:"#eff6ff",color:"#1e3a8a"},zl={display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12},Rl={fontSize:14,fontWeight:800},Ll={marginTop:3,color:"#476b68",fontSize:12,lineHeight:1.5},Nl={marginTop:9,color:"#1d4ed8",fontSize:12,fontWeight:750},Pl={display:"flex",alignItems:"center",gap:8,flexWrap:"wrap",marginTop:12},_l={display:"inline-flex",alignItems:"center",minHeight:34,border:"1px solid #bfdbfe",borderRadius:7,background:"#fff"},Dl={minWidth:150,padding:"0 8px",textAlign:"center",color:"#234e4a",fontSize:12,fontWeight:750},Vn={display:"inline-flex",alignItems:"center",justifyContent:"center",width:32,height:32,padding:0,border:0,background:"transparent",color:"#1d4ed8",cursor:"pointer"},Ai={display:"inline-flex",alignItems:"center",gap:7,minHeight:34,padding:"7px 11px",border:"1px solid #2563eb",borderRadius:7,background:"#2563eb",color:"#fff",font:"inherit",fontSize:12,fontWeight:800,cursor:"pointer"},Gn={...Ai,border:"1px solid #bfdbfe",background:"#fff",color:"#234e4a"},Bl={display:"inline-flex",alignItems:"center",justifyContent:"center",width:32,height:32,flex:"0 0 32px",padding:0,border:"1px solid #bfdbfe",borderRadius:7,background:"#fff",color:"#476b68",cursor:"pointer"},Ul={marginTop:10,display:"flex",alignItems:"center",gap:8,padding:"11px 13px",border:"1px solid #93c5fd",borderRadius:7,background:"#ecfdf5",color:"#1d4ed8",fontSize:14,fontWeight:750,boxShadow:"0 8px 20px -16px rgba(15, 118, 110, .65)"},Fl={marginTop:10,display:"flex",alignItems:"center",justifyContent:"space-between",gap:12,padding:"10px 13px",border:"1px solid #fecdd3",borderRadius:7,background:"#fff1f2",color:"#9f1239",fontSize:14,fontWeight:700},Wl={display:"inline-flex",alignItems:"center",gap:6,padding:"6px 9px",border:"1px solid #fda4af",borderRadius:6,background:"#fff",color:"#9f1239",font:"inherit",fontWeight:750,cursor:"pointer"};Bi.createRoot(document.getElementById("root")).render(l.jsx(kl,{}));
